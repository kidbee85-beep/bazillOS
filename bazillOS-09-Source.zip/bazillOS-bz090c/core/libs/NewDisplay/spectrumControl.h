
#ifndef _SPECTRUM_CONTROL_H_
#define _SPECTRUM_CONTROL_H_

#include "displayControls.h"
#include <type_traits>

struct strTrackerSpectrum
{
    uint8_t spectrumType;
    int8_t upperData[600];
    int8_t lowerData[600];

    uint16_t loadProgress;

    uint32_t width;
    enum PointsLimit
    {
        k200,
        k300,
        k600
    } pointsLimit;

    // Transient view metadata, never serialized with a project/sample.
    // Explicit opt-in lets other stock pages retain their original drawing.
    // This aggregate is also placed in external NOINIT SDRAM. Its default
    // construction must never emit writes before BOARD_InitBootPeripherals.
    // Initialize all view metadata in init(), after SDRAM is available.
    bool framedLane;
    uint8_t channelHint;
    bool stereoLane;
    bool showChannelLabel;

    void init(uint32_t w = 0, PointsLimit limit = PointsLimit::k300)
    {
        spectrumType = 0;
        framedLane = false;
        channelHint = 0;
        stereoLane = false;
        showChannelLabel = false;
        for (int i = 0; i < 600; i++)
        {
            upperData[i] = 0;
            lowerData[i] = 0;
        }
        loadProgress = 0;
        width = w;
        pointsLimit = limit;
    }
};

static_assert(std::is_trivially_default_constructible<strTrackerSpectrum>::value,
              "External NOINIT waveform data must not run a startup constructor");

//--------------------------------------------------------------------
class cSpectrum : public cDisplayControl
{
  public:
    cSpectrum(strControlProperties* properties);
    virtual ~cSpectrum();

    virtual void update();
    virtual void update2();
    virtual void update3();

    virtual void setStyle(uint32_t style);
    virtual void setText(const char* text);
    virtual void setValue(int value);
    virtual void setColors(const uint32_t* colors);
    virtual void setData(void* data);

  private:
    strTrackerSpectrum* spectrum;
#ifdef TRACKER_MINI
    void drawFramedLane();
#endif

    uint16_t ramPartSize[5] = { 0 };
    uint8_t refreshStep;
};

#endif
