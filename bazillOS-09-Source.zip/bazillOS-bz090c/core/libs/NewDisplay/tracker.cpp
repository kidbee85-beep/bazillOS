
#include "FT812.h"

#include "display.h"
#ifdef TRACKER_MINI
#include "BazillSurface.h"
#include "BazillPatternCursor.h"
#endif
#include "trackerControl.h"

#include <cstring>
#include <algorithm>

static void Number2Bitmaps(int16_t x, int16_t y, uint8_t font_x, uint8_t font_y, int16_t number);
static void Number2HexBitmaps(int16_t x, int16_t y, uint8_t font_x, uint8_t font_y, int16_t number);

#define ROW_NUM 1

static constexpr uint8_t text_font = 1;

#ifdef TRACKER_MINI
// Original BREAKLINE graphics use the user's cached theme palette. Integer-only
// colour mixing; no extra clocks, background task, allocation or audio work.
static uint32_t breaklinePatternMix(uint32_t a, uint32_t b, unsigned amount)
{
    const unsigned inverse = 16 - amount;
    const uint32_t r = (((a >> 16) & 255) * inverse + ((b >> 16) & 255) * amount) >> 4;
    const uint32_t g = (((a >> 8) & 255) * inverse + ((b >> 8) & 255) * amount) >> 4;
    const uint32_t blue = ((a & 255) * inverse + (b & 255) * amount) >> 4;
    return (r << 16) | (g << 8) | blue;
}

static uint32_t breaklinePatternAccent(const uint32_t* palette, unsigned track, bool muted)
{
    return muted ? palette[16] : palette[2 + (track & 3)];
}
#endif


#if ROW_NUM
// uint8_t fourParamsOffset[4] =		{	4,44,73,130,	};	// stara koncepcja z numerami
// wierszy uint8_t twoParamsOffsetFirst[4] =	{	9,9,9,9,		}; uint8_t
// twoParamsOffsetSecond[4] =	{	50,50,50,50,	};

static uint8_t fourParamsOffset[4] = {
    8,
    52,
    86,
    140,
};
static uint8_t twoParamsOffsetFirst[4] = {
    7,
    10,
    5,
    0,
};
static uint8_t twoParamsOffsetSecond[4] = {
    0,
    61,
    50,
    50,
};
static uint8_t oneParamsOffset[4] = {
    32,
    37,
    27,
    27,
};

static const uint8_t fourParamsSelOffset[4] = {
    1,
    44,
    78,
    132,
};
static const uint8_t fourParamsSelWidth[4] = {
    40,
    30,
    50,
    50,
};

static const uint8_t twoParamsSel1Offset[4] = {
    1,
    1,
    1,
    0,
};
static const uint8_t twoParamsSel1Width[4] = {
    40,
    33,
    43,
    0,
};

static const uint8_t twoParamsSel2Offset[4] = {
    0,
    52,
    44,
    44,
};
static const uint8_t twoParamsSel2Width[4] = {
    0,
    37,
    45,
    45,
};

static const uint8_t oneParamsSelOffset[4] = {
    24,
    29,
    19,
    19,
};
static const uint8_t oneParamsSelWidth[4] = {
    40,
    30,
    50,
    50,
};

#else

uint8_t fourParamsOffset[4] = {
    18,
    60,
    92,
    144,
};
uint8_t twoParamsOffsetFirst[4] = {
    9,
    9,
    6,
    0,
};
uint8_t twoParamsOffsetSecond[4] = {
    0,
    65,
    55,
    55,
};
uint8_t oneParamsOffset[4] = {
    35,
    40,
    30,
    30,
};

const uint8_t fourParamsSelOffset[4] = {
    10,
    52,
    84,
    136,
};
const uint8_t fourParamsSelWidth[4] = {
    40,
    30,
    50,
    50,
};

const uint8_t twoParamsSel1Offset[4] = {
    1,
    1,
    1,
    0,
};
const uint8_t twoParamsSel1Width[4] = {
    40,
    30,
    47,
    0,
};

const uint8_t twoParamsSel2Offset[4] = {
    0,
    57,
    49,
    49,
};
const uint8_t twoParamsSel2Width[4] = {
    0,
    30,
    47,
    47,
};

const uint8_t oneParamsSelOffset[4] = {
    27,
    32,
    22,
    22,
};
const uint8_t oneParamsSelWidth[4] = {
    40,
    30,
    50,
    50,
};

const uint8_t paramToStateOffset[4] = {
    1,
    2,
    4,
    8,
};

#endif

const uint8_t paramToStateOffset[4] = {
    1,
    2,
    4,
    8,
};

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
cTracker::cTracker(strControlProperties* properties)
  : cDisplayControl(controlIdTracker, 5)
{
    colorsCount = 21;
    colors = display.getTheme().patternTrackerColors;

    if (properties == nullptr)
    {
        posX = 0;
        posY = 0;
        width = 0;
        height = 0;
        tracks = nullptr;
        this->style = 0;
        value = 0;
        return;
    }

    colors = (properties->colors == nullptr) ? colors : properties->colors;

    tracks = (strTrackerPattern*)properties->data;
    posX = properties->x;
    posY = properties->y;
    width = properties->w;
    height = properties->h;
    value = properties->value;

    setStyle(properties->style);
}

cTracker::~cTracker()
{
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
void cTracker::setStyle(uint32_t style)
{
    this->style = style;

    int8_t textFont = FONT_INDEX_FROM_STYLE;
    textFont = (textFont >= 0) ? textFont : 0;
    font = &fonts[textFont];
}

void cTracker::setText(const char* text)
{
}

void cTracker::setValue(int value)
{
    this->value = value;
}

void cTracker::setColors(const uint32_t* colors)
{
    this->colors = colors;
}

void cTracker::setData(void* data)
{
    tracks = (strTrackerPattern*)data;
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
// void cTracker::update()
//{
//    update1();
//
//    //    // API_LIB_BeginDirectDL();
//    //    displayDriver->beginCoProListNoCheck();
//    //    API_CMD_DLSTART();
//    //
//    //    API_SAVE_CONTEXT();
//    //
//    //    switch (refreshStep)
//    //    {
//    //        case 0: refresh1(); break;
//    //        case 1: refresh2(); break;
//    //        case 2: refresh3(); break;
//    //        case 3: refresh4(); break;
//    //        case 4: refresh5(); break;
//    //        default: refreshStep = 0; break;
//    //    }
//    //
//    //    API_RESTORE_CONTEXT();
//    //
//    //    displayDriver->endCoProList();
//}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
void cTracker::update()
{
    // colors[10] = tracks->selectColor;
    if (!tracks) return;
    displayMode = value < 0 || value > 15 ? 0 : value;
    // Compact cells can hold at most two fields. Invalid/stale masks use detail.
    if (__builtin_popcount(unsigned(displayMode)) > 2) displayMode = 0;

    lastFontHandle = -1; // zerowanie ostatnio uzywanej czcionki

    rightOffset = 0;
    leftOffset = 0;

#if ROW_NUM
    rightOffset = 27;
    leftOffset = 27;
#endif

    stepHight = height / 15;

    if (displayMode > 0)
    {
        tracksWidth = (800 - (rightOffset + leftOffset)) / 8;
        columnsCount = (tracks->popupMode & 2) ? 6 : 8;
        columnsCount = (tracks->popupMode & 4) ? 4 : columnsCount;
        paramCount = (displayMode & 1) + ((displayMode & 2) >> 1) + ((displayMode & 4) >> 2) +
                     ((displayMode & 8) >> 3);
    }
    else
    {
        columnsCount = (tracks->popupMode & 2) ? 3 : 4;
        columnsCount = (tracks->popupMode & 4) ? 2 : columnsCount;
        tracksWidth = (800 - (rightOffset + leftOffset)) / 4;
        paramCount = 4;
    }

    firstTrack = std::clamp<int>(tracks->firstVisibleTrack, 0,
                                strTrackerPattern::kTrackCount-columnsCount);
    if (tracks->popupMode & 1)
    {
        rowCount = 8;
    }
    else
    {
        rowCount = 15;
    }

    // counting row numbers here
    // used in several further procedures
    bool showTrackEndLines = false;
    uint16_t rowNumbers[15]{};

    const int patternLength = std::clamp<int>(tracks->patternLength, 1, 128);
    for (uint16_t i = 0; i < rowCount; i++)
    {
        if (tracks->track[0].row[i].note[0] == 0)
        {
            rowNumbers[i] = 0;
            continue;
        }

        int16_t row = tracks->actualStep - 6 + i;

        if (row < 1)
        {
            showTrackEndLines = true;
            row = patternLength + (row % patternLength);
        }
        else if (row > patternLength)
        {
            showTrackEndLines = true;
            row = (row - 1) % patternLength + 1;
        }

        rowNumbers[i] = row;
    }

    backgroundDivider(rowNumbers);

    calculateSelection();

    playHead();

    lines();

#if ROW_NUM
    drawRowNumbers(rowNumbers, showTrackEndLines);
#endif

    selection();
}

//------------------------------------------------------------------------------------------
void cTracker::update2()
{
    if (!tracks) return;
    if (displayMode == 0 || displayMode & 1)
    {
        notes();
    }
}

void cTracker::update3()
{
    if (!tracks) return;
    if (displayMode == 0 || displayMode & 2)
    {
        instruments();
    }
}

void cTracker::update4()
{
    if (!tracks) return;
    if (displayMode == 0 || displayMode & 4)
    {
        // volumes();
        fxes1();
    }
}

void cTracker::update5()
{
    if (!tracks) return;
    if (displayMode == 0 || displayMode & 8)
    {
        fxes2();
    }

    tracksNumbers();
}

//-------------------------------------------------------------------------------------
// podzialka
void cTracker::backgroundDivider(uint16_t* rowNumbers)
{
#ifdef TRACKER_MINI
    // Keep the exact 15-row geometry and popup dimensions. Beat emphasis follows
    // the existing user division, with every fourth division a stronger bar.
    API_SAVE_CONTEXT();
    API_LINE_WIDTH(16);
    API_BEGIN(RECTS);
    const uint32_t culture = breaklinePatternMix(colors[1], 0x090F14, 8);
    API_COLOR(culture);
    API_VERTEX2F(posX + 1, posY);
    API_VERTEX2F(width - 2, posY + height - 2);
    API_COLOR(breaklinePatternMix(culture, colors[15], 1));
    for (unsigned column=1; column<columnsCount; column+=2) {
        API_VERTEX2F(rightOffset+column*tracksWidth+2,posY);
        API_VERTEX2F(rightOffset+(column+1)*tracksWidth-2,posY+rowCount*stepHight-1);
    }
    const unsigned division = tracks->stepDevider ? tracks->stepDevider : 1;
    for (uint8_t i = 0; i < rowCount; ++i)
    {
        if (!rowNumbers[i]) continue;
        const unsigned row = rowNumbers[i] - 1;
        const bool beat = row % division == 0;
        const bool bar = beat && (row / division) % 4 == 0;
        if (!beat && !(i == 7 && tracks->selectState)) continue;
        uint32_t background = culture;
        if (beat) background = breaklinePatternMix(culture, colors[11], 5);
        if (bar) background = breaklinePatternMix(background, colors[15], 1);
        if (i == 7 && tracks->selectState)
            background = breaklinePatternMix(culture, bazill_cursor::color(tracks->selectColor,colors), 1);
        API_COLOR(background);
        API_VERTEX2F(1, posY + i * stepHight + 1);
        API_VERTEX2F(798, posY + (i + 1) * stepHight - 1);
    }
    API_END();
    bazill_surface::patternTexture(rightOffset+1,posY,width-rightOffset-leftOffset-2,rowCount*stepHight);
    // Phosphor edge colonies: low-opacity halation, static behind musical data.
    bazill_surface::patternMicrobe(width-leftOffset-88,posY+rowCount*stepHight-100,10,80,0xA3F376);
    bazill_surface::patternMicrobe(rightOffset+40,posY+89,4,56,0x56D7C3,52);
    bazill_surface::patternMembrane(width-leftOffset-48,posY+rowCount*stepHight-60);
    API_BEGIN(RECTS);
    // Quiet row-number gutters keep musical position readable while the centre
    // row or playback line moves. All marks stay outside the note/FX cells.
    API_COLOR(breaklinePatternMix(colors[1], 0, 3));
    API_VERTEX2F(1, posY);
    API_VERTEX2F(rightOffset - 1, posY + rowCount * stepHight - 1);
    API_VERTEX2F(800 - leftOffset + 1, posY);
    API_VERTEX2F(798, posY + rowCount * stepHight - 1);
    for (uint8_t i = 0; i < rowCount; ++i)
    {
        if (!rowNumbers[i]) continue;
        const unsigned row = rowNumbers[i] - 1;
        const bool beat = row % division == 0;
        const bool bar = beat && (row / division) % 4 == 0;
        if (beat)
        {
            API_COLOR(bar ? colors[3] : colors[16]);
            API_VERTEX2F(24, posY + i * stepHight + 2);
            API_VERTEX2F(26, posY + i * stepHight + (bar ? 6 : 3));
            if (!(tracks->popupMode & 6))
            {
                API_VERTEX2F(773, posY + i * stepHight + 2);
                API_VERTEX2F(775, posY + i * stepHight + (bar ? 6 : 3));
            }
        }
    }
    if (tracks->selectState && rowCount > 7 && rowNumbers[7])
    {
        API_COLOR(bazill_cursor::color(tracks->selectColor,colors));
        const int markerY=posY+7*stepHight;
        if(tracks->selectColor==0) {
            // Split EDIT marker, without covering the row number.
            API_VERTEX2F(24,markerY+5);API_VERTEX2F(26,markerY+10);
            API_VERTEX2F(24,markerY+15);API_VERTEX2F(26,markerY+20);
        } else {
            const int inset=tracks->selectColor==4?4:8;
            API_VERTEX2F(24,markerY+inset);API_VERTEX2F(26,markerY+stepHight-inset);
        }
    }
    API_END();
    API_RESTORE_CONTEXT();
    return;
#endif

    // tlo calosci
    API_COLOR(colors[1]);
    API_LINE_WIDTH(16);
    API_BEGIN(RECTS);

    API_VERTEX2F(posX + 1, posY);
    API_VERTEX2F(width - 2, posY + height - 2);

    if (tracks->patternLength > 1)
    {
        // podzialka
        API_COLOR(colors[11]);
        API_LINE_WIDTH(16);

        for (uint8_t i = 0; i < rowCount; i++)
        {
            if (rowNumbers[i] == 0)
            {
                continue;
            }

            if ((rowNumbers[i] - 1) % tracks->stepDevider == 0)
            {
                API_VERTEX2F(1, posY + (i * stepHight) + 1);
                API_VERTEX2F(798, posY + (i * stepHight) + 26);
            }
        }
    }

    API_END();

    if (style & controlStyleBottomShadow)
    {
        // gradient-cien dolny
        API_SAVE_CONTEXT();
        API_SCISSOR_XY(1, 413);
        API_SCISSOR_SIZE(798, 10);
        API_CMD_GRADIENT(0, 413, colors[1], 0, 423, 0x0);
        API_RESTORE_CONTEXT();
    }
}

//-------------------------------------------------------------------------------------
// // linie
void cTracker::lines()
{
    API_COLOR(colors[15]);
    API_LINE_WIDTH(16);
    API_BEGIN(LINES);

#if ROW_NUM
    API_VERTEX2F(rightOffset, posY);
    API_VERTEX2F(rightOffset, posY + stepHight * 15);

    API_VERTEX2F(799 - leftOffset, posY);
    API_VERTEX2F(799 - leftOffset, posY + stepHight * 15);
#endif

    uint16_t x;
    for (uint8_t i = 0; i < columnsCount; i++)
    {
        x = (rightOffset + tracksWidth * i);
#ifdef TRACKER_MINI
        if(displayMode==0 || displayMode==3){
        API_VERTEX2F(x, posY);API_VERTEX2F(x+1, posY+height/3);
        API_VERTEX2F(x-1, posY+height/3);API_VERTEX2F(x, posY+height*2/3);
        API_VERTEX2F(x+1, posY+height*2/3);API_VERTEX2F(x, posY+height);
        }else{API_VERTEX2F(x,posY);API_VERTEX2F(x,posY+height);}
#else
        API_VERTEX2F(x, posY);API_VERTEX2F(x, posY+height);
#endif
    }

    API_END();
#ifdef TRACKER_MINI
    API_SAVE_CONTEXT();
    // Parameter separators are only added to the existing four-parameter view.
    // No text, selection width, hit area or parameter ordering is changed.
    if (displayMode == 0)
    {
        API_COLOR(breaklinePatternMix(colors[1], colors[15], 7));
        API_LINE_WIDTH(8);
        API_BEGIN(LINES);
        const uint8_t separators[] = { 43, 77, 133 };
        for (uint8_t i = 0; i < columnsCount; ++i)
            for (uint8_t separator : separators)
            {
                const int x = rightOffset + tracksWidth * i + separator;
                API_VERTEX2F(x, posY + 2);
                API_VERTEX2F(x, posY + rowCount * stepHight - 1);
            }
        API_END();
    }
    API_LINE_WIDTH(16);
    API_BEGIN(RECTS);
    for (uint8_t i = 0; !tracks->showTrackNames && i < columnsCount; ++i)
    {
        const int track = firstTrack + i;
        if (track < 0 || track >= strTrackerPattern::kTrackCount) continue;
        const uint32_t accent = breaklinePatternAccent(colors, track, tracks->inactive[track]);
        const int x = rightOffset + tracksWidth * i;
        API_COLOR(track == tracks->actualTrack ? accent : breaklinePatternMix(colors[1], accent, 5));
        // Split top rail is our splice motif; it does not cover the first row.
        API_VERTEX2F(x + 4, posY);
        API_VERTEX2F(x + 19, posY + 1);
        API_VERTEX2F(x + 24, posY);
        API_VERTEX2F(x + tracksWidth - 4, posY + 1);
    }
    API_END();
    API_RESTORE_CONTEXT();
#endif

}

#define DISP_RGB(red, green, blue)                                                                 \
    ((((red) & 255UL) << 16) | (((green) & 255UL) << 8) | (((blue) & 255UL) << 0))

//-------------------------------------------------------------------------------------
// playhead
void cTracker::playHead()
{
    if (!tracks->showPlayhead)
    {
        return;
    }

    if (tracks->playheadPosition > tracks->actualStep - 8 &&
        tracks->playheadPosition < tracks->actualStep + 8)
    {
        uint8_t row = tracks->playheadPosition - (tracks->actualStep - 8);
        uint16_t phy1 = posY + stepHight * (row - 1);
        uint16_t phy2 = posY + stepHight * row;
        int16_t phx1 = 1;
        uint16_t phw = 798;

        if (tracks->playheadStartTrack > 0 || tracks->playheadEndTrack < 7)
        {
            int16_t phx2;
            if (tracks->playheadStartTrack < tracks->playheadEndTrack)
            {
                phx1 = tracks->playheadStartTrack;
                phx2 = tracks->playheadEndTrack;
            }
            else
            {
                phx1 = tracks->playheadEndTrack;
                phx2 = tracks->playheadStartTrack;
            }

            if (phx1 > (firstTrack + columnsCount) ||
                phx2 < firstTrack)
            {
                return;
            }

            phx1 = leftOffset + (phx1 - firstTrack) * tracksWidth + 1;
            phx1 = phx1 < (leftOffset + 1) ? leftOffset + 1 : phx1;

            phx2 = leftOffset + (phx2 + 1 - firstTrack) * tracksWidth;
            phx2 = phx2 > (800 - rightOffset - 1) ? 800 - rightOffset - 1 : phx2;

            phw = phx2 - phx1;
        }

        if (style & controlStyleGradient)
        {
            API_SAVE_CONTEXT();

            // API_LINE_WIDTH(16);
            API_SCISSOR_XY(phx1, phy1 - 11);
            API_SCISSOR_SIZE(phw, 11);
            API_CMD_GRADIENT(0, phy1 - 11, colors[1], 0, phy1, colors[13]);

            API_RESTORE_CONTEXT();

            API_SAVE_CONTEXT();

            // API_LINE_WIDTH(16);
            API_SCISSOR_XY(phx1, phy2);
            API_SCISSOR_SIZE(phw, 11);
            API_CMD_GRADIENT(0, phy2, colors[13], 0, phy2 + 11, colors[1]);

            API_RESTORE_CONTEXT();
        }
        else
        {
            API_COLOR(colors[13]);
            API_LINE_WIDTH(16);
            API_BEGIN(RECTS);
            API_VERTEX2F(phx1, phy1);
            API_VERTEX2F(phx1 + phw, phy2);
            API_END();
        }
#ifdef TRACKER_MINI
        // A thin phosphor rail reads as PLAY even on an otherwise empty step.
        API_SAVE_CONTEXT();API_COLOR(0xBFEF76);API_COLOR_A(175);API_LINE_WIDTH(16);API_BEGIN(RECTS);
        API_VERTEX2F(phx1,phy1);API_VERTEX2F(phx1+phw,phy1+1);
        API_COLOR_A(255);API_VERTEX2F(24,phy1+7);API_VERTEX2F(26,phy2-7);
        API_END();API_RESTORE_CONTEXT();
        // Musical feedback is driven only by the sequencer's existing playhead
        // refresh. It indicates a step with note data, never an audio VU level.
        const unsigned visibleRow = row - 1;
        if (visibleRow < rowCount && phy2 > phy1 + 8)
        {
            API_SAVE_CONTEXT();
            API_LINE_WIDTH(16);
            API_BEGIN(RECTS);
            for (uint8_t column = 0; column < columnsCount; ++column)
            {
                const int track = firstTrack + column;
                if (track < 0 || track >= strTrackerPattern::kTrackCount) continue;
                const char* note = tracks->track[track].row[visibleRow].note;
                if (tracks->inactive[track] || !note[0] || note[0] == '-') continue;
                const int x = rightOffset + column * tracksWidth + 2;
                if (x < phx1 || x >= phx1 + phw) continue;
                API_COLOR(breaklinePatternAccent(colors, track, false));
                API_VERTEX2F(x, phy1 + 4);
                API_VERTEX2F(x + 2, phy2 - 4);
            }
            API_END();
            API_RESTORE_CONTEXT();
        }
#endif
    }
}

void cTracker::calculateSelection()
{
    if (tracks->selectState == 2)
    {
        selectActive = 1;

        if (tracks->selectStartTrack > tracks->selectEndTrack)
        {
            select1_x = tracks->selectEndTrack;
            select2_x = tracks->selectStartTrack;
        }
        else
        {
            select1_x = tracks->selectStartTrack;
            select2_x = tracks->selectEndTrack;
        }

        if (tracks->selectStartStep > tracks->selectEndStep)
        {
            select1_y = tracks->selectEndStep;
            select2_y = tracks->selectStartStep;
        }
        else
        {
            select1_y = tracks->selectStartStep;
            select2_y = tracks->selectEndStep;
        }

        select1_x = select1_x - firstTrack;
        select1_x = rightOffset + select1_x * tracksWidth + 1;

        if (select1_x < rightOffset + 1)
        {
            select1_x = rightOffset + 1;
        }

        select2_x = select2_x - firstTrack;
        select2_x = rightOffset + select2_x * tracksWidth + tracksWidth - 2;

        if (select2_x > 800 - rightOffset - 4)
        {
            select2_x = 800 - rightOffset - 4;
        }

        select1_y = select1_y - tracks->actualStep + 7;
        select1_y = posY + select1_y * stepHight;

        select2_y = select2_y - tracks->actualStep + 7;
        select2_y = posY + select2_y * stepHight + stepHight;
    }
    else
    {
        selectActive = 0;
    }
}
//-------------------------------------------------------------------------------------
// ZAZNACZENIE ACTUAL
void cTracker::selection()
{
#ifdef TRACKER_MINI
    const uint32_t selection_color=bazill_cursor::color(tracks->selectColor,colors);
#else
    uint32_t selection_color = colors[10];
    if (tracks->selectColor == 1)
        selection_color = colors[17];
    else if (tracks->selectColor == 2)
        selection_color = colors[18];
#endif

    //--------------------
    // ZAZNACZENIE

    if (tracks->selectState == 2)
    {
        // pole pod edytowanym parametrem
        API_COLOR(selection_color);
        API_LINE_WIDTH(kRedFrameWidth);
        API_BEGIN(RECTS);

        int16_t sel2_y_temp = select2_y;

        if (sel2_y_temp > posY + stepHight * 15) // dolna
        {
            sel2_y_temp = posY + stepHight * 15;
        }

        if (paramCount == 1 && ((1 << tracks->selectedParam) &
                                displayMode)) // jesli jest na ekranie zaznaczony parametr
        {
            for (uint8_t i = 0; i < 8; i++)
            {
                uint16_t SelPosX =
                  select1_x + oneParamsSelOffset[tracks->selectedParam] + (tracksWidth * i);
                if (SelPosX < select2_x && SelPosX > select1_x)
                {
                    API_VERTEX2F(SelPosX, select1_y + 1);
                    API_VERTEX2F(SelPosX + oneParamsSelWidth[tracks->selectedParam], sel2_y_temp);
                }
            }
        }
        else if (paramCount == 2 && ((1 << tracks->selectedParam) & displayMode))
        {
            uint8_t param = whichParamFromTwoSelected();
            uint8_t offset = param == 0 ? twoParamsSel1Offset[tracks->selectedParam]
                                        : twoParamsSel2Offset[tracks->selectedParam];
            uint8_t width = param == 0 ? twoParamsSel1Width[tracks->selectedParam]
                                       : twoParamsSel2Width[tracks->selectedParam];

            for (uint8_t i = 0; i < 8; i++)
            {
                uint16_t SelPosX = select1_x + offset + (tracksWidth * i);
                if (SelPosX < select2_x && SelPosX > select1_x)
                {
                    API_VERTEX2F(SelPosX, select1_y + 1);
                    API_VERTEX2F(SelPosX + width, sel2_y_temp);
                }
            }
        }
        else if (paramCount == 4)
        {
            for (uint8_t i = 0; i < 8; i++)
            {
                uint16_t SelPosX =
                  select1_x + fourParamsSelOffset[tracks->selectedParam] + (tracksWidth * i);
                if (SelPosX < select2_x && SelPosX > select1_x)
                {
                    API_VERTEX2F(SelPosX, select1_y + 1);
                    API_VERTEX2F(SelPosX + fourParamsSelWidth[tracks->selectedParam], sel2_y_temp);
                }
            }
        }
        API_END();

        // ramka zaznaczenia
        API_BEGIN(LINES);

        if (select1_y >= posY) // gorna
        {
            API_VERTEX2F(select1_x, select1_y);
            API_VERTEX2F(select2_x, select1_y);
        }
        else
        {
            select1_y = posY;
        }

        if (select2_y <= posY + stepHight * 15) // dolna
        {
            API_VERTEX2F(select2_x, select2_y);
            API_VERTEX2F(select1_x, select2_y);
        }
        else
        {
            select2_y = posY + stepHight * 15;
        }

        if (select2_x <= rightOffset + tracksWidth * columnsCount) // prawa
        {
            API_VERTEX2F(select2_x, select1_y);
            API_VERTEX2F(select2_x, select2_y);
        }
        if (select1_x >= rightOffset) // lewa
        {
            API_VERTEX2F(select1_x, select2_y);
            API_VERTEX2F(select1_x, select1_y);
        }

        API_END();
    }

    // aktualnie modyfikowany step
    if (tracks->selectState && tracks->actualTrack >= firstTrack &&
        tracks->actualTrack < firstTrack + columnsCount)
    {
        uint16_t select_x =
          rightOffset + (tracks->actualTrack - firstTrack) * tracksWidth + 2;
        uint16_t select1_y = posY + stepHight * 7;
        uint16_t select2_y = select1_y + stepHight - 1;
        uint16_t select_w = tracksWidth - 5;
        uint16_t rect_select_x = 0;
        uint16_t rect_select_width = 0;

        if (paramCount == 1)
        {
            rect_select_x = select_x + oneParamsSelOffset[tracks->selectedParam];
            rect_select_width = oneParamsSelWidth[tracks->selectedParam];
        }
        else if (paramCount == 2)
        {
            uint8_t param = whichParamFromTwoSelected();
            rect_select_x = select_x + (param == 0 ? twoParamsSel1Offset[tracks->selectedParam]
                                                   : twoParamsSel2Offset[tracks->selectedParam]);
            rect_select_width = (param == 0 ? twoParamsSel1Width[tracks->selectedParam]
                                            : twoParamsSel2Width[tracks->selectedParam]);
        }
        else if (paramCount == 4)
        {
            rect_select_x = select_x + fourParamsSelOffset[tracks->selectedParam];
            rect_select_width = fourParamsSelWidth[tracks->selectedParam];
        }

        API_COLOR(selection_color);
        API_LINE_WIDTH(kRedFrameWidth);
        API_BEGIN(RECTS);
        API_VERTEX2F(rect_select_x, select1_y + 1);
        API_VERTEX2F(rect_select_x + rect_select_width - 1, select2_y - 1);
        API_END();

        // ramka tylko w okolo aktualnego stepa
        if (tracks->selectState == 1)
        {

            API_BEGIN(LINE_STRIP);

            /*
                    API_LINE_WIDTH(16);
                    API_VERTEX2F(rect_select_x-2, select1_y);
                    API_VERTEX2F(rect_select_x+rect_select_width, select1_y);
                    API_VERTEX2F(rect_select_x+rect_select_width, select2_y);
                    API_VERTEX2F(rect_select_x-2, select2_y);
                    API_VERTEX2F(rect_select_x-2, select1_y);
            */

            API_LINE_WIDTH(kRedFrameWidth);
            API_VERTEX2F(select_x, select1_y);
            API_VERTEX2F(select_x + select_w, select1_y);
            API_VERTEX2F(select_x + select_w, select2_y);
            API_VERTEX2F(select_x, select2_y);
            API_VERTEX2F(select_x, select1_y);

            API_END();
        }
    }
}

uint8_t cTracker::whichParamFromTwoSelected()
{
    if (displayMode & 1)
    {
        if (tracks->selectedParam == 0)
            return 0;
        else
            return 1;
    }
    else if (displayMode & 2)
    {
        if (tracks->selectedParam == 1)
            return 0;
        else
            return 1;
    }
    else if (displayMode & 4)
    {
        if (tracks->selectedParam == 2)
            return 0;
        else
            return 1;
    }

    return 1;
}

//-------------------------------------------------------------------------------------
// step number
void cTracker::drawRowNumbers(uint16_t* rowNumbers, bool showTrackEndLines)
{
    API_SAVE_CONTEXT();

    strFont* numFont = &fonts[0];

    API_COLOR(colors[16]);
    API_BITMAP_HANDLE(numFont->handle);
    API_BEGIN(BITMAPS);

    // show right row number column only if it's not obstructed
    uint8_t showRight = !((tracks->popupMode & 4) | (tracks->popupMode & 2));
    bool hexMode = isStyleSet(controlStyleHexNumbers);
    bool startFrom1 = isStyleSet(controlStyleStartNumbersFrom1);

    for (uint16_t i = 0; i < rowCount; i++)
    {
        if (rowNumbers[i] == 0)
        {
            continue;
        }

#ifdef TRACKER_MINI
        const unsigned division = tracks->stepDevider ? tracks->stepDevider : 1;
        const bool beat = (rowNumbers[i] - 1) % division == 0;
        API_COLOR(i == 7 && tracks->selectState ? bazill_cursor::color(tracks->selectColor,colors) : beat ? colors[0] : colors[16]);
#endif
        if (hexMode)
        {
            Number2HexBitmaps(3,
                              posY + (i * stepHight) + 12,
                              7,
                              numFont->height,
                              startFrom1 ? rowNumbers[i] : rowNumbers[i] - 1);
            if (showRight)
            {
                Number2HexBitmaps((799 - 23),
                                  posY + (i * stepHight) + 12,
                                  7,
                                  numFont->height,
                                  startFrom1 ? rowNumbers[i] : rowNumbers[i] - 1);
            }
        }
        else
        {
            Number2Bitmaps(3,
                           posY + (i * stepHight) + 12,
                           7,
                           numFont->height,
                           startFrom1 ? rowNumbers[i] : rowNumbers[i] - 1);
            if (showRight)
            {
                Number2Bitmaps((799 - 23),
                               posY + (i * stepHight) + 12,
                               7,
                               numFont->height,
                               startFrom1 ? rowNumbers[i] : rowNumbers[i] - 1);
            }
        }
    }
    API_END();

    // --------------------------------------------
    // track end lines

    if (showTrackEndLines)
    {
        API_COLOR(colors[20]);
        API_LINE_WIDTH(8);
        API_BEGIN(LINES);

        API_BLEND_FUNC(SRC_ALPHA, ZERO);

        for (uint16_t i = 1; i < rowCount; i++)
        {
            if (rowNumbers[i] == 1)
            {
                int trackEndLineY = posY + (i * stepHight);
                API_VERTEX2F(0, trackEndLineY);
                API_VERTEX2F(799, trackEndLineY);
            }
        }

        API_END();
    }

    API_RESTORE_CONTEXT();
}

//-------------------------------------------------------------------------------------
// tracks numbers
void cTracker::tracksNumbers()
{
    if (!tracks->showTrackNames)
    {
        return;
    }

    int16_t x, y, w, h;
    w = 24;
    h = 27;

    // pole/tlo
    y = posY; //-1

    // wyznaczanie najduższej nazwy

    API_LINE_WIDTH(24);
    API_BEGIN(RECTS);

    int textLetersCount[8]{};

    for (uint8_t i = 0; i < columnsCount; i++)
    {
        const int headerTrack = firstTrack + i;
        if (headerTrack < 0 || headerTrack >= tracks->kTrackCount || tracks->inactive[headerTrack])
            API_COLOR(colors[12]);
        else
#ifdef TRACKER_MINI
            API_COLOR(colors[1]);
#else
            API_COLOR(colors[19]);
#endif

        int trackIdx = firstTrack + i;
        const char* text = trackIdx >= 0 && trackIdx < tracks->kTrackCount && tracks->tracksNames[trackIdx]
                             ? tracks->tracksNames[trackIdx] : "";
        int letersCount = 0;
        while (letersCount < 7 && text[letersCount]) ++letersCount;
        w = getTextWidth((strFont*)font, text, letersCount);

        while (w > tracksWidth - 2)
        {
            if (letersCount > 1)
            {
                letersCount--;
            }
            else
            {
                break;
            }
            w = getTextWidth((strFont*)font, text, letersCount);
        }

        x = rightOffset + (i * tracksWidth) + 1;

        textLetersCount[i] = letersCount;

#ifdef TRACKER_MINI
        // The name is a header for the complete track, so clear the complete
        // existing header row; note/FX fragments must not leak past a short name.
        API_VERTEX2F(x, y);
        API_VERTEX2F(x + tracksWidth - 3, y + h);
#else
        API_VERTEX2F(x, y);
        API_VERTEX2F(x + w + 2, y + h);
#endif
    }

    API_END();

    // numer/nazwa
    y = posY + 12 - font->height / 2;
    actualColor = lastFontColor = colors[0];

    API_SAVE_CONTEXT();
    API_COLOR(actualColor);
    lastFontHandle = -1;
    API_BEGIN(BITMAPS);
#ifdef TRACKER_MINI
    // One bitmap batch for all names replaces8 nested SAVE/BEGIN/END pairs.
    // Explicit-font VERTEX2II plus a cached translation also saves right-side
    // CELL commands. Positions and variable advances remain unchanged.
    int nameTranslation=0;
    API_VERTEX_TRANSLATE_X(0);
#endif
    for (uint8_t i = 0; i < columnsCount; i++)
    {
        x = rightOffset + (i * tracksWidth) + 4;
        int trackIdx = firstTrack + i;
        const char* trackName = trackIdx >= 0 && trackIdx < tracks->kTrackCount && tracks->tracksNames[trackIdx]
                                  ? tracks->tracksNames[trackIdx] : "";
#ifdef TRACKER_MINI
        API_COLOR(breaklinePatternAccent(colors, trackIdx,
                  trackIdx < 0 || trackIdx >= tracks->kTrackCount || tracks->inactive[trackIdx]));
#endif
#ifdef TRACKER_MINI
        for(int letter=0;letter<textLetersCount[i];++letter) {
            unsigned code=static_cast<unsigned char>(trackName[letter]);
            if(code>=128)code='?';
            if(code!=' ' && font->data[code]) {
                const int offset=x>511?400:0;
                if(offset!=nameTranslation){API_VERTEX_TRANSLATE_X(offset*16);nameTranslation=offset;}
                API_VERTEX2II(x-offset,y,font->handle,code);
            }
            x+=font->data[code];
        }
#else
        string2Bitmaps(x, y, trackName, textLetersCount[i], false);
#endif
    }

    API_END();
    API_RESTORE_CONTEXT();
#ifdef TRACKER_MINI
    API_SAVE_CONTEXT();
    API_LINE_WIDTH(16);
    API_BEGIN(RECTS);
    for (uint8_t i = 0; i < columnsCount; ++i)
    {
        const int track = firstTrack + i;
        if (track < 0 || track >= tracks->kTrackCount) continue;
        const int x = rightOffset + i * tracksWidth + 3;
        API_COLOR(breaklinePatternAccent(colors, track, tracks->inactive[track]));
        API_VERTEX2F(x, posY + 25);
        API_VERTEX2F(x + 14, posY + 26);
        API_VERTEX2F(x + 20, posY + 25);
        API_VERTEX2F(x + tracksWidth - 6, posY + 26);
    }
    API_END();
    API_RESTORE_CONTEXT();
#endif
}

//===============================================================================================================================
void cTracker::notes()
{
    API_SAVE_CONTEXT();
#ifdef TRACKER_MINI
    glyphTranslate=0; API_VERTEX_TRANSLATE_X(0);
#endif
    API_COLOR(colors[2]);
    actualColor = lastFontColor = colors[2];
    // API_BITMAP_HANDLE(fonts[1].handle);
    lastFontHandle = -1;
    API_BEGIN(BITMAPS);

    uint8_t offset_y = posY + 12;
    uint8_t offset_x = rightOffset + fourParamsOffset[0];

    // if(paramCount == 1) 		offset_x = 27 + ((tracksSpace/2)-(param_length[1]*12)/2);
    if (paramCount == 1)
        offset_x = rightOffset + oneParamsOffset[0];
    else if (paramCount == 2)
        offset_x = rightOffset + twoParamsOffsetFirst[0];

    int8_t mark = -1;
    if ((tracks->selectedParam == 0 /*|| tracks->selectedParam == 4*/) && tracks->selectState)
    {
        mark = tracks->actualTrack - firstTrack;
    }

    for (uint16_t i = 0; i < columnsCount; i++)
    {
        for (uint16_t j = 0; j < rowCount; j++)
        {
            int16_t param_x = offset_x + i * tracksWidth;
            int16_t param_y = offset_y + j * stepHight;

            char* text = tracks->track[firstTrack + i].row[j].note;

            if (selectActive && mark >= 0 && param_x > select1_x && param_x < select2_x &&
                param_y > select1_y && param_y < select2_y)
                actualColor = colors[14];
            else if (j == 7 && i == mark)
                actualColor = colors[14];
            else
            {
                if (tracks->inactive[firstTrack + i])
#ifdef TRACKER_MINI
                    actualColor = breaklinePatternMix(colors[0], colors[1], 10);
#else
                    actualColor = colors[12];
#endif
                else if (*text == '-')
                    actualColor = colors[6];
                else
                    actualColor = colors[2];
            }

            String2Bitmaps(param_x, param_y, &fonts[text_font], text, param_length[0]);
        }
    }
    API_END();
    API_RESTORE_CONTEXT();
}

//===============================================================================================================================
void cTracker::instruments()
{
    API_SAVE_CONTEXT();
#ifdef TRACKER_MINI
    glyphTranslate=0; API_VERTEX_TRANSLATE_X(0);
#endif
    API_COLOR(colors[3]);
    actualColor = lastFontColor = colors[3];
    // API_BITMAP_HANDLE(fonts[1].handle);
    lastFontHandle = -1;
    API_BEGIN(BITMAPS);

    uint8_t offset_y = posY + 12;
    uint8_t offset_x = rightOffset + fourParamsOffset[1]; // 59
    if (paramCount == 1)
        offset_x = rightOffset + oneParamsOffset[1];
    else if (paramCount == 2)
        offset_x = (displayMode & 1) ? rightOffset + twoParamsOffsetSecond[1]
                                     : rightOffset + twoParamsOffsetFirst[1];

    int8_t mark = -1;
    if ((tracks->selectedParam == 1 /*|| tracks->selectedParam == 4*/) && tracks->selectState)
    {
        mark = tracks->actualTrack - firstTrack;
    }

    for (uint16_t i = 0; i < columnsCount; i++)
    {
        uint8_t track = firstTrack + i;
        for (uint16_t j = 0; j < rowCount; j++)
        {
            int16_t param_x = offset_x + i * tracksWidth;
            int16_t param_y = offset_y + j * stepHight;
            // uint8_t midi_channel  =  tracks->track[track].row[j].instr[3];
            char* text = tracks->track[track].row[j].instr;
            if (selectActive && mark >= 0 && param_x > select1_x && param_x < select2_x &&
                param_y > select1_y && param_y < select2_y)
                actualColor = colors[14];
            else if (j == 7 && i == mark)
                actualColor = colors[14];
            else
            {
                if (tracks->inactive[track])
#ifdef TRACKER_MINI
                    actualColor = breaklinePatternMix(colors[0], colors[1], 10);
#else
                    actualColor = colors[12];
#endif
                else if (*text == '-')
                    actualColor = colors[7];
                else
                    actualColor = colors[3];
            }

            if (tracks->track[track].row[j].instr[2] > 0)
            {
                String2Bitmaps(param_x - (fonts[0].data['M'] - 6),
                               param_y,
                               &fonts[0],
                               text,
                               param_length[1] + 1);
            }
            else
            {
                String2Bitmaps(param_x, param_y, &fonts[text_font], text, param_length[1]);
            }
        }
    }
    API_END();
    API_RESTORE_CONTEXT();
}

//===============================================================================================================================
void cTracker::fxes1()
{
    API_SAVE_CONTEXT();
#ifdef TRACKER_MINI
    glyphTranslate=0; API_VERTEX_TRANSLATE_X(0);
#endif
    API_COLOR(colors[4]);
    actualColor = lastFontColor = colors[4];
    lastFontHandle = -1;
    // API_BITMAP_HANDLE(fonts[1].handle);
    API_BEGIN(BITMAPS);

    uint8_t offset_y = posY + 12;
    uint8_t offset_x = rightOffset + fourParamsOffset[2]; // 99
    if (paramCount == 1)
        offset_x = rightOffset + oneParamsOffset[2];
    else if (paramCount == 2)
        offset_x = (displayMode & 8) ? rightOffset + twoParamsOffsetFirst[2]
                                     : rightOffset + twoParamsOffsetSecond[2];

    int8_t mark = -1;
    if ((tracks->selectedParam == 2 /*|| tracks->selectedParam == 4*/) && tracks->selectState)
    {
        mark = tracks->actualTrack - firstTrack;
    }

    for (uint16_t i = 0; i < columnsCount; i++)
    {
        for (uint16_t j = 0; j < rowCount; j++)
        {

            int16_t param_x = offset_x + i * tracksWidth;
            int16_t param_y = offset_y + j * stepHight;
            char* text = &tracks->track[firstTrack + i].row[j].fx[0][0];

            if (selectActive && mark >= 0 && param_x > select1_x && param_x < select2_x &&
                param_y > select1_y && param_y < select2_y)
                actualColor = colors[14];
            else if (j == 7 && i == mark)
                actualColor = colors[14];
            else
            {
                if (tracks->inactive[firstTrack + i])
#ifdef TRACKER_MINI
                    actualColor = breaklinePatternMix(colors[0], colors[1], 10);
#else
                    actualColor = colors[12];
#endif
                else if (*text == '-')
                    actualColor = colors[8];
                else
                    actualColor = colors[4];
            }
            String2Bitmaps(param_x, param_y, &fonts[text_font], text, param_length[3]);
        }
    }
    API_END();
    API_RESTORE_CONTEXT();
}
void cTracker::fxes2()
{
    API_SAVE_CONTEXT();
#ifdef TRACKER_MINI
    glyphTranslate=0; API_VERTEX_TRANSLATE_X(0);
#endif
    API_COLOR(colors[5]);
    actualColor = lastFontColor = colors[5];
    lastFontHandle = -1;
    // API_BITMAP_HANDLE(fonts[1].handle);
    API_BEGIN(BITMAPS);

    uint8_t offset_y = posY + 12;
    uint8_t offset_x = rightOffset + fourParamsOffset[3];
    if (paramCount == 1)
        offset_x = rightOffset + oneParamsOffset[3];
    else if (paramCount == 2)
        offset_x = rightOffset + twoParamsOffsetSecond[3];

    int8_t mark = -1;
    if ((tracks->selectedParam == 3 /*|| tracks->selectedParam == 4*/) && tracks->selectState)
    {
        mark = tracks->actualTrack - firstTrack;
    }

    for (uint16_t i = 0; i < columnsCount; i++)
    {
        for (uint16_t j = 0; j < rowCount; j++)
        {

            int16_t param_x = offset_x + i * tracksWidth;
            int16_t param_y = offset_y + j * stepHight;
            char* text = &tracks->track[firstTrack + i].row[j].fx[1][0];

            if (selectActive && mark >= 0 && param_x > select1_x && param_x < select2_x &&
                param_y > select1_y && param_y < select2_y)
                actualColor = colors[14];
            else if (j == 7 && i == mark)
                actualColor = colors[14];
            else
            {
                if (tracks->inactive[firstTrack + i])
#ifdef TRACKER_MINI
                    actualColor = breaklinePatternMix(colors[0], colors[1], 10);
#else
                    actualColor = colors[12];
#endif
                else if (*text == '-')
                    actualColor = colors[9];
                else
                    actualColor = colors[5];
            }

            String2Bitmaps(param_x, param_y, &fonts[text_font], text, param_length[3]);
        }
    }
    API_END();
    API_RESTORE_CONTEXT();
}
//===============================================================================================================================
//===============================================================================================================================
//===============================================================================================================================
static inline void draw_char(uint16_t x, uint16_t y, uint8_t charr)
{
    if (x > 511 || y > 511)
    {
        API_CELL(charr);
        API_VERTEX2F(x, y);
    }
    else
    {
        API_VERTEX2II(x, y, fonts[0].handle, charr);
    }
}

/*
Note: this is not cDisplayControl::string2Bitmaps

This one has support for multiple fonts and optimizations for switching bitmap handles only
when necessary.
*/
void cTracker::String2Bitmaps(int16_t x,
                              int16_t y,
                              const strFont* font,
                              char* string,
                              int8_t length,
                              int16_t w_limit)
{
    uint32_t drawColor=actualColor;
#ifdef TRACKER_MINI
    // Resolve placeholder colour before sending a colour opcode. Consecutive
    // empty cells share a single colour state instead of toggling it twice.
    bool empty = length >= 2 && length <= 4;
    for (int i=0; empty && i<length; ++i) empty = string[i]=='-';
    char emptyMarker[2] = {'.',0};
    if (empty) {
        drawColor=breaklinePatternMix(colors[1],actualColor,7);
        x += (length-1)*11/2; string=emptyMarker; length=1;
    }
#endif
    if (drawColor != lastFontColor) {API_COLOR(drawColor);lastFontColor=drawColor;}
    if (lastFontHandle != font->handle) {API_BITMAP_HANDLE(font->handle);lastFontHandle=font->handle;}

    w_limit += x;
    y = y - font->height / 2;
    uint8_t strPtr = 0;

    x += fonts[1].width - font->width; // text_font

    unsigned char ch;
    for (uint8_t i = 0; i < length; i++)
    {
        ch = string[strPtr++];
        if (ch == 0 || x > w_limit)
            return;

        if (0 <= x && x <= 799 && 0 <= y && y <= 479)
        {
#ifdef TRACKER_MINI
            // ASCII space has no ink in the supported font families. Keep its
            // advance but omit the empty GPU glyph (up to240 words in 8xFX).
            if (font->data[ch] && ch != ' ') {
                // FT81x vertex translation applies to VERTEX2II as well as
                // VERTEX2F, in1/16px. Cache the offset per drawing stage so
                // right-side text needs one instruction per glyph too.
                // Bridgetek BRT_AN_014, section on VERTEX_TRANSLATE.
                const uint16_t translated=x>511?400:0;
                if (translated!=glyphTranslate) {
                    API_VERTEX_TRANSLATE_X(translated*16u);glyphTranslate=translated;
                }
                API_VERTEX2II(x-translated,y,font->handle,ch);
            }
#else
            if ((x > 511 || y > 511) && font->data[ch])
            {
                API_CELL(ch);
                API_VERTEX2F(x, y);
            }
            else if (font->data[ch])
            {
                API_VERTEX2II(x, y, font->handle, ch);
            }
#endif
        }

        // if(font == &fonts[0])
        if (string[0] == '-' && string[1] == '-')
        {
            x += 11; // font->data['8'];
        }
        else
        {
            x += font->data[ch];
            // x += font->data['C'];
        }
    }
}

static void Number2HexBitmaps(int16_t x, int16_t y, uint8_t font_x, uint8_t font_y, int16_t number)
{
    y = y - font_y / 2;
    uint8_t digit, ascii_offset;

    if (number < 0)
    {
        number *= -1;
        draw_char(x, y, 45);
        x += font_x;
    }

    // note: only prints the last two hex digits of the number (00-FF)
    number = number % 256;
    digit = number / 16;
    number = number % 16;

    // Xx
    ascii_offset = digit > 9 ? 55 : 48;
    draw_char(x, y, digit + ascii_offset);
    x += font_x;

    // xX
    ascii_offset = number > 9 ? 55 : 48;
    draw_char(x, y, number + ascii_offset);
}

static void Number2Bitmaps(int16_t x, int16_t y, uint8_t font_x, uint8_t font_y, int16_t number)
{
    y = y - font_y / 2;
    uint8_t digit, flag = 0;

    if (number < 0)
    {
        number = number * (-1);
        draw_char(x, y, 45);
        x += font_x;
    }

    //	digit =  number/10000;
    //	number = number%10000;
    //	if(digit > 0) {draw_char(x,y,digit+48); x+=font_x; flag = 1;}

    //	digit =  number/1000;
    //	number = number%1000;
    //	if(digit > 0 || flag) {draw_char(x,y,digit+48); x+=font_x; flag = 1;}

    digit = number / 100;
    number = number % 100;
    if (digit > 0 || flag)
    {
        draw_char(x, y, digit + 48);
        x += font_x - 1;
        flag = 1;
    } // skrocony odstep po 1

    digit = number / 10;
    number = number % 10;
    if (digit > 0 || flag)
    {
        draw_char(x, y, digit + 48);
        x += font_x;
        flag = 1;
    }

    draw_char(x, y, number + 48);
}
