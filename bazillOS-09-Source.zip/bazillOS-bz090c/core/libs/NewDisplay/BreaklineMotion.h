#pragma once
#include <stdint.h>

// Volatile UI preference only: no project/config-file layout or audio state.
namespace breakline_motion {
enum class Mode : uint8_t { off = 0, reduced = 1, full = 2 };
Mode mode() noexcept;
void setMode(Mode value) noexcept;
uint32_t nowMs() noexcept;
uint32_t mix(uint32_t a, uint32_t b, unsigned amount) noexcept;

struct Bounds { int16_t left = 0, right = 0; };
class FocusTransition {
public:
    void begin(Bounds from, Bounds to, uint32_t now, uint16_t duration = 144) noexcept
    {
        from_ = from; to_ = to; current_ = from; started_ = now;
        duration_ = duration ? duration : 1; frames_ = 0;
        active_ = mode() == Mode::full && (from.left != to.left || from.right != to.right);
        if (!active_) current_ = to_;
    }
    Bounds advance(uint32_t now) noexcept
    {
        if (!active_ || mode() != Mode::full) { active_ = false; return current_ = to_; }
        const uint32_t elapsed = now - started_; // wrap-safe for bounded UI duration
        // The existing GPU/display queue supplies refresh cadence. A hard frame
        // cap also terminates the effect if the clock stops during debugging.
        if (elapsed >= duration_ || ++frames_ >= 12) { active_ = false; return current_ = to_; }
        const int32_t p = static_cast<int32_t>(elapsed * 256 / duration_);
        const int32_t remaining = 256 - p;
        const int32_t eased = 256 - remaining * remaining * remaining / 65536;
        current_.left = static_cast<int16_t>(from_.left + (to_.left - from_.left) * eased / 256);
        current_.right = static_cast<int16_t>(from_.right + (to_.right - from_.right) * eased / 256);
        return current_;
    }
    Bounds current() const noexcept { return current_; }
    bool active() const noexcept { return active_; }
    void finish() noexcept { active_ = false; current_ = to_; }
private:
    Bounds from_{}, to_{}, current_{};
    uint32_t started_ = 0;
    uint16_t duration_ = 144;
    uint8_t frames_ = 0;
    bool active_ = false;
};
} // namespace breakline_motion
