// SPDX-License-Identifier: MIT
// Schematic control-driven demo graphics, not measured audio waveforms.
// All vertices stay in the unused card band below the two text rows.
#pragma once
#include "breakline/punch_visuals.hpp"
namespace bazill_punch_visuals {
inline uint32_t ink(unsigned bank) {
 static constexpr uint32_t colors[]={0xAEED76,0x6CE6E2,0xC6A4F4,0xE8A5C8,0x7BD9DE,0xE9C879,0x82E9BC,0xE7B1DB};
 return colors[bank%8];
}
inline void strip(unsigned phase,uint32_t color) {
 API_SAVE_CONTEXT();API_COLOR(color);API_COLOR_A(90);API_LINE_WIDTH(8);API_BEGIN(LINE_STRIP);
 for(unsigned i=0;i<12;++i)API_VERTEX2F(26+int(i)*67,141+triangle(phase+i*4,24,4));
 API_END();API_RESTORE_CONTEXT();
}
inline void band(unsigned recipe,int x,int y,unsigned phase,bool moving,uint32_t color) {
 if(!moving)phase=0;
 const auto type=kind(recipe);const int left=x+11,top=y+63,width=154,cy=top+11;
 API_SAVE_CONTEXT();API_COLOR(color);API_COLOR_A(moving?200:135);API_LINE_WIDTH(16);
 if(type==Kind::dust) {
  API_BEGIN(RECTS);
  for(unsigned i=0;i<5;++i){unsigned seed=(recipe+1)*193+i*137+phase*29;seed^=seed>>3;
   const int px=left+int(seed%147),py=top+int((seed>>7)%17);API_VERTEX2F(px,py);API_VERTEX2F(px+3,py+2);}
 } else if(type==Kind::roll) {
  API_BEGIN(LINES);
  for(unsigned i=0;i<3;++i){const int d=int((phase+i*8)%24);const int l=left+d*2,r=left+width-d*2,t=top+d/3,b=top+22-d/3;
   API_VERTEX2F(l,t);API_VERTEX2F(r,t);API_VERTEX2F(l,b);API_VERTEX2F(r,b);}
 } else if(type==Kind::echo) {
  API_BEGIN(LINES);
  for(unsigned i=0;i<5;++i){const int px=left+int((phase*2+i*29)%148),h=10-int(i)*2;API_VERTEX2F(px,cy-h);API_VERTEX2F(px,cy+h);}
 } else if(type==Kind::room) {
  API_BEGIN(LINE_STRIP);
  for(unsigned i=0;i<2;++i){const int w=24+int((phase+i*12)%24)*2,h=4+int((phase+i*12)%12)/2;
   API_VERTEX2F(left+77-w,cy);API_VERTEX2F(left+77,cy-h);API_VERTEX2F(left+77+w,cy);API_VERTEX2F(left+77,cy+h);API_VERTEX2F(left+77-w,cy);}
 } else if(type==Kind::reverse) {
  API_BEGIN(LINES);
  for(unsigned i=0;i<3;++i){const int px=left+12+int((i*45+144-phase*3)%130);API_VERTEX2F(px+10,top+2);API_VERTEX2F(px,cy);API_VERTEX2F(px,cy);API_VERTEX2F(px+10,top+20);}
 } else if(type==Kind::cut) {
  API_BEGIN(LINES);
  for(unsigned i=0;i<6;++i){const int px=left+int(i)*25+int(phase%3);API_VERTEX2F(px,top+20);API_VERTEX2F(px+12,top+2);}
 } else if(type==Kind::orbit) {
  static constexpr int8_t px[]={-1,0,1,1,1,0,-1,-1,-1},py[]={0,-1,-1,0,1,1,1,0,0};
  API_BEGIN(LINE_STRIP);for(unsigned i=0;i<9;++i){unsigned n=(i+phase/3)%8;API_VERTEX2F(left+77+px[n]*62,cy+py[n]*8);}
 } else if(type==Kind::filter) {
  API_BEGIN(LINE_STRIP);for(unsigned i=0;i<9;++i)API_VERTEX2F(left+int(i)*19,cy+triangle(phase+i*3,24,8-int(i)/2));
 } else {
  API_BEGIN(LINE_STRIP);for(unsigned i=0;i<9;++i)API_VERTEX2F(left+int(i)*19,top+3+int((i*3+phase)%17));
 }
 API_END();API_RESTORE_CONTEXT();
}
} // namespace bazill_punch_visuals
