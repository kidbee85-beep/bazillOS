// SPDX-License-Identifier: MIT
#pragma once
#include <cstdint>
#include <cstddef>
namespace bazill_text {
struct Face {const uint8_t* advances;unsigned cellWidth,height;};
struct Run {char text[160]{};unsigned face=0,count=0,pixels=0;};
inline unsigned fit(const Face& f,const char* text,unsigned count,unsigned width,unsigned* pixels=nullptr){
 unsigned pen=0,ink=0,n=0;
 for(;n<count;++n){
  const unsigned code=static_cast<unsigned char>(text[n]);
  const unsigned advance=code<128?f.advances[code]:0;
  const unsigned end=pen+f.cellWidth;
  if(end>width)break;
  if(end>ink)ink=end;
  pen+=advance;
 }
 if(pixels)*pixels=ink;return n;
}
// Cached UI drawing only. Three faces: requested, normal body, micro.
// A fixed stack buffer prevents UTF-8 bytes becoming out-of-range font cells.
inline Run bounded(const Face (&faces)[3],const char* source,unsigned width){
 Run r;if(!source||!width)return r;bool symbols=false;
 for(size_t i=0;source[i]&&r.count<sizeof(r.text)-1;){
  unsigned code=static_cast<unsigned char>(source[i++]);
  if(code>=128){while((static_cast<unsigned char>(source[i])&192)==128)++i;code='?';}
  if(code<17||code==127||!faces[0].advances[code])code=code=='\t'?' ':'?';
  symbols|=code<32;r.text[r.count++]=static_cast<char>(code);
 }
 unsigned best=fit(faces[0],r.text,r.count,width);
 if(!symbols)for(unsigned i=1;i<3;++i){
  if(faces[i].height>faces[0].height)continue;
  const unsigned n=fit(faces[i],r.text,r.count,width);
  if(n>best){best=n;r.face=i;}
  if(best==r.count)break;
 }
 if(best<r.count){
  r.count=best;
  if(best>=3){r.text[best-1]='.';r.text[best-2]='.';r.text[best-3]='.';}
  r.text[r.count]=0;
 }
 r.count=fit(faces[r.face],r.text,r.count,width,&r.pixels);
 r.text[r.count]=0;return r;
}
} // namespace bazill_text
