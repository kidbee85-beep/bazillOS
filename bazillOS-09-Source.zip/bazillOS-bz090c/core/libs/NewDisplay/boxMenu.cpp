
#include "FT812.h"

#include "boxMenuControl.h"
#include "display.h"
#ifdef TRACKER_MINI
#include "BazillSurface.h"
#endif

#include <string.h>
#include <cstdio>

cBoxMenu::cBoxMenu(strControlProperties* properties)
  : cDisplayControl(controlIdBoxMenu, 1)
{
    colorsCount = 7;
    colors = display.getTheme().miniBoxMenuColors;

    if (properties == nullptr)
    {
        posX = 0;
        posY = 0;
        text = nullptr;
        data = nullptr;
        width = 0;
        height = 0;
        style = 0;
        value = 0;
        return;
    }

    colors = (properties->colors == nullptr) ? colors : properties->colors;

    posX = properties->x;
    posY = properties->y;

    text = properties->text;

    value = properties->value;

    data = (strBoxMenuData*)(properties->data);

    width = properties->w;
    height = properties->h;

    setStyle(properties->style);
}

cBoxMenu::~cBoxMenu()
{
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
void cBoxMenu::setStyle(uint32_t style)
{
    this->style = style;

    textStyle = (style & controlStyleCenterX ? OPT_CENTERX : 0) |
                (style & controlStyleCenterY ? OPT_CENTERY : 0) |
                (style & controlStyleRightX ? OPT_RIGHTX : 0);

    int8_t textFont = FONT_INDEX_FROM_STYLE;
    textFont = (textFont >= 0) ? textFont : 0;
    font = &fonts[textFont];
}

void cBoxMenu::setText(const char* text)
{
    this->text = text;
}

void cBoxMenu::setValue(int value)
{
    this->value = value;
}

void cBoxMenu::setColors(const uint32_t* colors)
{
    this->colors = colors;
}

void cBoxMenu::setData(void* data)
{
    this->data = (strBoxMenuData*)(data);
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------

#ifdef TRACKER_MINI
// Original bazillOS menu skin. Fixed geometry and batched sprite commands:
// no timers, allocation, extra bitmap storage, or changes to menu routing.
static void drawCultureIndex(const strBoxMenuData& data, int selected,
                             int x, int y, int width, int height,
                             const strFont* font)
{
    constexpr int gap = 4, chrome = 24;
    const int cardW = (width - (data.columnsCount + 1) * gap) / data.columnsCount;
    const int cardH = (height - chrome - (data.rowsCount + 1) * gap) / data.rowsCount;
    const int count = data.columnsCount * data.rowsCount;
    if (selected < 0 || selected >= count) selected = 0;
    const auto cardX = [&](int i) { return x + gap + (i % data.columnsCount) * (cardW + gap); };
    const auto cardY = [&](int i) { return y + chrome + gap + (i / data.columnsCount) * (cardH + gap); };
    constexpr uint32_t dark = 0x060A09, acid = 0xA7ED32, ink = 0xD9EEA9;
    constexpr uint32_t paper = 0xB9CBB3, pink = 0xCB366D;
    constexpr uint32_t beds[6] = {0x111B14, 0x101B19, 0x19181B, 0x141B19, 0x1B1C14, 0x101A1A};

    API_SAVE_CONTEXT();
    API_COLOR_A(255); API_COLOR(dark); API_BEGIN(RECTS);
    API_VERTEX2F(x, y); API_VERTEX2F(x + width, y + height); API_END();

    // Acid outline, charcoal cards and six near-black culture tints. A displaced shadow and cut
    // corners replace the uniform stock rectangles without moving text.
    API_BEGIN(RECTS);
    for (int i = 0; i < count; ++i) {
        const int cx = cardX(i), cy = cardY(i);
        API_COLOR(i == selected ? pink : 0x030508);
        API_VERTEX2F(cx + 3, cy + 3); API_VERTEX2F(cx + cardW, cy + cardH);
        API_COLOR(i == selected ? 0x26391A : beds[i % 6]);
        API_VERTEX2F(cx + 1, cy + 1); API_VERTEX2F(cx + cardW - 3, cy + cardH - 3);
    }
    API_END();
    bazill_surface::texture(x, y + chrome, width, height - chrome, 0x94AC71, 20);

    // Two offset corner traces and short hatch marks stay away from labels
    // and subpage dots. All cards share one primitive batch.
    API_LINE_WIDTH(8); API_BEGIN(LINES);
    for (int i = 0; i < count; ++i) {
        const int cx = cardX(i), cy = cardY(i);
        API_COLOR(i == selected ? acid : 0x657B53);
        API_COLOR_A(i == selected ? 230 : 155);
        API_VERTEX2F(cx + 2, cy + 8); API_VERTEX2F(cx + 13, cy + 1);
        API_VERTEX2F(cx + cardW - 3, cy + cardH - 9); API_VERTEX2F(cx + cardW - 16, cy + cardH - 3);
        for (int k = 0; k < (i == selected || i >= 12 ? 3 : 0); ++k) {
            API_VERTEX2F(cx + 6 + k * 5, cy + cardH - 6);
            API_VERTEX2F(cx + 11 + k * 5, cy + cardH - 13);
        }
    }
    API_END(); API_COLOR_A(255);

    // Reuse the existing 24px sprites. Set common bitmap state once for all
    // 20 tiles instead of paying a full state block for every creature.
    API_SAVE_CONTEXT(); API_BLEND_FUNC(SRC_ALPHA, ONE_MINUS_SRC_ALPHA);
    API_BITMAP_HANDLE(0); API_CELL(0);
    API_BITMAP_LAYOUT(L4, 12, 24); API_BITMAP_LAYOUT_H(0, 0); API_BITMAP_SIZE_H(0, 0);
    API_BITMAP_SIZE(NEAREST, BORDER, BORDER, 24, 24); API_BEGIN(BITMAPS);
    for (int i = 0; i < count; ++i) {
        API_COLOR(i == selected ? acid : 0x657B53);
        API_BITMAP_SOURCE(bazill_surface::mascotAddress +
          ((i % 6) * 2 + (i == selected ? 0 : 1)) * bazill_surface::mascotBytes);
        API_VERTEX2F(cardX(i) + cardW - 31, cardY(i) + 2);
    }
    API_END(); API_RESTORE_CONTEXT();

    API_COLOR(pink);
    API_CMD_TEXT(x + 8, y + 4, fonts[0].handle, 0, "bazillOS // SIGNAL CULT");
    API_COLOR(0x91A58B);
    const char* groups[]={"SAMPLES","INSTRUMENTS","ARRANGE / LIVE","PROJECT / ANALYSIS"};
    char hint[96];std::snprintf(hint,sizeof hint,"%s / +/- VIEW / MIDDLE OPEN",groups[selected/5]);
    API_CMD_TEXT(x + 296, y + 6, fonts[4].handle, 0, hint);
    char position[12]; std::snprintf(position, sizeof position, "%02d/%02d", selected + 1, count);
    API_COLOR(acid); API_CMD_TEXT(x + width - 8, y + 4, fonts[0].handle, OPT_RIGHTX, position);

    // Fixed two-digit stamps share font state. VERTEX2F supports the whole
    // 800px viewport; VERTEX2II would wrap x coordinates beyond 511px.
    API_SAVE_CONTEXT(); API_BITMAP_HANDLE(fonts[4].handle); API_BEGIN(BITMAPS);
    for (int i = 0; i < count; ++i) {
        API_COLOR(i == selected ? acid : 0x657B53);
        API_CELL('0' + (i + 1) / 10); API_VERTEX2F(cardX(i) + 9, cardY(i) + 6);
        API_CELL('0' + (i + 1) % 10); API_VERTEX2F(cardX(i) + 9 + fonts[4].data['0'], cardY(i) + 6);
    }
    API_END(); API_RESTORE_CONTEXT();

    for (int i = 0; i < count; ++i) {
        const int cx = cardX(i), cy = cardY(i);
        if (!data.textList[i]) continue;
        const char* title = data.textList[i];
        int length = strlen(title);
        const char* split = nullptr;
        int ty = cy + cardH / 2;
        if (getTextWidth(font, title, length) + 12 > cardW) {
            split = strchr(title, ' ');
            if (split) { length = split - title; ty -= font->height / 2; }
        }
        API_COLOR(i == selected ? ink : paper);
        API_CMD_TEXT(cx + cardW / 2, ty, font->handle, OPT_CENTERX | OPT_CENTERY, title, length);
        if (split) API_CMD_TEXT(cx + cardW / 2, ty + font->height, font->handle,
                                OPT_CENTERX | OPT_CENTERY, split + 1);
    }

    // Bright current-page dot and muted companion dots. Page
    // selection and persistent Menu behavior remain in InterfaceMenuPopup.
    API_POINT_SIZE(48); API_BEGIN(FTPOINTS);
    if (data.modes) for (int i = 0; i < count; ++i) {
        if (!data.modes[i] || data.modes[i]->count == 0) continue;
        const unsigned pages = data.modes[i]->count > 8 ? 8 : data.modes[i]->count;
        const int start = cardX(i) + cardW / 2 - (pages - 1) * 10 / 2;
        for (unsigned page = 0; page < pages; ++page) {
            API_COLOR(page == data.modes[i]->current ? (i == selected ? ink : acid) :
                       (i == selected ? 0x61783D : 0x536B51));
            API_VERTEX2F(start + page * 10, cardY(i) + cardH - 11);
        }
    }
    API_END();
    bazill_surface::faultFrame(cardX(selected), cardY(selected), cardW - 1, cardH - 1, pink, 255);
    API_RESTORE_CONTEXT();
}
#endif

void cBoxMenu::update()
{
    if (data == nullptr || data->textList == nullptr || data->columnsCount == 0 || data->rowsCount == 0)
    {
        return;
    }
#ifdef TRACKER_MINI
    if (data->columnsCount == 5 && data->rowsCount == 4 && width >= 560 && height >= 340) {
        drawCultureIndex(*data, value, posX, posY, width, height, font);
        return;
    }
#endif

    int colorIdx = -1;
    int boxSpacing = 3;
    int chromeHeight=0;
#ifdef TRACKER_MINI
    if (data->columnsCount>=4 && data->rowsCount>=3 && width>=560 && height>=340) chromeHeight=24;
#endif
    const int gridY=posY+chromeHeight;
    int boxW = (width - ((data->columnsCount + 1) * boxSpacing)) / data->columnsCount;
    int boxH = (height - chromeHeight - ((data->rowsCount + 1) * boxSpacing)) / data->rowsCount;
    int frameX = posX;
    int frameY = posY;

    API_SAVE_CONTEXT();
#ifdef TRACKER_MINI
    if(chromeHeight) {
        bazill_surface::texture(0,29,800,391,0x8797BB,42);
        bazill_surface::watermark(5,45,0,84,56);
        bazill_surface::watermark(710,42,2,84,50);
        bazill_surface::watermark(0,306,4,112,44);
        bazill_surface::watermark(704,306,6,96,44);
    }
#endif

    // bg

    API_COLOR(colors[3]);
    API_BEGIN(RECTS);
    API_VERTEX2F(posX, posY);
    API_VERTEX2F(posX + boxSpacing + (boxSpacing + boxW) * data->columnsCount,
                 posY + height);

#ifdef TRACKER_MINI
    if(chromeHeight) {
        API_COLOR(0x080510);
        for(int row=0;row<data->rowsCount;++row)for(int column=0;column<data->columnsCount;++column) {
            const int x=posX+boxSpacing+(boxSpacing+boxW)*column;
            const int y=gridY+boxSpacing+(boxSpacing+boxH)*row;
            API_VERTEX2F(x+4,y+4);API_VERTEX2F(x+boxW+3,y+boxH+3);
        }
    }
#endif
    // squares

    for (int column = 0; column < data->columnsCount; column++)
    {
        for (int row = 0; row < data->rowsCount; row++)
        {
            int currentBoxIdx = row * data->columnsCount + column;
            int curentColorIdx = currentBoxIdx == value ? 2 : 1;

            if (colorIdx != curentColorIdx)
            {
                colorIdx = curentColorIdx;
                API_COLOR(colors[colorIdx]);
            }

            int boxX = posX + boxSpacing + (boxSpacing + boxW) * column;
            int boxY = gridY + boxSpacing + (boxSpacing + boxH) * row;

#ifdef TRACKER_MINI
            if(chromeHeight) {
                API_VERTEX2F(boxX+2,boxY+2);API_VERTEX2F(boxX+boxW-2,boxY+boxH-2);
            } else
#endif
            {
                API_VERTEX2F(boxX, boxY);
                API_VERTEX2F(boxX + boxW, boxY + boxH);
            }

            if (currentBoxIdx == value)
            {
                frameX = boxX;
                frameY = boxY;
            }
        }
    }

    API_END();

#ifdef TRACKER_MINI
    bazill_surface::texture(posX,posY,width,height,0x8B9CC0,38);
    for (int row=0;row<data->rowsCount;++row) for(int column=0;column<data->columnsCount;++column) {
        const int index=row*data->columnsCount+column;
        if (!data->textList[index] || boxW<96 || boxH<80) continue;
        const int x=posX+boxSpacing+(boxSpacing+boxW)*column;
        const int y=gridY+boxSpacing+(boxSpacing+boxH)*row;
        const unsigned species=index%6;
        const uint32_t color=bazill_surface::speciesColors[species];
        bazill_surface::menuMascot(x+boxW-42,y+3,species*2+(index==value?0:1),color,index==value?235:140);
        if(index==value || index>=12)
            bazill_surface::scars(x+1,y+1,boxW-2,boxH-2,color,index==value?190:130);
        // Scars, tint and mascots identify the dedicated tools. One focused
        // outline keeps all20 cards within the GPU command FIFO.

    }
#endif
#ifdef TRACKER_MINI
    if(chromeHeight) {
        API_SAVE_CONTEXT();
        API_COLOR(colors[0]); API_COLOR_A(185);
        API_CMD_TEXT(posX+8,posY+4,fonts[0].handle,0,"ARROWS SELECT / +/- PAGE / MIDDLE OPEN / MENU BACK");
        char position[20];std::snprintf(position,sizeof position,"%02d / %02u",value+1,unsigned(data->columnsCount)*data->rowsCount);
        API_CMD_TEXT(posX+width-8,posY+4,fonts[0].handle,OPT_RIGHTX,position);
        API_RESTORE_CONTEXT();
    }
#endif
#ifdef TRACKER_MINI
    if(chromeHeight) {
        API_SAVE_CONTEXT();API_COLOR(0x070C15);API_COLOR_A(140);API_BEGIN(RECTS);
        for(int row=0;row<data->rowsCount;++row)for(int column=0;column<data->columnsCount;++column) {
            const int x=posX+boxSpacing+(boxSpacing+boxW)*column;
            const int y=gridY+boxSpacing+(boxSpacing+boxH)*row;
            API_VERTEX2F(x+9,y+28);API_VERTEX2F(x+boxW-9,y+boxH-27);
        }
        API_END();API_RESTORE_CONTEXT();
    }
#endif
    // text

    colorIdx = 0;
    API_COLOR(colors[colorIdx]);

    for (int column = 0; column < data->columnsCount; column++)
    {
        for (int row = 0; row < data->rowsCount; row++)
        {
            int currentBoxIdx = row * data->columnsCount + column;

            if (data->textList[currentBoxIdx] == nullptr)
            {
                continue;
            }

            int textX = posX + boxSpacing + (boxSpacing + boxW) * column + boxW / 2;
            int textY = gridY + boxSpacing + (boxSpacing + boxH) * row + boxH / 2;

            char* text = data->textList[currentBoxIdx];
            int textLen = strlen(text);
            char* spacePtr = nullptr;

            if (getTextWidth(font, data->textList[currentBoxIdx], textLen) + 10 > boxW)
            {
                spacePtr = strchr(text, ' ');
                if (spacePtr != nullptr)
                {
                    textLen = spacePtr - text;
                    textY -= font->height / 2;
                }
            }

            API_CMD_TEXT(
              textX, textY, font->handle, textStyle, data->textList[currentBoxIdx], textLen);

            if (spacePtr != nullptr)
            {
                textY += font->height;
                API_CMD_TEXT(textX, textY, font->handle, textStyle, spacePtr + 1);
            }
        }
    }

    // dots

    if (data->modes != nullptr)
    {
        constexpr int dotSize = 3;
        constexpr int dotSpacing = 13;
        constexpr int dotBottomOffset = 12;

        API_POINT_SIZE(16 * dotSize);
        API_BEGIN(FTPOINTS);

        for (int column = 0; column < data->columnsCount; column++)
        {
            for (int row = 0; row < data->rowsCount; row++)
            {
                int currentBoxIdx = row * data->columnsCount + column;
                if (data->modes[currentBoxIdx] != nullptr && data->modes[currentBoxIdx]->count > 0)
                {
                    int boxX = posX + boxSpacing + (boxSpacing + boxW) * column;
                    int boxY = gridY + boxSpacing + (boxSpacing + boxH) * row;

                    int dotsX = (boxX + (boxW / 2)) -
                                (((data->modes[currentBoxIdx]->count - 1) * dotSpacing) / 2);
                    int dotsY = boxY + boxH - dotBottomOffset;

                    for (int dot = 0; dot < data->modes[currentBoxIdx]->count; dot++)
                    {
                        int curentColorIdx = data->modes[currentBoxIdx]->current == dot ? 6 : 5;

                        if (colorIdx != curentColorIdx)
                        {
                            colorIdx = curentColorIdx;
                            API_COLOR(colors[colorIdx]);
                        }

                        API_VERTEX2F(dotsX + dot * dotSpacing, dotsY);
                    }
                }
            }
        }

        API_END();
    }

    // The focused card has a broken/chamfered outer trace, not a plain box.
#ifdef TRACKER_MINI
    if(chromeHeight) bazill_surface::faultFrame(frameX,frameY,boxW,boxH,colors[4],255);
    else
#endif
    {
    // frame

    API_COLOR(colors[4]);
    API_LINE_WIDTH(kRedFrameWidth);
    API_BEGIN(LINE_STRIP);

    API_VERTEX2F(frameX, frameY);
    API_VERTEX2F(frameX + boxW, frameY);
    API_VERTEX2F(frameX + boxW, frameY + boxH);
    API_VERTEX2F(frameX, frameY + boxH);
    API_VERTEX2F(frameX, frameY);

    API_END();

    }
    API_RESTORE_CONTEXT();
}
