// SPDX-License-Identifier: MIT
#pragma once
#include "BazillHeaderLayout.h"
#include <cstdint>
namespace bazill_cursor {
// Keep the existing unfocused slot2; no change to the transient tracker structure.
inline constexpr uint8_t focusedSlot(bool edit,bool rec,bool playing){
 const auto mode=bazill_header::mode(true,edit,rec,playing,false,false);
 return mode==bazill_header::Mode::Recording?4:mode==bazill_header::Mode::Armed?3:mode==bazill_header::Mode::Edit?0:1;
}
inline bool synchronize(uint8_t& slot,bool edit,bool rec,bool playing){
 if(slot==2)return false;
 const auto next=focusedSlot(edit,rec,playing);if(slot==next)return false;slot=next;return true;
}
inline uint32_t color(unsigned slot,const uint32_t* palette){
 switch(slot){case 0:return 0x56ECD4;case 1:return 0x8FAEC6;case 2:return palette[18];case 3:return 0xFFD276;case 4:return 0xFF657B;default:return palette[10];}
}
}
