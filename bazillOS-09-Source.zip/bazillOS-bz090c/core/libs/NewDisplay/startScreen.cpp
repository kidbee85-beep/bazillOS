
#include "FT812.h"

#include "display.h"
#include "displayControls.h"
#include "startScreenControl.h"
#include "breaklineSplash.h"
#include "BazillShutdown.h"
#include <algorithm>
#include <cstdio>
#ifdef TRACKER_MINI
#include "BreaklineMotion.h"
#endif

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
cStartScreen::cStartScreen(strControlProperties* properties)
  : cDisplayControl(controlIdStartScreen, breakline_splash::kBatchCount)
{
    colorsCount = 2;
    colors = display.getTheme().startScreenColors;

    if (properties == nullptr)
    {
        posX = 0;
        posY = 0;
        text = nullptr;
        data = nullptr;
        value = 0;
        width = 0;
        height = 0;
        style = 0;
        return;
    }

    colors = (properties->colors == nullptr) ? colors : properties->colors;

    posX = properties->x;
    posY = properties->y;

    text = properties->text;
    value = properties->value;

    width = properties->w;
    height = properties->h;

    data = (char*)(properties->data);

    setStyle(properties->style);
}

cStartScreen::~cStartScreen()
{
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
void cStartScreen::setStyle(uint32_t style)
{
    this->style = style;

    textStyle = (style & controlStyleCenterX ? OPT_CENTERX : 0) |
                (style & controlStyleCenterY ? OPT_CENTERY : 0) |
                (style & controlStyleRightX ? OPT_RIGHTX : 0);

    textFont = FONT_INDEX_FROM_STYLE;
    textFont = (textFont >= 0) ? textFont : 0;
    textFont = fonts[textFont].handle;
}

void cStartScreen::setText(const char* text)
{
    this->text = text;
}

void cStartScreen::setValue(int value)
{
    this->value = value;
}

void cStartScreen::setColors(const uint32_t* colors)
{
    this->colors = colors;
}

void cStartScreen::setData(void* data)
{
    this->data = static_cast<char*>(data);
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
void cStartScreen::update()
{
    frameShutdown = (style & controlStyleReverse_0_100) != 0;
    frameProgress = frameShutdown ? (value & 127) : value;
    frameBusy = frameShutdown && (value & 256);
    frameTick = animationTick++;
#ifdef TRACKER_MINI
    frameAnimated = breakline_motion::mode() == breakline_motion::Mode::full;
#else
    frameAnimated = true;
#endif
    drawStage(0);
}

void cStartScreen::update2() { drawStage(1); }
void cStartScreen::update3() { drawStage(2); }

void cStartScreen::drawStage(unsigned stage)
{
    API_SAVE_CONTEXT();
    API_COLOR_A(255);
    API_BLEND_FUNC(SRC_ALPHA, ONE_MINUS_SRC_ALPHA);
    API_LINE_WIDTH(16);
    // Existing UI refresh/progress drives this finite animation. No timer,
    // delay, bitmap load, heap allocation or audio-path change is introduced.
    API_BEGIN(RECTS);
    uint32_t ink = 0xFFFFFFFFu;
    auto paint=[&ink](int x, int y, int w, int h, uint32_t color) {
        if (w <= 0 || h <= 0) return;
        if (ink != color) { API_COLOR(color); ink = color; }
        API_VERTEX2F(x, y);
        API_VERTEX2F(x+w-1, y+h-1);
    };
    if(frameShutdown)bazill_shutdown::drawBatch(frameProgress,frameAnimated,frameBusy,stage,paint,frameTick);
    else breakline_splash::drawBatch(frameProgress,frameAnimated,stage,paint,frameTick);
    API_END();
    if (!frameShutdown && stage == breakline_splash::kBatchCount - 1) {
        static constexpr const char* faces[] = {"[x_x]", "[#:#]", "[x:#]", "[#:x]"};
        const unsigned pose = frameAnimated ? static_cast<unsigned>(std::max(0, frameProgress) / 12) % 4 : 0;
        API_COLOR(0xA7ED32);
        API_CMD_TEXT(42, 365, fonts[0].handle, 0, faces[pose]);
    }
    if (!frameShutdown && stage == breakline_splash::kBatchCount - 1 && data != nullptr) {
        char version[49];
        std::snprintf(version, sizeof version, "%.48s", data);
        API_COLOR(0x82947E);
        API_CMD_TEXT(400, 451, fonts[0].handle, OPT_CENTER, version);
    }
    API_RESTORE_CONTEXT();
}
