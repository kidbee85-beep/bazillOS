// SPDX-License-Identifier: MIT
// Original finite culture shutdown. Decorative only: never controls power or SD.
#pragma once
#include "breaklineSplash.h"
namespace bazill_shutdown {
template<class Rect> void draw(int progress,bool animate,bool busy,Rect rect,unsigned tick=0) {
    const int p=progress<0?0:progress>100?100:progress;
    rect(0,0,800,480,0x050908);
    for(int y=8;y<480;y+=24)rect(24,y,752,1,0x0C1711);
    rect(28,26,744,1,0x304231);rect(28,26,54,3,0xCB366D);
    breakline_splash::type("CULTURE REST",38,42,2,0x82947E,rect);
    breakline_splash::type("KID BUNKA",652,42,2,0x82947E,rect);
    // The name slowly closes its pixel rows; low-motion modes retain the logo.
    const int remaining=animate&&p>65?100-(p-65)*80/35:100;
    for(int row=0;row<7;++row){
        const int drop=animate?p*row/35:0;
        breakline_splash::type(breakline_splash::kLogo,118,123+drop,12,row%3?0xA7ED32:0xD9EEA9,rect,remaining,row);
    }
    const int approach=animate?p:0;
    const int blink=animate&&p<75?int(tick/4)%3:0;
    for(int side=0;side<2;++side){
        const int x=side?642-approach*2:100+approach*2,y=270;
        breakline_splash::crawler(x,y,blink,side?0xCB366D:0xA7ED32,rect);
        // At rest the cells close their eyes; all marks stay clear of captions.
        if(p>=65||!animate){rect(x+14,y+8,28,12,side?0xCB366D:0xA7ED32);rect(x+16,y+12,8,2,0x050908);rect(x+32,y+12,8,2,0x050908);}
    }
    using breakline_splash::type;
    if(busy&&p==100)type("WAIT FOR SD",302,344,3,0xF8BD62,rect);
    else type("SHUTTING DOWN",284,344,3,0xD9EEA9,rect);
    type("RELEASE TO CANCEL",256,384,3,0x82947E,rect);
    rect(116,430,568,12,0x17231A);
    const int blocks=p*32/100;
    for(int i=0;i<blocks;++i)rect(119+i*17,433,13,6,i<24?0xA7ED32:0xCB366D);
}
template<class Rect> unsigned drawBatch(int progress,bool animate,bool busy,unsigned requested,Rect rect,unsigned tick=0){
    unsigned part=0,words=0;uint32_t ink=~0u;
    draw(progress,animate,busy,[&](int x,int y,int w,int h,uint32_t color){
        unsigned cost=2+(ink!=color);
        if(words+cost>breakline_splash::kBatchWords){++part;words=0;ink=~0u;cost=3;}
        if(part==requested)rect(x,y,w,h,color);
        words+=cost;ink=color;
    },tick);
    return part+1;
}
}
