#ifndef LIBS_STARTSCREEN_CONTROL_H_
#define LIBS_STARTSCREEN_CONTROL_H_

#include "displayControls.h"

//--------------------------------------------------------------------
//--------------------------------------------------------------------
//--------------------------------------------------------------------
class cStartScreen : public cDisplayControl
{
  public:
    cStartScreen(strControlProperties* properties = nullptr);
    virtual ~cStartScreen();

    void update() override;
    void update2() override;
    void update3() override;

    virtual void setStyle(uint32_t style);
    virtual void setText(const char* text);
    virtual void setValue(int value);
    virtual void setColors(const uint32_t* colors);
    virtual void setData(void* data);

    char* data;

    uint8_t dots;
    uint16_t textStyle;
    int16_t textFont;

  private:
    void drawStage(unsigned stage);
    int frameProgress = 0;
    bool frameAnimated = false;
    bool frameShutdown = false;
    bool frameBusy = false;
    unsigned animationTick = 0;
    unsigned frameTick = 0;
};

#endif
