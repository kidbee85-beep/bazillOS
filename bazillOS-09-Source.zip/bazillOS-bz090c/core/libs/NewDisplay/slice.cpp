#include "FT812.h"

#include "display.h"
#include "displayControls.h"
#include "sliceControl.h"
#include <algorithm>

cSlicePoints::cSlicePoints(strControlProperties* properties)
  : cDisplayControl(controlIdSlicePoints, 1)
{
    colorsCount = 3;
    colors = display.getTheme().sliceColors;

    if (properties == nullptr)
    {
        posX = 0;
        posY = 0;
        text = nullptr;
        points = nullptr;
        value = 0;
        width = 0;
        height = 0;
        style = 0;
        return;
    }

    colors = (properties->colors == nullptr) ? colors : properties->colors;

    points = (strSlicePoints*)properties->data;

    posX = properties->x;
    posY = properties->y;

    text = properties->text;
    value = properties->value;

    width = properties->w;
    height = properties->h;

    setStyle(properties->style);
}

cSlicePoints::~cSlicePoints()
{
}

//--------------------------------------------------------------------------------
void cSlicePoints::setStyle(uint32_t style)
{
    this->style = style;

    textStyle = (style & controlStyleCenterX ? OPT_CENTERX : 0) |
                (style & controlStyleCenterY ? OPT_CENTERY : 0) |
                (style & controlStyleRightX ? OPT_RIGHTX : 0);

    textFont = FONT_INDEX_FROM_STYLE;
    textFont = (textFont >= 0) ? textFont : 0;
    textFont = fonts[textFont].handle;
}

void cSlicePoints::setText(const char* text)
{
    this->text = text;
}

void cSlicePoints::setValue(int value)
{
}

void cSlicePoints::setColors(const uint32_t* colors)
{
    this->colors = colors;
}

void cSlicePoints::setData(void* data)
{
    points = (strSlicePoints*)data;
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
void cSlicePoints::update()
{
#ifdef TRACKER_MINI
    drawBreaklineSlices();
    return;
#endif
    if (points == nullptr)
    {
        return;
    }

    API_LINE_WIDTH(16);

    uint16_t start = 0;
    constexpr int selectedDiff = 9;

    for (uint8_t i = 0; i < points->sliceCount; i++)
    {
        if (points->slice[i] >= 0)
        {
            start = points->slice[i] + posX;
            bool selected = false;

            if (points->selected == i)
            {
                selected = true;
                API_COLOR(points->isSliceZerocrossed[i] ? colors[2] : colors[1]);
            }
            else
            {
                API_COLOR(colors[0]);
            }

            // point
            API_BEGIN(LINES);
            API_VERTEX2F(start, posY - (1 + (selected ? selectedDiff : 0)));
            API_VERTEX2F(start, posY + height);
            API_END();

            // znaczek
            API_BEGIN(LINE_STRIP);
            API_VERTEX2F(start - 4, posY - (7 + (selected ? selectedDiff : 0)));
            API_VERTEX2F(start + 4, posY - (7 + (selected ? selectedDiff : 0)));
            API_VERTEX2F(start, posY - (2 + (selected ? selectedDiff : 0)));
            API_VERTEX2F(start - 4, posY - (7 + (selected ? selectedDiff : 0)));
            API_END();
        }
    }
}

#ifdef TRACKER_MINI
void cSlicePoints::drawBreaklineSlices()
{
    autoRefresh = false;
    if (!points || width < 2 || !height || posX >= 800 || posY >= 480) { focusReady = false; return; }
    const int w = std::min<int>(width, 800 - posX);
    const int h = std::min<int>(height, 480 - posY);
    const unsigned count = std::min<unsigned>(points->sliceCount, MAX_SLICE_NUMBER);
    const unsigned selected = points->selected;
    const uint32_t now = breakline_motion::nowMs();
    bool selectedVisible = selected < count && points->slice[selected] >= 0 && points->slice[selected] < w;
    int selectedLeft = 0, selectedRight = 0;
    if (selectedVisible)
    {
        selectedLeft = points->slice[selected]; selectedRight = w - 1;
        for (unsigned i = selected + 1; i < count; ++i)
            if (points->slice[i] > selectedLeft && points->slice[i] < w) { selectedRight = points->slice[i]; break; }
        if (!focusReady || lastSliceCount != count)
            focusMotion.begin({static_cast<int16_t>(selectedLeft), static_cast<int16_t>(selectedLeft)},
                              {static_cast<int16_t>(selectedLeft), static_cast<int16_t>(selectedRight)}, now, 176);
        else if (lastSelected != selected || lastLeft != selectedLeft || lastRight != selectedRight)
            focusMotion.begin(focusMotion.current(),
                              {static_cast<int16_t>(selectedLeft), static_cast<int16_t>(selectedRight)}, now);
        focusReady = true; lastSelected = selected; lastSliceCount = count;
        lastLeft = selectedLeft; lastRight = selectedRight;
    }
    else focusReady = false;
    const uint32_t selectedColor = selectedVisible && points->isSliceZerocrossed[selected] ? colors[2] : colors[1];
    API_SAVE_CONTEXT();
    API_BLEND_FUNC(SRC_ALPHA, ONE_MINUS_SRC_ALPHA);
    if (selectedVisible)
    {
        const auto focus = focusMotion.advance(now);
        autoRefresh = focusMotion.active() && breakline_motion::mode() == breakline_motion::Mode::full;
        if (focus.right > focus.left && h > 1)
        {
            API_COLOR(selectedColor); API_COLOR_A(24); API_LINE_WIDTH(16); API_BEGIN(RECTS);
            API_VERTEX2F(posX + focus.left, posY + 1);
            API_VERTEX2F(posX + focus.right, posY + h - 1); API_END();
            // A short travelling rail reveals the interval without moving the
            // true cut marker. Full waveform data stays cached and untouched.
            API_COLOR_A(164); API_BEGIN(LINES);
            API_VERTEX2F(posX + focus.left, posY + h - 1);
            API_VERTEX2F(posX + focus.right, posY + h - 1); API_END();
        }
    }
    API_COLOR(colors[0]); API_COLOR_A(126); API_LINE_WIDTH(8); API_BEGIN(LINES);
    for (unsigned i = 0; i < count; ++i)
    {
        const int x = points->slice[i];
        if (i == selected || x < 0 || x >= w) continue;
        API_VERTEX2F(posX + x, posY);
        API_VERTEX2F(posX + x, posY + h - 1);
    }
    API_END();
    // Flat splice caps replace the heavy repeated triangles. Each cached slice
    // retains its precise vertical line; dense maps get only every fourth cap
    // to keep the ruler legible and leave GPU list space for musical controls.
    API_COLOR_A(214); API_LINE_WIDTH(16); API_BEGIN(RECTS);
    const int top = std::max(0, int(posY) - 5);
    for (unsigned i = 0; i < count; ++i)
    {
        const int x = points->slice[i];
        if (i == selected || x < 0 || x >= w || (count > 16 && i % 4 != 0)) continue;
        API_VERTEX2F(posX + std::max(0, x - 2), top);
        API_VERTEX2F(posX + std::min(w - 1, x + 2), top + 1);
    }
    API_END();
    if (selectedVisible)
    {
        const int x = posX + selectedLeft;
        API_COLOR(selectedColor); API_COLOR_A(255); API_LINE_WIDTH(24); API_BEGIN(LINES);
        API_VERTEX2F(x, std::max(0, int(posY) - 8));
        API_VERTEX2F(x, posY + h - 1); API_END();
        API_LINE_WIDTH(16); API_BEGIN(RECTS);
        API_VERTEX2F(std::max(int(posX), x - 4), std::max(0, int(posY) - 10));
        API_VERTEX2F(std::min(int(posX) + w - 1, x + 4), std::max(0, int(posY) - 7));
        API_END();
    }
    API_RESTORE_CONTEXT();
}
#endif
