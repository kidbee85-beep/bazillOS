#include "FT812.h"

#include "display.h"
#include "progressCursorControl.h"
#include "BreaklineMotion.h"
#include <algorithm>

cProgressCursor::cProgressCursor(strControlProperties* properties)
  : cDisplayControl(controlIdProgressCursor, 1)
{
    colorsCount = 2;
    colors = display.getTheme().waveformProgressColors;

    if (properties == nullptr)
    {
        posX = 0;
        posY = 0;
        width = 0;
        height = 0;

        this->style = 0;
        return;
    }

    colors = (properties->colors == nullptr) ? colors : properties->colors;

    posX = properties->x;
    posY = properties->y;
    width = properties->w;
    height = properties->h;

    setStyle(properties->style);
}

cProgressCursor::~cProgressCursor()
{
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
void cProgressCursor::setStyle(uint32_t style)
{
    this->style = style;
}

void cProgressCursor::setText(const char* text)
{
}

void cProgressCursor::setValue(int value)
{
#ifdef TRACKER_MINI
    if (this->value != value)
    {
        const bool valid = this->value > 0 && this->value < width && value > 0 && value < width;
        const int distance = !valid ? 0 : this->value > value ? this->value - value : value - this->value;
        if (valid && distance <= std::max(8, int(width) / 3))
        {
            olderPosition = previousPosition;
            previousPosition = static_cast<int16_t>(this->value);
            movedAt = breakline_motion::nowMs(); trailFrames = 0;
            trailActive = breakline_motion::mode() == breakline_motion::Mode::full;
        }
        else { previousPosition = olderPosition = -1; trailActive = false; }
    }
#endif
    this->value = value;
}

void cProgressCursor::setColors(const uint32_t* colors)
{
    this->colors = colors;
}

void cProgressCursor::setData(void* data)
{
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
void cProgressCursor::update()
{
#ifdef TRACKER_MINI
    autoRefresh = false;
    if (value <= 0 || value >= width || !height || posX >= 800 || posY >= 480) { trailActive = false; return; }
    const int x = posX + value;
    const int bottom = std::min<int>(479, posY + height - 1);
    if (x >= 800) return;
    API_SAVE_CONTEXT(); API_BLEND_FUNC(SRC_ALPHA, ONE_MINUS_SRC_ALPHA);
    API_LINE_WIDTH(16);
    const uint32_t elapsed = breakline_motion::nowMs() - movedAt;
    if (bottom > int(posY) + 6 && trailActive && breakline_motion::mode() == breakline_motion::Mode::full && elapsed < 80 && ++trailFrames < 8)
    {
        API_COLOR(colors[1]); API_LINE_WIDTH(8);
        if (olderPosition > 0 && olderPosition < width && posX + olderPosition < 800)
        {
            API_COLOR_A(static_cast<uint8_t>((80 - elapsed) * 34 / 80)); API_BEGIN(LINES);
            API_VERTEX2F(posX + olderPosition, posY + 2); API_VERTEX2F(posX + olderPosition, bottom - 2); API_END();
        }
        if (previousPosition > 0 && previousPosition < width && posX + previousPosition < 800)
        {
            API_COLOR_A(static_cast<uint8_t>((80 - elapsed) * 72 / 80)); API_BEGIN(LINES);
            API_VERTEX2F(posX + previousPosition, posY + 1); API_VERTEX2F(posX + previousPosition, bottom - 1); API_END();
        }
        autoRefresh = true;
    }
    else trailActive = false;
    // The centre line is always at the exact current sample position; only its
    // faint history fades. Motion Off/Reduced never delays this musical cue.
    API_COLOR_A(255); API_COLOR(colors[0]); API_LINE_WIDTH(16); API_BEGIN(LINES);
    API_VERTEX2F(x, posY); API_VERTEX2F(x, bottom); API_END();
    API_COLOR(colors[1]); API_BEGIN(RECTS);
    API_VERTEX2F(std::max(int(posX), x - 2), posY);
    API_VERTEX2F(std::min(799, x + 2), std::min(bottom, int(posY) + 3));
    API_VERTEX2F(std::max(int(posX), x - 2), std::max(int(posY), bottom - 3));
    API_VERTEX2F(std::min(799, x + 2), bottom); API_END();
    API_RESTORE_CONTEXT();
    return;
#endif
    if (value > 0 && value < width)
    {
        API_COLOR(colors[1]);
        API_BEGIN(LINES);
        API_VERTEX2F(posX + value, posY);
        API_VERTEX2F(posX + value, posY + height);
        API_END();
    }
}
