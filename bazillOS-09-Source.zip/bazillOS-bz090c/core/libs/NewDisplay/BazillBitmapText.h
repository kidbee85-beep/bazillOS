// SPDX-License-Identifier: MIT
// Bounded bitmap runs for dense Pattern toolbars. Positions/advances match
// CMD_TEXT; the native text path remains available to every other control.
#pragma once
namespace bazill_bitmap_text {
template<class Font> inline void draw(int x,int y,const Font& font,unsigned opts,
                                     const char* text,unsigned count) {
    if (opts & OPT_CENTERY) y-=font.height/2;
    API_SAVE_CONTEXT();
    API_BITMAP_HANDLE(font.handle);
    API_BEGIN(BITMAPS);
    int translated=-1;
    for(unsigned i=0;i<count;++i) {
        const unsigned code=static_cast<unsigned char>(text[i]);
        if(code>=128)break; // Runs are sanitized by bazill_text::bounded.
        if(code!=' ' && font.data[code] && x>=0 && x<800 && y>=0 && y<480) {
            const int offset=x>511?400:0;
            if(offset!=translated){API_VERTEX_TRANSLATE_X(offset*16);translated=offset;}
            API_VERTEX2II(x-offset,y,font.handle,code);
        }
        x+=font.data[code];
    }
    API_END();
    API_RESTORE_CONTEXT();
}
}
