// SPDX-License-Identifier: MIT
// Original bazillOS bounded help layout. No heap allocation or text mutation.
#pragma once
#include <cstddef>
#include <cstdint>

namespace bazill_help {
constexpr unsigned maxRows = 12;
constexpr unsigned maxInput = 4096;
constexpr unsigned maxCharsPerRow = 159;
struct Line { uint16_t offset=0, length=0, width=0; };
struct Flow { Line rows[maxRows]{}; unsigned count=0; bool overflow=false; };
inline bool space(unsigned char c) { return c==' ' || c=='\t' || c=='\r'; }

// Break at whitespace whenever a word fits. A longer-than-row token is split
// without dropping its next character. Explicit newlines consume a real row.
template<class Advance>
Flow wrap(const char* text, unsigned width, unsigned limit, Advance advance) {
    Flow out;
    if (!text || !width || !limit) return out;
    if (limit>maxRows) limit=maxRows;
    unsigned size=0;
    while(size<maxInput && text[size]) ++size;
    unsigned start=0;
    while(start<size && out.count<limit) {
        while(start<size && space(static_cast<unsigned char>(text[start]))) ++start;
        if(start==size) break;
        if(text[start]=='\n') { out.rows[out.count++].offset=start++; continue; }
        unsigned at=start, pixels=0, lastSpace=start, spacePixels=0;
        while(at<size && text[at]!='\n' && at-start<maxCharsPerRow) {
            const unsigned char c=static_cast<unsigned char>(text[at]);
            const unsigned step=advance(c);
            if(pixels+step>width) break;
            if(space(c)) { lastSpace=at;spacePixels=pixels; }
            pixels+=step;++at;
        }
        unsigned end=at, next=at, used=pixels;
        if(at<size && text[at]!='\n' && !space(static_cast<unsigned char>(text[at])) && lastSpace>start) {
            end=lastSpace;next=lastSpace+1;used=spacePixels;
        } else if(at<size && text[at]=='\n') {
            next=at+1;
        }
        // A glyph wider than the text region cannot be drawn safely. Consume it
        // and flag the unsupported geometry rather than loop or overflow.
        if(end==start) { out.overflow=true;++start;continue; }
        while(end>start && space(static_cast<unsigned char>(text[end-1]))) {
            --end;used-=advance(static_cast<unsigned char>(text[end]));
        }
        out.rows[out.count++]={uint16_t(start),uint16_t(end-start),uint16_t(used)};
        start=next;
    }
    while(start<size && space(static_cast<unsigned char>(text[start]))) ++start;
    out.overflow=out.overflow || start<size || size==maxInput;
    return out;
}
} // namespace bazill_help
