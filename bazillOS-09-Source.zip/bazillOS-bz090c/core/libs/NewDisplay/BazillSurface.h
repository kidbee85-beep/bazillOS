// SPDX-License-Identifier: MIT
// Original bazillOS surfaces. Constant assets and bounded display commands;
// no allocation, clock, SD access, or pre-main external RAM initialization.
#pragma once
#include <cstdint>
#include "BazillSurfaceLayout.h"

namespace bazill_surface {
inline void texture(int x, int y, int width, int height, uint32_t color = 0x7B91B0,
                    uint8_t alpha = 40)
{
    if (x < 0) { width += x; x = 0; }
    if (y < 0) { height += y; y = 0; }
    if (width > 800-x) width = 800-x;
    if (height > 480-y) height = 480-y;
    if (width < 24 || height < 12) return;
    API_SAVE_CONTEXT();
    API_BLEND_FUNC(SRC_ALPHA, ONE_MINUS_SRC_ALPHA);
    API_COLOR(color); API_COLOR_A(alpha);
    API_BITMAP_HANDLE(0); API_CELL(0);
    API_BITMAP_SOURCE(textureAddress);
    API_BITMAP_LAYOUT(L4,32,64); API_BITMAP_LAYOUT_H(0,0);
    API_BITMAP_SIZE_H(0,0);
    // Two <=400px repeated quads avoid the 9-bit BITMAP_SIZE width limit.
    for (int offset=0; offset<width; offset+=400) {
        const int w = width-offset > 400 ? 400 : width-offset;
        API_BITMAP_SIZE(NEAREST,REPEAT,REPEAT,w,height);
        API_BEGIN(BITMAPS); API_VERTEX2F(x+offset,y); API_END();
    }
    API_RESTORE_CONTEXT();
}

// Pattern-only paper: existing menus retain their own texture and addresses.
inline void patternTexture(int x,int y,int width,int height) {
    if(width<1 || height<1)return;
    API_SAVE_CONTEXT();API_BLEND_FUNC(SRC_ALPHA,ONE_MINUS_SRC_ALPHA);
    API_COLOR(0x78B995);API_COLOR_A(34);API_BITMAP_HANDLE(0);API_CELL(0);
    API_BITMAP_SOURCE(patternTextureAddress);API_BITMAP_LAYOUT(L4,64,64);
    API_BITMAP_LAYOUT_H(0,0);API_BITMAP_SIZE_H(0,0);
    for(int offset=0;offset<width;offset+=400){const int w=width-offset>400?400:width-offset;
        API_BITMAP_SIZE(NEAREST,REPEAT,REPEAT,w,height);API_BEGIN(BITMAPS);API_VERTEX2F(x+offset,y);API_END();}
    API_RESTORE_CONTEXT();
}

inline void mascot(int x, int y, unsigned pose, uint32_t color = 0x6BE6C2,
                   uint8_t alpha = 210)
{
    API_SAVE_CONTEXT();
    API_BLEND_FUNC(SRC_ALPHA, ONE_MINUS_SRC_ALPHA);
    API_COLOR(color); API_COLOR_A(alpha);
    API_BITMAP_HANDLE(0); API_CELL(0);
    API_BITMAP_SOURCE(mascotAddress + (pose % mascotCount)*mascotBytes);
    API_BITMAP_LAYOUT(L4,12,24); API_BITMAP_LAYOUT_H(0,0);
    API_BITMAP_SIZE_H(0,0);
    API_BITMAP_SIZE(NEAREST,BORDER,BORDER,24,24);
    API_BEGIN(BITMAPS); API_VERTEX2F(x,y); API_END();
    API_RESTORE_CONTEXT();
}

inline void watermark(int x, int y, unsigned pose = 0, int size = 96, uint8_t alpha = 42, uint32_t tint = 0)
{
    if(size<24 || size>128)return;
    API_SAVE_CONTEXT();
    API_BLEND_FUNC(SRC_ALPHA, ONE_MINUS_SRC_ALPHA);
    API_COLOR(tint ? tint : speciesColors[(pose/2)%6]); API_COLOR_A(alpha);
    API_BITMAP_HANDLE(0); API_CELL(0);
    API_BITMAP_SOURCE(mascotAddress + (pose % mascotCount)*mascotBytes);
    API_BITMAP_LAYOUT(L4,12,24); API_BITMAP_LAYOUT_H(0,0);
    API_BITMAP_SIZE_H(0,0);
    // Integer inverse transform: enlarge an original24px sprite.
    API_BITMAP_TRANSFORM_A((24*256+size/2)/size); API_BITMAP_TRANSFORM_B(0); API_BITMAP_TRANSFORM_C(0);
    API_BITMAP_TRANSFORM_D(0); API_BITMAP_TRANSFORM_E((24*256+size/2)/size); API_BITMAP_TRANSFORM_F(0);
    API_BITMAP_SIZE(NEAREST,BORDER,BORDER,size,size);
    API_BEGIN(BITMAPS); API_VERTEX2F(x,y); API_END();
    API_RESTORE_CONTEXT();
}
// Static phosphor halation, using the existing atlas. No time source or refresh loop.
inline void patternMicrobe(int x,int y,unsigned pose,int size,uint32_t tint,uint8_t coreAlpha=90) {
    if(size<24 || size>112)return;
    API_SAVE_CONTEXT();API_BLEND_FUNC(SRC_ALPHA,ONE_MINUS_SRC_ALPHA);
    API_COLOR(tint);API_BITMAP_HANDLE(0);API_CELL(0);
    API_BITMAP_SOURCE(mascotAddress+(pose%mascotCount)*mascotBytes);
    API_BITMAP_LAYOUT(L4,12,24);API_BITMAP_LAYOUT_H(0,0);API_BITMAP_SIZE_H(0,0);
    API_BITMAP_TRANSFORM_B(0);API_BITMAP_TRANSFORM_C(0);API_BITMAP_TRANSFORM_D(0);API_BITMAP_TRANSFORM_F(0);
    for(unsigned pass=0;pass<2;++pass) {
        const int expanded=pass?size:size+8,offset=pass?0:-4;
        const int scale=(24*256+expanded/2)/expanded;
        API_COLOR_A(pass?coreAlpha:18);API_BITMAP_TRANSFORM_A(scale);API_BITMAP_TRANSFORM_E(scale);
        API_BITMAP_SIZE(NEAREST,BORDER,BORDER,expanded,expanded);
        API_BEGIN(BITMAPS);API_VERTEX2F(x+offset,y+offset);API_END();
    }
    API_RESTORE_CONTEXT();
}
inline void patternMembrane(int cx,int cy) {
    static constexpr int8_t points[9][2]={{-29,-43},{23,-43},{44,-22},{44,22},{24,43},{-24,43},{-44,22},{-44,-23},{-29,-43}};
    API_SAVE_CONTEXT();API_COLOR(0xA5EB72);API_COLOR_A(48);API_LINE_WIDTH(8);API_BEGIN(LINE_STRIP);
    for(const auto& p:points) {API_VERTEX2F(cx+p[0],cy+p[1]);}
    API_END();API_RESTORE_CONTEXT();
}
inline void patternBrackets(int x,int y,int width,int height) {
    if(width<48 || height<48)return;
    API_SAVE_CONTEXT();API_COLOR(0xA8E768);API_COLOR_A(56);API_LINE_WIDTH(8);API_BEGIN(LINES);
    for(int side=0;side<2;++side) {
        const int xx=side?x+width:x,dx=side?-1:1;
        API_VERTEX2F(xx,y+2);API_VERTEX2F(xx+dx*12,y+2);
        API_VERTEX2F(xx,y+2);API_VERTEX2F(xx,y+13);
        API_VERTEX2F(xx,y+height-2);API_VERTEX2F(xx+dx*12,y+height-2);
        API_VERTEX2F(xx,y+height-2);API_VERTEX2F(xx,y+height-13);
    }
    API_END();API_RESTORE_CONTEXT();
}
inline void menuMascot(int x,int y,unsigned pose,uint32_t color,uint8_t alpha)
{
    API_SAVE_CONTEXT();API_BLEND_FUNC(SRC_ALPHA,ONE_MINUS_SRC_ALPHA);
    API_COLOR(color);API_COLOR_A(alpha);API_BITMAP_HANDLE(0);API_CELL(0);
    API_BITMAP_SOURCE(menuMascotAddress+(pose%mascotCount)*menuMascotBytes);
    API_BITMAP_LAYOUT(L4,18,36);API_BITMAP_LAYOUT_H(0,0);API_BITMAP_SIZE_H(0,0);
    API_BITMAP_SIZE(NEAREST,BORDER,BORDER,36,36);
    API_BEGIN(BITMAPS);API_VERTEX2F(x,y);API_END();API_RESTORE_CONTEXT();
}
inline void scars(int x,int y,int width,int height,uint32_t color,uint8_t alpha=100)
{
    if(width<80 || height<40)return;
    API_SAVE_CONTEXT();API_COLOR(color);API_COLOR_A(alpha);API_LINE_WIDTH(8);API_BEGIN(LINES);
    for(int i=0;i<4;++i){API_VERTEX2F(x+7+i*6,y+6);API_VERTEX2F(x+3+i*6,y+13);}
    API_END();API_RESTORE_CONTEXT();
}
inline void faultFrame(int x,int y,int width,int height,uint32_t color,uint8_t alpha=100)
{
    API_SAVE_CONTEXT();API_COLOR(color);API_COLOR_A(alpha);API_LINE_WIDTH(8);API_BEGIN(LINE_STRIP);
    API_VERTEX2F(x+7,y);API_VERTEX2F(x+width-3,y);API_VERTEX2F(x+width,y+3);
    API_VERTEX2F(x+width,y+height-7);API_VERTEX2F(x+width-7,y+height);
    API_VERTEX2F(x+2,y+height);API_VERTEX2F(x,y+height-2);API_VERTEX2F(x,y+7);API_VERTEX2F(x+7,y);
    API_END();API_RESTORE_CONTEXT();
}
} // namespace bazill_surface
