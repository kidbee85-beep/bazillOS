// SPDX-License-Identifier: MIT
// Original bazillOS field guide. Fixed safe areas, actual font advances,
// existing microbe atlas; no allocations, timers, audio or filesystem work.
#pragma once
#include "BazillHelpLayout.h"
#include "BazillSurface.h"

namespace bazill_help {
inline unsigned advance(unsigned fontIndex,unsigned char c) {
    if(c<32 || c>126) c='?';
    const unsigned n=fonts[fontIndex].data[c];
    return n?n:fonts[fontIndex].width;
}
inline Flow flow(const char* text,unsigned fontIndex,unsigned width,unsigned rows) {
    return wrap(text,width,rows,[fontIndex](unsigned char c){return advance(fontIndex,c);});
}
inline void paintLines(const char* text,const Flow& lines,unsigned fontIndex,
                       int x,int y,int step,uint32_t color) {
    if(!text) return;
    API_COLOR(color);API_COLOR_A(255);
    for(unsigned i=0;i<lines.count;++i) {
        const auto& line=lines.rows[i];
        if(!line.length) continue;
        // Every shipped help line fits this bounded buffer at the smallest
        // supported font advance. Unknown bytes receive a visible replacement.
        char safe[160];
        unsigned n=line.length;
        if(n>=sizeof safe) n=sizeof safe-1;
        for(unsigned j=0;j<n;++j) {
            const unsigned char c=static_cast<unsigned char>(text[line.offset+j]);
            safe[j]=(c>=32 && c<=126)?char(c):'?';
        }
        safe[n]=0;
        API_CMD_TEXT(x,y+int(i)*step,fonts[fontIndex].handle,0,safe);
    }
}
inline void draw(const char* title,const char* action,const char* body,const char* footer) {
    API_SAVE_CONTEXT();API_BLEND_FUNC(SRC_ALPHA,ONE_MINUS_SRC_ALPHA);
    API_COLOR_A(255);API_COLOR(0x050A10);API_LINE_WIDTH(16);API_BEGIN(RECTS);
    API_VERTEX2F(0,0);API_VERTEX2F(799,479);API_END();
    API_COLOR(0x0D1921);API_BEGIN(RECTS);
    API_VERTEX2F(24,34);API_VERTEX2F(775,447);API_END();
    bazill_surface::texture(25,35,750,410,0x509985,16);
    bazill_surface::faultFrame(24,34,751,413,0x3B706C,170);
    bazill_surface::scars(32,37,120,40,0xA8E768,160);
    bazill_surface::patternMicrobe(706,205,2,40,0x6BE6C2,56);
    bazill_surface::patternMicrobe(692,287,9,64,0xA8E768,44);
    bazill_surface::menuMascot(710,49,7,0xA8E768,220);
    API_COLOR(0x6BE6C2);API_COLOR_A(255);
    API_CMD_TEXT(56,54,fonts[0].handle,0,"bazillOS / FIELD GUIDE");
    API_COLOR(0x345E61);API_LINE_WIDTH(8);API_BEGIN(LINES);
    API_VERTEX2F(56,112);API_VERTEX2F(744,112);
    API_VERTEX2F(56,184);API_VERTEX2F(680,184);
    API_VERTEX2F(56,368);API_VERTEX2F(744,368);API_END();
    // Keep display text at least56px from screen edges, and the main reading
    // column72px from the left with a separate microbe rail on the right.
    paintLines(title,flow(title,4,640,2),4,56,86,16,0x9AAFB6);
    unsigned actionFont=3;
    auto actionLines=flow(action,actionFont,608,2);
    if(actionLines.overflow || fonts[actionFont].height>24) {
        actionFont=0;actionLines=flow(action,actionFont,608,2);
    }
    paintLines(action,actionLines,actionFont,72,124,26,0xB9EF86);
    unsigned bodyFont=0,bodyStep=24;
    auto bodyLines=flow(body,bodyFont,608,6);
    if(bodyLines.overflow || fonts[bodyFont].height>20) {
        bodyFont=4;bodyStep=18;bodyLines=flow(body,bodyFont,608,8);
    }
    paintLines(body,bodyLines,bodyFont,72,202,bodyStep,0xDBE8E7);
    paintLines(footer,flow(footer,4,664,3),4,56,386,16,0x92C4BE);
    API_RESTORE_CONTEXT();
}
} // namespace bazill_help
