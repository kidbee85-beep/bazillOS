// SPDX-License-Identifier: MIT
#pragma once
#include <cstdint>
namespace bazill_surface {
inline constexpr uint32_t textureAddress=131072;
inline constexpr unsigned textureSide=64,textureBytes=2048;
inline constexpr unsigned mascotCount=12,mascotBytes=288,menuMascotBytes=648;
inline constexpr uint32_t mascotAddress=textureAddress+textureBytes;
inline constexpr uint32_t menuMascotAddress=mascotAddress+mascotCount*mascotBytes;
inline constexpr uint32_t patternTextureAddress=menuMascotAddress+mascotCount*menuMascotBytes;
inline constexpr unsigned patternTextureBytes=4096;
inline constexpr uint32_t assetEnd=patternTextureAddress+patternTextureBytes;
static_assert(assetEnd<150000,"Culture assets must stay below cached display controls");
inline constexpr uint32_t speciesColors[6]={0xCEFF78,0x68FFE1,0xF197E6,0xB59BFF,0xFFD092,0x7DE2FA};
}
