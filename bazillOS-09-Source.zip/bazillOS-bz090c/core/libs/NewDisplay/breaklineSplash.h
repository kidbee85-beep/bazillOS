// SPDX-License-Identifier: MIT
// Original bazillOS identity: procedural pixel type and finite demoscene reveal.
#pragma once
#include <cstdint>
#include <array>
namespace breakline_splash {
// Compile the tiny logo alphabet into ROM. No per-frame bit-string decoding,
// heap or dynamic initialization; invalid row requests never index a glyph.
constexpr std::array<uint8_t,7> glyph(const char (&bits)[36]) {
    std::array<uint8_t,7> out{};
    for (unsigned r=0;r<7;++r) for(unsigned c=0;c<5;++c)
        out[r]=uint8_t((out[r]<<1)|(bits[r*5+c]=='1'));
    return out;
}
inline uint8_t row(char c,int r){
    if(r<0 || r>=7)return 0;
    switch(c){
    case 'b': { static constexpr auto g=glyph("10000100001111010001100011000111110"); return g[r]; }
    case 'a': { static constexpr auto g=glyph("00000000000111000001011111000101111"); return g[r]; }
    case 'z': { static constexpr auto g=glyph("00000000001111100010001000100011111"); return g[r]; }
    case 'l': { static constexpr auto g=glyph("01100001000010000100001000010001110"); return g[r]; }
    case 'm': { static constexpr auto g=glyph("00000110111010110101101011010110101"); return g[r]; }
    case 'i': { static constexpr auto g=glyph("00100000000010000100001000010001110"); return g[r]; }
    case 'n': { static constexpr auto g=glyph("00000000001111010001100011000110001"); return g[r]; }
    case 'o': { static constexpr auto g=glyph("00000000000111010001100011000101110"); return g[r]; }
    case 'A': { static constexpr auto g=glyph("01110100011000111111100011000110001"); return g[r]; }
    case 'B': { static constexpr auto g=glyph("11110100011000111110100011000111110"); return g[r]; }
    case 'C': { static constexpr auto g=glyph("01111100001000010000100001000001111"); return g[r]; }
    case 'D': { static constexpr auto g=glyph("11110100011000110001100011000111110"); return g[r]; }
    case 'E': { static constexpr auto g=glyph("11111100001000011110100001000011111"); return g[r]; }
    case 'F': { static constexpr auto g=glyph("11111100001000011110100001000010000"); return g[r]; }
    case 'W': { static constexpr auto g=glyph("10001100011000110101101011101110001"); return g[r]; }
    case 'G': { static constexpr auto g=glyph("01111100001000010111100011000101111"); return g[r]; }
    case 'H': { static constexpr auto g=glyph("10001100011000111111100011000110001"); return g[r]; }
    case 'I': { static constexpr auto g=glyph("01110001000010000100001000010001110"); return g[r]; }
    case 'K': { static constexpr auto g=glyph("10001100101010011000101001001010001"); return g[r]; }
    case 'L': { static constexpr auto g=glyph("10000100001000010000100001000011111"); return g[r]; }
    case 'M': { static constexpr auto g=glyph("10001110111010110101100011000110001"); return g[r]; }
    case 'N': { static constexpr auto g=glyph("10001110011010110011100011000110001"); return g[r]; }
    case 'O': { static constexpr auto g=glyph("01110100011000110001100011000101110"); return g[r]; }
    case 'P': { static constexpr auto g=glyph("11110100011000111110100001000010000"); return g[r]; }
    case 'R': { static constexpr auto g=glyph("11110100011000111110101001001010001"); return g[r]; }
    case 'S': { static constexpr auto g=glyph("01111100001000001110000010000111110"); return g[r]; }
    case 'T': { static constexpr auto g=glyph("11111001000010000100001000010000100"); return g[r]; }
    case 'U': { static constexpr auto g=glyph("10001100011000110001100011000101110"); return g[r]; }
    case 'V': { static constexpr auto g=glyph("10001100011000110001100010101000100"); return g[r]; }
    case 'Z': { static constexpr auto g=glyph("11111000010001000100010001000011111"); return g[r]; }
    case 'Y': { static constexpr auto g=glyph("10001100010101000100001000010000100"); return g[r]; }
    case '/': { static constexpr auto g=glyph("00001000100001000100010000100010000"); return g[r]; }
    case '>': { static constexpr auto g=glyph("10000010000010000010001000100010000"); return g[r]; }
    case '_': { static constexpr auto g=glyph("00000000000000000000000000000011111"); return g[r]; }
    default:return 0;
    }
}
inline constexpr char kLogo[]="bazillOS";
template<class Rect> void type(const char* text,int x,int y,int scale,uint32_t color,Rect rect,int reveal=100,int onlyRow=-1){
    if(!text || scale<1 || onlyRow>=7)return;
    unsigned length=0;while(length<64 && text[length])++length;
    if(!length)return;
    const int span=int(length)*6+6;
    for(int r=0;r<7;++r){
        if(onlyRow>=0 && r!=onlyRow)continue;
        for(unsigned k=0;k<length;++k){
            if(reveal<100 && int(k*6+r)*100/span>reveal)continue;
            const auto bits=row(text[k],r);
            for(int c=0;c<5;){
                if(!(bits&(16>>c))){++c;continue;}
                int end=c+1;while(end<5&&(bits&(16>>end)))++end;
                rect(x+(int(k)*6+c)*scale,y+r*scale,(end-c)*scale,scale,color);c=end;
            }
        }
    }
}
// A small crawling culture, drawn in one fixed palette. Its motion reuses
// startup refreshes; no random state, clock reads, file access or audio work.
template<class Rect> void crawler(int x,int y,unsigned pose,uint32_t body,Rect rect){
    auto q=[&](int a,int b,int w,int h,uint32_t c){rect(x+a*2,y+b*2,w*2,h*2,c);};
    const int lean=int(pose%3)-1;
    q(3,3,21,13,body);q(6,0,14,3,body);
    q(1,7,3,6,body);q(23,5,4,7,body);
    for(int i=0;i<3;++i){q(5+i*7+lean,16,2,4,body);}
    q(-2,4,4,2,body);q(26,10,4,2,body);
    q(8,6,3,4,0x050908);q(17,5,3,4,0x050908);
    q(9,12,11,2,0x050908);q(13,11,2,4,0x050908);
}
template<class Rect> void draw(int progress,bool animate,Rect rect,unsigned tick=0){
    const int p=progress<0?0:progress>100?100:progress;
    const unsigned phase=animate?tick%64:0;
    rect(0,0,800,480,0x050908);
    // Sparse CRT grain and fractured copper rails leave the name unobscured.
    for(int y=8;y<480;y+=24)rect(24,y,752,1,0x0C1711);
    rect(28,26,744,1,0x304231);rect(28,26,1,34,0x304231);
    rect(28,26,54,3,0xA7ED32);rect(718,26,54,3,0xCB366D);
    type("KID BUNKA",38,42,2,0x82947E,rect);
    type("TRACKER SYSTEM",592,42,2,0x82947E,rect);
    const int wave[]={0,2,5,8,5,2,0,-2,-5,-8,-5,-2,0,2,5,8};
    for(unsigned i=0;i<16;++i){
        const int lift=wave[(i+phase/4)%16];
        rect(112+int(i)*36,125+lift,29,2,i%4==0?0xCB366D:0x486822);
        rect(112+int(i)*36,286-lift,29,2,i%4==1?0xA7ED32:0x26382B);
    }
    const int reveal=p<8?0:p>65?100:(p-8)*100/57;
    // Lower-case bazill + upper-case OS is part of the identity. Letters
    // arrive at staggered heights, then breathe by only two pixels.
    for(unsigned i=0;i<8;++i){
        const int arrival=(100-reveal)*int(8-i)/32;
        const int bob=animate?wave[(i*2+phase/4)%16]/4:0;
        const int x=118+int(i)*72,y=168-arrival+bob;
        char letter[2]={kLogo[i],0};
        type(letter,x+3,y+4,12,0x603044,rect,reveal,5);
        type(letter,x,y,12,i<6?0xA7ED32:0xD9EEA9,rect,reveal);
    }
    // Cilia around the name, never cutting into the letter strokes.
    rect(107,194,8,3,0xCB366D);rect(109,213,6,3,0xA7ED32);
    rect(686,188,9,3,0xA7ED32);rect(685,225,12,3,0xCB366D);
    type("CODE / CHOP / MUTATE",222,315,3,0xADBEA7,rect);
    const int wander=animate?wave[phase/4]:0;
    crawler(70+wander,320,phase/8,0xA7ED32,rect);
    crawler(696-wander,320,phase/8+1,0xCB366D,rect);
    // Cell division: the two tiny cultures separate as loading advances.
    for(int i=0;i<8;++i){
        const int h=5+(i*7+int(phase)/2)%22;
        rect(166+i*9,365-h,5,h,i%3?0x486822:0xCB366D);
    }
    type(p<100?"> LOADING_":"> READY_",296,365,3,p<100?0xF8BD62:0xA7ED32,rect);
    rect(116,410,568,12,0x17231A);
    const int blocks=p*32/100;
    for(int i=0;i<blocks;++i)rect(119+i*17,413,13,6,i<24?0xA7ED32:0xCB366D);
    type("SAMPLE CULTURE",38,446,2,0x63725F,rect);
    rect(728,448,10,10,0xA7ED32);rect(745,448,10,10,0xCB366D);
}

// RAM_DL is 8 KiB, but the display command FIFO is only 4 KiB. The
// production driver commits its write pointer only after each entire burst.
// Partition one immutable frame across cached-control stages, never one
// oversized burst. Each stage has independent color/context setup.
inline constexpr unsigned kBatchWords=800;
inline constexpr unsigned kBatchCount=3;
template<class Rect> unsigned drawBatch(int progress,bool animate,unsigned requested,Rect rect,unsigned tick=0){
    unsigned part=0,words=0;uint32_t ink=~0u;
    draw(progress,animate,[&](int x,int y,int w,int h,uint32_t color){
        unsigned cost=2+(ink!=color);
        if(words+cost>kBatchWords){++part;words=0;ink=~0u;cost=3;}
        if(part==requested)rect(x,y,w,h,color);
        words+=cost;ink=color;
    },tick);
    return part+1;
}
}
