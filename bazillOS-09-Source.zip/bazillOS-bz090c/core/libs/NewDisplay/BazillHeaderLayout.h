// SPDX-License-Identifier: MIT
#pragma once
#include <cstdint>
#include <cstdio>
namespace bazill_header {
enum class Mode:uint8_t {Browse,Edit,Armed,Recording};
inline constexpr Mode mode(bool pattern,bool edit,bool rec,bool playing,bool sampleRec,bool sampleArmed){
 return sampleRec?Mode::Recording:sampleArmed?Mode::Armed:pattern&&rec?(playing?Mode::Recording:Mode::Armed):pattern&&edit?Mode::Edit:Mode::Browse;
}
inline constexpr unsigned modeBits(Mode state,bool pulse=false){return (unsigned(state)<<8)|(pulse?1024u:0u);}

inline constexpr uint32_t editAccent=0x56ECD4,armedAccent=0xFFD276,recordAccent=0xFF657B;
inline constexpr uint32_t runningText[4]={0xC4F582,0x0B101B,0xC4F582,0xC4F582};
inline constexpr uint32_t stoppedText[4]={0xAFC3D1,0x0B101B,0xAFC3D1,0xAFC3D1};
inline constexpr int brandX=40,slashX=110,titleX=124,titleWidth=136;
inline constexpr int timerX=272,timerWidth=216,rightX=752,rightWidth=248;
static_assert(titleX+titleWidth<timerX && timerX+timerWidth<rightX-rightWidth);
inline void format(char* out,unsigned capacity,unsigned minutes,unsigned seconds,
                   unsigned pattern,unsigned step,char state,bool hex){
 char elapsed[16];
 if(minutes<1000)std::snprintf(elapsed,sizeof elapsed,"%03u:%02u",minutes,seconds%60);
 else std::snprintf(elapsed,sizeof elapsed,"%3uh%02u",minutes/60,minutes%60);
 const char* transport=state=='P'?"PLAY":state=='S'?"SONG":state=='L'?"LIVE":state=='V'?"SEL":"STOP";
 std::snprintf(out,capacity,hex?"%s %s P%02X.%02X":"%s %s P%03u.%03u",
               elapsed,transport,pattern,step);
}
} // namespace bazill_header
