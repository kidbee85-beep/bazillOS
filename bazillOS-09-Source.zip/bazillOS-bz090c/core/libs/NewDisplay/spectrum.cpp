#include "FT812.h"

#include "display.h"
#include "polyassert.h"
#include "spectrumControl.h"
#include "BreaklineMotion.h"
#include <algorithm>

cSpectrum::cSpectrum(strControlProperties* properties)
  : cDisplayControl(controlIdSpectrum, 1)
{
    colorsCount = 2;
    colors = display.getTheme().waveformColors;

    refreshStep = 0;

    if (properties == nullptr)
    {
        posX = 0;
        posY = 0;
        width = 0;
        height = 0;
        spectrum = nullptr;
        this->style = 0;
        return;
    }

    colors = (properties->colors == nullptr) ? colors : properties->colors;

    spectrum = (strTrackerSpectrum*)properties->data;
    posX = properties->x;
    posY = properties->y;
    width = properties->w;
    height = properties->h;

    setStyle(properties->style);
}

cSpectrum::~cSpectrum()
{
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
void cSpectrum::setStyle(uint32_t style)
{
    this->style = style;
}

void cSpectrum::setText(const char* text)
{
}

void cSpectrum::setValue(int value)
{
    this->value = value;
}

void cSpectrum::setColors(const uint32_t* colors)
{
    this->colors = colors;
}

void cSpectrum::setData(void* data)
{
    spectrum = (strTrackerSpectrum*)data;

    width = spectrum->width;
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
void cSpectrum::update()
{
#ifdef TRACKER_MINI
    if (spectrum && spectrum->framedLane) { drawFramedLane(); return; }
#endif
    API_COLOR(colors[0]);
    API_LINE_WIDTH(16);

    // uint16_t half = height/2;
    uint16_t center = posY + height / 2;

    float yNormalizationCoeff = (float)height / (float)(MAX_16BIT / 300);

    if (spectrum == nullptr)
    {
        API_BEGIN(LINES);
        API_VERTEX2F(posX, center);
        API_VERTEX2F(posX + width - 1, center);
    }
    else if (spectrum->spectrumType == 1)
    {
        // srodek
        API_COLOR(colors[1]);
        API_LINE_WIDTH(8);
        API_BEGIN(LINES);
        API_VERTEX2F(posX, center);
        API_VERTEX2F(posX + width - 1, center);
        API_END();

        // jedna lamana linia
        API_COLOR(colors[0]);
        API_LINE_WIDTH(8);
        API_BEGIN(LINE_STRIP);

        int16_t sample_y = 0;
        int16_t next_sample_y = 0;

        int pointsLimit = 0;

        if (spectrum->pointsLimit == strTrackerSpectrum::PointsLimit::k600)
        {
            pointsLimit = 600;
        }
        else if (spectrum->pointsLimit == strTrackerSpectrum::PointsLimit::k300)
        {
            pointsLimit = 300;
        }
        else if (spectrum->pointsLimit == strTrackerSpectrum::PointsLimit::k200)
        {
            pointsLimit = 200;
        }

        float limitToWidthCoeff = (float)width / (float)pointsLimit;
        float idx = 0.0f;

        for (uint16_t i = 0; i < pointsLimit; i++)
        {
            int sampleIdx = (int)idx;

            if (spectrum->upperData[sampleIdx] > 0)
            {
                sample_y = center - spectrum->upperData[sampleIdx] * yNormalizationCoeff;
            }
            else if (spectrum->lowerData[sampleIdx] < 0)
            {
                sample_y = center - spectrum->lowerData[sampleIdx] * yNormalizationCoeff;
            }
            else
            {
                sample_y = center;
            }

            idx += limitToWidthCoeff;

            int nextSampleIdx = (int)idx;

            if (nextSampleIdx < width - 1 && sampleIdx > 0)
            {
                if (spectrum->upperData[nextSampleIdx] > 0)
                {
                    next_sample_y =
                      center - spectrum->upperData[nextSampleIdx] * yNormalizationCoeff;
                }
                else if (spectrum->lowerData[nextSampleIdx] < 0)
                {
                    next_sample_y =
                      center - spectrum->lowerData[nextSampleIdx] * yNormalizationCoeff;
                }
                else
                {
                    next_sample_y = center;
                }
            }
            else
            {
                next_sample_y = sample_y + 1;
            }

            if (next_sample_y == sample_y)
            {
                continue; // omija powtorzenia takiej samej wartosci probki
            }

            assert(sampleIdx < width);
            API_VERTEX2F(posX + sampleIdx, sample_y);
        }
    }
    else if (spectrum->spectrumType == 0)
    {
        API_BEGIN(LINES);

        int pointsLimit = 0;
        if (spectrum->pointsLimit == strTrackerSpectrum::PointsLimit::k600)
        {
            pointsLimit = 600;
        }
        else if (spectrum->pointsLimit == strTrackerSpectrum::PointsLimit::k300)
        {
            pointsLimit = 300;
        }
        else if (spectrum->pointsLimit == strTrackerSpectrum::PointsLimit::k200)
        {
            pointsLimit = 200;
        }

        float mult = (float)width / (float)pointsLimit;
        uint16_t length = width / mult;

        for (uint16_t i = 0; i < length; i++)
        {
            int idx = i * mult;
            assert(idx < width);
            API_VERTEX2F(posX + idx, center - spectrum->upperData[idx] * yNormalizationCoeff);
            API_VERTEX2F(posX + idx, center - spectrum->lowerData[idx] * yNormalizationCoeff);
        }
    }
    else if (spectrum->spectrumType == 3)
    {
        // elementsState.waitSpinner = 1;
    }
    API_END();
}

//------------------------------------------------------------------------------------------
void cSpectrum::update2()
{
    if (spectrum == nullptr)
    {
    }
    else if (spectrum->spectrumType == 1)
    {
    }
    else if (spectrum->spectrumType == 0 && width > 200)
    {
        API_BEGIN(LINE_STRIP);

        uint16_t center = posY + height / 2;

        uint8_t odd = 0;

        uint16_t width_left = (width - 200 > 200) ? 200 : width - 200;

        if (width_left > 0)
        {
            for (uint16_t i = 0; i < width_left; i++)
            {
                if (odd)
                    API_VERTEX2II(posX + i + 199, center - spectrum->upperData[i + 199], 0, 0);
                else
                    API_VERTEX2II(posX + i + 199, center - spectrum->lowerData[i + 199], 0, 0);
                odd = !odd;
            }
        }
    }
    API_END();
}

//------------------------------------------------------------------------------------------
void cSpectrum::update3()
{
    if (spectrum == nullptr)
    {
    }
    else if (spectrum->spectrumType == 1)
    {
    }
    else if (spectrum->spectrumType == 0 && width > 400)
    {
        API_BEGIN(LINE_STRIP);

        uint16_t center = posY + height / 2;

        uint8_t odd = 0;

        uint16_t width_left = (width - 400 > 200) ? 200 : width - 400;

        if (width_left > 0)
        {
            for (uint16_t i = 0; i < width_left; i++)
            {
                if (odd)
                    API_VERTEX2F(posX + i + 399, center - spectrum->upperData[i + 399]);
                else
                    API_VERTEX2F(posX + i + 399, center - spectrum->lowerData[i + 399]);
                odd = !odd;
            }
        }
    }
    API_END();
}

#ifdef TRACKER_MINI
void cSpectrum::drawFramedLane()
{
    // Cached peak data only: no audio, sample reads, floating point or allocation.
    if (!spectrum || width < 4 || height < 8 || posX >= 800 || posY >= 480) return;
    const int w = std::min<int>(width, 800 - posX);
    const int h = std::min<int>(height, 480 - posY);
    if (w < 4 || h < 8) return;
    const int center = posY + h / 2;
    const int amplitude = std::max(1, h / 2 - 5);
    const auto& theme = display.getTheme();
    const uint32_t background = breakline_motion::mix(theme.backgroundColor, 0x111920, 8);
    const uint32_t grid = breakline_motion::mix(background, theme.grey_22, 9);
    const uint32_t accent = spectrum->stereoLane && spectrum->channelHint == 1 ? theme.cyan : colors[0];
    API_SAVE_CONTEXT();
    API_COLOR_A(255);
    API_BLEND_FUNC(SRC_ALPHA, ONE_MINUS_SRC_ALPHA);
    API_LINE_WIDTH(16);
    API_COLOR(background);
    API_BEGIN(RECTS);
    API_VERTEX2F(posX, posY); API_VERTEX2F(posX + w - 1, posY + h - 1);
    API_END();
    API_COLOR(grid);
    API_LINE_WIDTH(8);
    API_BEGIN(LINES);
    for (int quarter = 1; quarter < 4; ++quarter)
    {
        const int x = posX + quarter * (w - 1) / 4;
        API_VERTEX2F(x, posY + 2); API_VERTEX2F(x, posY + h - 3);
    }
    API_VERTEX2F(posX + 1, center); API_VERTEX2F(posX + w - 2, center);
    API_END();
    API_COLOR(breakline_motion::mix(background, accent, 5));
    API_BEGIN(LINE_STRIP);
    API_VERTEX2F(posX, posY + h - 1); API_VERTEX2F(posX, posY);
    API_VERTEX2F(posX + w - 1, posY); API_VERTEX2F(posX + w - 1, posY + h - 1);
    API_END();

    // 128/240 bins aggregate every cached source column, so a narrow transient
    // cannot disappear merely because it falls between displayed x positions.
    // This reduces GPU list size while preserving the extrema of each bin.
    const unsigned sourceWidth = spectrum->width ? std::min<uint32_t>(spectrum->width, 600) : std::min<unsigned>(width, 600);
    const unsigned limit = spectrum->pointsLimit == strTrackerSpectrum::k200 ? 128 : 240;
    const unsigned count = std::min<unsigned>(sourceWidth, std::min<unsigned>(limit, w));
    API_COLOR(accent);
    API_LINE_WIDTH(20);
    API_BEGIN(spectrum->spectrumType == 1 ? LINE_STRIP : LINES);
    for (unsigned bin = 0; spectrum->spectrumType != 3 && bin < count; ++bin)
    {
        const unsigned start = bin * sourceWidth / count;
        const unsigned end = (bin + 1) * sourceWidth / count;
        int upper = -128, lower = 127;
        for (unsigned sample = start; sample < end; ++sample)
        {
            upper = std::max(upper, int(spectrum->upperData[sample]));
            lower = std::min(lower, int(spectrum->lowerData[sample]));
        }
        upper = std::clamp(upper, -109, 109); lower = std::clamp(lower, -109, 109);
        if (upper < lower) std::swap(upper, lower);
        const int x = posX + int((start + end - 1) * (w - 1) / (2 * std::max(1u, sourceWidth - 1)));
        if (spectrum->spectrumType == 1)
        {
            const int sample = upper >= -lower ? upper : lower;
            API_VERTEX2F(x, center - sample * amplitude / 109);
        }
        else if (upper != 0 || lower != 0)
        {
            API_VERTEX2F(x, center - upper * amplitude / 109);
            API_VERTEX2F(x, center - lower * amplitude / 109);
        }
    }
    API_END();
    // A small geometric channel letter; no font widget or extra text list cost.
    if (spectrum->showChannelLabel && w >= 20 && h >= 20)
    {
        const int x = posX + 7, y = posY + 6;
        API_COLOR(breakline_motion::mix(background, accent, 13));
        API_LINE_WIDTH(16); API_BEGIN(LINE_STRIP);
        if (!spectrum->stereoLane)
        {
            API_VERTEX2F(x, y + 8); API_VERTEX2F(x, y); API_VERTEX2F(x + 3, y + 4);
            API_VERTEX2F(x + 6, y); API_VERTEX2F(x + 6, y + 8);
        }
        else if (spectrum->channelHint == 1)
        {
            API_VERTEX2F(x, y + 8); API_VERTEX2F(x, y); API_VERTEX2F(x + 5, y);
            API_VERTEX2F(x + 5, y + 4); API_VERTEX2F(x, y + 4);
            API_VERTEX2F(x + 5, y + 8);
        }
        else
        {
            API_VERTEX2F(x, y); API_VERTEX2F(x, y + 8); API_VERTEX2F(x + 5, y + 8);
        }
        API_END();
    }
    API_RESTORE_CONTEXT();
}
#endif
