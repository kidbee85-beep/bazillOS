#include "BreaklineMotion.h"
#ifdef TRACKER_MINI
#include "Tracker.h"
#endif

namespace breakline_motion {
namespace { Mode currentMode = Mode::full; }
Mode mode() noexcept { return currentMode; }
void setMode(Mode value) noexcept
{
    if (value == Mode::off || value == Mode::reduced || value == Mode::full) currentMode = value;
}
uint32_t nowMs() noexcept
{
#ifdef TRACKER_MINI
    auto* tracker = Tracker::getInstance();
    if (tracker && tracker->getPlatform() && tracker->getPlatform()->getTimer())
        return tracker->getPlatform()->getTimer()->millis();
#endif
    return 0;
}
uint32_t mix(uint32_t a, uint32_t b, unsigned amount) noexcept
{
    if (amount > 16) amount = 16;
    const unsigned inverse = 16 - amount;
    const uint32_t r = (((a >> 16) & 255) * inverse + ((b >> 16) & 255) * amount) >> 4;
    const uint32_t g = (((a >> 8) & 255) * inverse + ((b >> 8) & 255) * amount) >> 4;
    const uint32_t blue = ((a & 255) * inverse + (b & 255) * amount) >> 4;
    return (r << 16) | (g << 8) | blue;
}
} // namespace breakline_motion
