// Spleen derived, Copyright (c) 2018-2026 Frederic Cambus. BSD-2-Clause.
// bazillOS Spore Phosphor: stronger stems with unchanged advances and cell bounds.
// See licenses/Spleen-BSD-2-Clause.txt; retained UI control glyphs keep CE terms.
#pragma once
#include "NewDisplay/CompressionRLE.h"
extern const CompressedData SporeLabel_L4_compressed[2828];
