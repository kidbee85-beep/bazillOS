#ifndef FILEMANAGER_PATTERNSMETADATA_H_
#define FILEMANAGER_PATTERNSMETADATA_H_

#include <stdint.h>
#include "breakline/pattern_copy.hpp"

class FileSystem;

class PatternsMetadata
{
  public:
    void init(FileSystem* fileSystem);
    void loadPatternsMetadata();
    bool copyPatternsMetadata(const char* src, const char* dest);

    char* getPatternName(int idx);
    void setPatternName(int idx, char* name);
    // Exclusive FileManager operation only; bounded staged writes, checked rename.
    bool beginCheckedPatternName(int idx, const char* name);
    breakline_pattern_copy::Result updateCheckedPatternName();

  private:
    bool readWorkspacePatternsMetadata();
    void writeWorkspacePatternsMetadata();
    bool readPatternsMetadata(const char* path);
    void writePatternsMetadata(const char* path);
    bool validatePatternsMetadata();

    FileSystem* fileSystem;

    bool successfulRead;
    breakline_pattern_copy::StagedWriter checkedWriter;
    char checkedOldName[31]{};
    int checkedIndex = -1;
    void* checkedFile = nullptr;
};

#endif /* FILEMANAGER_PATTERNSMETADATA_H_ */
