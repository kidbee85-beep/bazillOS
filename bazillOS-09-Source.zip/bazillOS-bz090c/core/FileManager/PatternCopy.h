// SPDX-License-Identifier: MIT
#pragma once
#include "Platform.h"
#include "breakline/pattern_copy.hpp"

class PatternCopy {
    breakline_pattern_copy::Job job;
    breakline_pattern_copy::Result result = breakline_pattern_copy::Result::idle;
    FileSystem::FileHandle file = nullptr;
    char destinationPath[48]{};
    char copiedName[31]{};
  public:
    bool begin();
    void update();
    int destination() const { return job.destination(); }
    breakline_pattern_copy::Result getResult() const { return result; }
    bool occupied(uint16_t index);
    void setDestination(uint16_t index);
    bool temporaryExists();
    bool backupExists() { return false; }
    bool targetExists();
    bool openTemporary();
    size_t writeTemporary(const uint8_t* data, size_t size);
    void closeTemporary();
    size_t temporarySize();
    bool backupTarget() { return false; }
    bool publishTemporary();
    bool restoreBackup() { return false; }
    bool removeBackup() { return false; }
    bool removeTemporary();
    bool removeCopiedPattern();
    bool beginMetadata(uint16_t index);
    breakline_pattern_copy::Result tickMetadata();
    void commit(uint16_t index);
};
