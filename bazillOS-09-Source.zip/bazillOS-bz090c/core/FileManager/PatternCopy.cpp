// SPDX-License-Identifier: MIT
#include "PatternCopy.h"
#include "fileManager.h"
#include "fileManagerDefs.h"
#include "fileTransfer.h"
#include <cstdio>
#include <cstring>

extern uint8_t externalRamFileManagerSrcBuff[READ_WRITE_BUFOR_SIZE];
namespace { constexpr char kStage[] = "Workspace/patterns/.breakline-copy.tmp"; }

bool PatternCopy::begin()
{
    using breakline_pattern_copy::Result;
    if (result == Result::busy || temporaryExists()) return false;
    const int source = mtProject.values.actualPattern;
    const char* name = newFileManager.getPatternsMetadata()->getPatternName(source);
    if (name && name[0]) snprintf(copiedName, sizeof(copiedName), "%.25s copy", name);
    else snprintf(copiedName, sizeof(copiedName), "Pattern %03d copy", source);
    file = nullptr;
    job.begin(source, sizeof(Sequencer::strPattern));
    result = Result::busy;
    return true;
}

void PatternCopy::update()
{
    result = job.tick(*this, externalRamFileManagerSrcBuff);
    if (result != breakline_pattern_copy::Result::busy) {
        newFileManager.setStatus(fmIdle);
        newFileManager.setCurrentOperation(fmNoOperation);
    }
}

bool PatternCopy::occupied(uint16_t index)
{
    // A missing file with pending edits or a nonempty project bitmask is not free.
    if (newFileManager.isPatternStructChanged(index) ||
        mtProject.values.allPatternsBitmask[index - 1] ||
        mtProject.values.allPatternsBitmaskMidi[index - 1]) return true;
    char path[48]; snprintf(path, sizeof(path), cWorkspacePatternFileFormat, index);
    return newFileManager.getFileSystem()->exists(path);
}
void PatternCopy::setDestination(uint16_t index) {
    snprintf(destinationPath, sizeof(destinationPath), cWorkspacePatternFileFormat, index);
}
bool PatternCopy::temporaryExists() { return newFileManager.getFileSystem()->exists(kStage); }
bool PatternCopy::targetExists() { return newFileManager.getFileSystem()->exists(destinationPath); }
bool PatternCopy::openTemporary() {
    auto opened = newFileManager.getFileSystem()->openFile(kStage, FileSystem::kWriteCreateNew);
    file = std::get<1>(opened); return std::get<0>(opened);
}
size_t PatternCopy::writeTemporary(const uint8_t* data, size_t size) {
    return newFileManager.getFileSystem()->writeFile(data, size, file);
}
void PatternCopy::closeTemporary() {
    if (file) newFileManager.getFileSystem()->closeFile(file);
    file = nullptr;
}
size_t PatternCopy::temporarySize() { return newFileManager.getFileSystem()->getFileSize(kStage); }
bool PatternCopy::publishTemporary() {
    return newFileManager.getFileSystem()->rename(kStage, destinationPath);
}
bool PatternCopy::removeTemporary() { return newFileManager.getFileSystem()->remove(kStage); }
bool PatternCopy::removeCopiedPattern() { return newFileManager.getFileSystem()->remove(destinationPath); }
bool PatternCopy::beginMetadata(uint16_t index) {
    return newFileManager.getPatternsMetadata()->beginCheckedPatternName(index, copiedName);
}
breakline_pattern_copy::Result PatternCopy::tickMetadata() {
    return newFileManager.getPatternsMetadata()->updateCheckedPatternName();
}
void PatternCopy::commit(uint16_t index) {
    // Never switch/load a pattern, clear source changes, or call saveToFileDone().
    newFileManager.updatePatternBitmask(index,
      reinterpret_cast<Sequencer::strPattern*>(externalRamFileManagerSrcBuff));
    newFileManager.clearPatternChanged(index); // copied file is already saved in Workspace
    newFileManager.setProjectStructChanged();
    mtProject.values.projectNotSavedFlag |= 1;
}
