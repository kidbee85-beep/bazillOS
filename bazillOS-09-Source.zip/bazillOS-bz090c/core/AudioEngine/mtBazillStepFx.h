#pragma once
#include <stdint.h>

namespace BazillStepFx {
enum Kind : uint8_t { Crush, Space, Wobble, Orbit, Radio, Acid, Ghost, Dust, Halo, Dive, Rust, Spore, Count };
enum Control : uint8_t { kDrive, kBits, kDelay, kReverb, kLowpass, kBandpass, kHighpass, kReverse,
                         kTune, kPosition, kPan, kFinetune, kFilterLfo, kFinetuneLfo, kPanLfo, kPositionLfo };
struct Command { Control control; uint8_t value; };
struct Recipe { Command commands[3]; uint8_t count; };
inline uint8_t scale(uint8_t v, int lo, int hi) { return uint8_t(lo + (hi-lo)*int(v)/100); }
inline uint16_t mask(Control c) {
    if (c == kBandpass || c == kHighpass) c = kLowpass;
    return uint16_t(1u << unsigned(c));
}
inline uint16_t mask(const Recipe& r) {
    uint16_t result=0;
    for (uint8_t i=0;i<r.count;++i) result |= mask(r.commands[i].control);
    return result;
}
inline Recipe recipe(uint8_t kind, uint8_t value, uint8_t maxLfoRate) {
    const uint8_t v=value>100?100:value;
    const uint8_t rate=value>maxLfoRate?maxLfoRate:value;
    switch (kind) {
        case Crush: return {{{kDrive,v},{kBits,scale(v,16,4)}},2};
        case Space: return {{{kDelay,v},{kReverb,v}},2};
        case Wobble: return {{{kFilterLfo,rate},{kFinetuneLfo,rate}},2};
        case Orbit: return {{{kPanLfo,rate},{kPositionLfo,rate}},2};
        case Radio: return {{{kBandpass,scale(v,35,70)},{kBits,scale(v,16,6)}},2};
        case Acid: return {{{kLowpass,v},{kDrive,scale(v,0,85)}},2};
        case Ghost: return {{{kReverse,1},{kReverb,v}},2};
        case Dust: return {{{kLowpass,scale(v,100,18)},{kBits,scale(v,16,4)}},2};
        case Halo: return {{{kTune,36},{kReverb,v}},2};
        case Dive: return {{{kTune,scale(v,24,0)},{kLowpass,scale(v,100,12)}},2};
        case Rust: return {{{kReverse,1},{kDrive,v}},2};
        case Spore: {
            // A value is a stable seed: restoring the other FX column never rerolls it.
            uint32_t x=uint32_t(v)*0x9e3779b9u;
            x ^= x>>16; x *= 0x7feb352du; x ^= x>>15;
            const uint8_t position=v?uint8_t(x%86u):0;
            const uint8_t pan=v?uint8_t((x>>8)%101u):50;
            return {{{kPosition,position},{kPan,pan}},2};
        }
        default: return {{},0};
    }
}
} // namespace BazillStepFx
