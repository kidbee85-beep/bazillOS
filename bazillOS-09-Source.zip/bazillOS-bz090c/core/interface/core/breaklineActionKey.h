#pragma once
#include <cstdint>
namespace breakline_action_key {
enum class Event : std::uint8_t { Press, Hold, Release };
enum class Action : std::uint8_t { None, Tap, Press, Hold, Release, ShowHelp, HideHelp };
enum class Phase : std::uint8_t { Idle, Pending, Editing, Help, Canceled };
struct Stamp { std::uint32_t epoch=0; std::uint8_t context=0; bool shift=false; };
inline bool same(Stamp a,Stamp b){return a.epoch==b.epoch&&a.context==b.context&&a.shift==b.shift;}
inline bool eligible(std::uint8_t context,std::uint8_t key){
    return key<8&&(context==1||context==2||context==4||context==5||context==6||(context==3&&key==3));
}
struct State { Phase phase=Phase::Idle; Stamp stamp{}; std::uint32_t order=0; };
class Gate {
public:
    explicit Gate(std::uint32_t initialOrder=0):order(initialOrder){}
    Action key(std::uint8_t key,Event event,Stamp now){
        if(key>=8)return Action::None;
        auto& state=states[key];
        if(event==Event::Press){
            if(state.phase==Phase::Idle&&now.context){state.phase=Phase::Pending;state.stamp=now;state.order=++order;}
            return Action::None;
        }
        if(state.phase==Phase::Idle)return Action::None;
        if(!same(state.stamp,now)){
            state.phase=event==Event::Release?Phase::Idle:Phase::Canceled;return Action::None;
        }
        if(event==Event::Hold){
            if(state.phase==Phase::Pending){state.phase=Phase::Editing;return Action::Press;}
            return state.phase==Phase::Editing?Action::Hold:Action::None;
        }
        const auto phase=state.phase;state.phase=Phase::Idle;
        return phase==Phase::Pending?Action::Tap:phase==Phase::Editing?Action::Release:
               phase==Phase::Help?Action::HideHelp:Action::None;
    }
    std::int8_t takeAdjustment(Stamp now){
        int found=-1;
        for(unsigned i=0;i<8;++i){auto& state=states[i];
            if(state.phase!=Phase::Pending)continue;
            if(!same(state.stamp,now)){state.phase=Phase::Canceled;continue;}
            if(found<0||static_cast<std::int32_t>(state.order-states[found].order)<0)found=i;
        }
        if(found>=0)states[found].phase=Phase::Editing;
        return static_cast<std::int8_t>(found);
    }
    std::uint8_t adjust(Stamp now){
        std::uint8_t mask=0;int key;
        while((key=takeAdjustment(now))>=0)mask|=static_cast<std::uint8_t>(1u<<key);
        return mask;
    }
    void reset(){for(auto& state:states)if(state.phase!=Phase::Idle)state.phase=Phase::Canceled;}
    bool down(std::uint8_t key)const{return key<8&&states[key].phase!=Phase::Idle;}
    Stamp stamp(std::uint8_t key)const{return key<8?states[key].stamp:Stamp{};}
private:State states[8]{};std::uint32_t order=0;
};
// The same adapter is used on device and in tests. A Press may switch screens
// or bindings, so never emit its Release into a different generation.
template<class Current,class Emit>
void dispatch(Action action,std::uint8_t key,Stamp captured,Current current,Emit emit){
    if(!same(captured,current()))return;
    if(action==Action::Tap){
        emit(key,Event::Press);
        if(same(captured,current()))emit(key,Event::Release);
    }else if(action==Action::Press)emit(key,Event::Press);
    else if(action==Action::Hold)emit(key,Event::Hold);
    else if(action==Action::Release)emit(key,Event::Release);
}
}
