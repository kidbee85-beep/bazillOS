#ifndef BREAKLINE_FUNCTION_KEY_H
#define BREAKLINE_FUNCTION_KEY_H
#include <stdint.h>
namespace breakline_function_key {
enum class Event : uint8_t { Press, Hold, Release };
enum class Action : uint8_t { None, Tap, ShowHelp, HideHelp };
struct State { bool down = false; bool help = false; uint8_t binding = 0; };
inline Action update(State& state, Event event, uint8_t binding)
{
    if (event == Event::Press)
    {
        // Ignore duplicate press notifications; keep the original Shift binding.
        if (!state.down) { state.down = true; state.help = false; state.binding = binding; }
        return Action::None;
    }
    if (!state.down) return Action::None;
    if (event == Event::Hold)
    {
        return Action::None;
    }
    state.down = false;
    return state.help ? Action::HideHelp : Action::Tap;
}
} // namespace breakline_function_key
#endif
