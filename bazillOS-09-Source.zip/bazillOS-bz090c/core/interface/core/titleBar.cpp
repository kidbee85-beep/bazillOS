#include "titleBar.h"
#include "core/interfaceDefs.h"
#include "display.h"
#ifdef TRACKER_MINI
#include "BreaklineMotion.h"
#include "BazillHeaderLayout.h"
#include "core/interface.h"
#include "patternEditor/patternEditor.h"
#include "sampleRecorder/sampleRecorder.h"
#include "Recorder.h"
static elapsedMillis recordBadgeTimer;
static elapsedMillis accentTimer;
#endif

#if GUI_HANDLE_SYNTH
#include "Profiler.h"
#include "Synth.h"
#endif

TitleBar titleBar;

static elapsedMillis refreshTimer;

#ifdef TRACKER_MINI
#define BATTERY_ENABLED 1
#endif

void TitleBar::init(Synth* synth, [[maybe_unused]] Battery* battery)
{
    this->synth = synth;
#ifdef BATTERY_ENABLED
    batteryDriver = battery;
    lastBatteryLevel = batteryDriver->getState() ? batteryDriver->getLevel() : kBatteryNotPresent;
#else
    batteryDriver = nullptr;
#endif
}

void TitleBar::initControls()
{
    strControlProperties prop;
#ifdef TRACKER_MINI
    prop.x = bazill_header::titleX;
#else
    prop.x = 9;
#endif
    prop.y = 13;
#ifdef TRACKER_MINI
    prop.w = bazill_header::titleWidth;
#else
    prop.w = 270;
#endif
    prop.colors = display.getTheme().topBarLabelColors;
#ifdef TRACKER_MINI
    prop.style = (controlStyleCenterY | controlStyleFont3 | controlStyleLimitTextWidth);
#else
    prop.style = (controlStyleCenterY | controlStyleFont4 | controlStyleLimitTextWidth);
#endif
    titleLabel = display.createControl<cLabel>(&prop);

    prop.y = 13;
#ifdef BATTERY_ENABLED
    prop.x = bazill_header::rightX;
    prop.w = bazill_header::rightWidth;
    prop.h = 0;
#else
    prop.x = 790;
#endif
    prop.colors = display.getTheme().topBarLabelColors;
#ifdef TRACKER_MINI
    prop.style = controlStyleRightX | controlStyleCenterY | controlStyleFont1 | controlStyleLimitTextWidth;
#else
    prop.style = (controlStyleRightX | controlStyleCenterY | controlStyleFont4);
#endif
    rightLabel = display.createControl<cLabel>(&prop);

#ifdef BATTERY_ENABLED
    prop.style = controlStyleShowBitmap | controlStyleCenterY;
    prop.colors = display.getTheme().batteryIconColors;
    prop.x = 795 - 28;
    prop.y = 13;
    prop.w = 28;
    prop.h = 13;
    prop.value = lastBatteryLevel;
    battery = display.createControl<cBattery>(&prop);
#endif

    prop.style = 0;
    prop.colors = &display.getTheme().red;
    prop.x = 297;
    prop.y = 0;
    prop.w = 170;
    prop.h = 1;
    prop.value = 0;
    performBox = display.createControl<SimpleBox>(&prop);

    barLabelData.line.color = display.getTheme().topBarLabelColors[2];
    barLabelData.line.x1 = 0;
    barLabelData.line.x2 = 800;
    barLabelData.line.y1 = 28;
    barLabelData.line.y2 = 28;

    prop.style = (controlStyleBackground | controlStyleSpecialFx);
#ifdef TRACKER_MINI
    prop.style |= controlStyleBazillChrome;
#endif
    prop.colors = display.getTheme().topBarLabelColors;
    prop.x = 0;
    prop.y = 0;
    prop.w = 800;
    prop.h = 28;
    prop.value = 0;
    prop.data = &barLabelData;
    bar = display.createControl<cLabel>(&prop);
}

void TitleBar::refreshColors()
{
    display.setControlColors(titleLabel, display.getTheme().topBarLabelColors);
    display.setControlColors(rightLabel, display.getTheme().topBarLabelColors);
#ifdef BATTERY_ENABLED
    display.setControlColors(battery, display.getTheme().batteryIconColors);
#endif
    display.setControlColors(performBox, &display.getTheme().red);
    barLabelData.line.color = display.getTheme().topBarLabelColors[2];
    display.setControlColors(bar, display.getTheme().topBarLabelColors);
}

void TitleBar::show(bool showRightLabel)
{
    display.setControlShow(titleLabel);
    display.refreshControl(titleLabel);

    if (showRightLabel)
    {
        display.setControlShow(rightLabel);
        display.refreshControl(rightLabel);
    }
    else
    {
        display.setControlHide(rightLabel);
    }

#ifdef BATTERY_ENABLED
    display.setControlShow(battery);
    display.refreshControl(battery);
#endif

    display.setControlShow(bar);
    display.refreshControl(bar);

    visible = true;
}

void TitleBar::setTitle(const char* text)
{
#ifdef TRACKER_MINI
    uint32_t hash=0;if(text)for(const char* p=text;*p;++p)hash=hash*33+static_cast<unsigned char>(*p);
    const uint32_t accents[]={0x63F6C5,0xD19AFF,0xF8BD62};accentColor=accents[hash%3];
    accentTotal=breakline_motion::mode()==breakline_motion::Mode::full?8:3;
    accentFrames=breakline_motion::mode()==breakline_motion::Mode::off?0:accentTotal;accentTimer=0;
    surfaceVariant=(hash%6)*2;
    display.setControlValue(bar,surfaceVariant | (unsigned(modeState)<<8) | (recordPulse?1024u:0u));
    barLabelData.line.color=modeState==3?bazill_header::recordAccent:modeState==2?bazill_header::armedAccent:modeState==1?bazill_header::editAccent:accentFrames?accentColor:0x2D405B;
    if(bar>=0)display.refreshControl(bar);
#endif
    display.setControlText(titleLabel, text);
    display.refreshControl(titleLabel);
}

void TitleBar::setRightLabel(const char* text)
{
    display.setControlText(rightLabel, text);
    display.refreshControl(rightLabel);
}

void TitleBar::showCurrentInstrumentOnRightLabel()
{
    static char actualInstrName[SAMPLE_NAME_SIZE + 1];
    actualInstrName[0] = 0;

    uint8_t idx = mtProject.values.lastUsedInstrument;

    if (idx >= SYNTH_INSTRUMENTS_START_IDX)
    {
#if GUI_HANDLE_SYNTH
        assert(synth);
        assert((idx - SYNTH_INSTRUMENTS_START_IDX) < kSynthInstrumentsCount);
        strncpy(actualInstrName,
                synth->getSynthName((idx - SYNTH_INSTRUMENTS_START_IDX)).c_str(),
                SAMPLE_NAME_SIZE);
        actualInstrName[SAMPLE_NAME_SIZE] = 0;
#endif
    }
    else if (idx >= MIDI_INSTRUMENTS_START_IDX)
    {
        snprintf(actualInstrName,
                 SAMPLE_NAME_SIZE,
                 "%d. MIDI Channel %d",
                 idx + 3,
                 (idx - MIDI_INSTRUMENTS_START_IDX) + 1);
    }
    else
    {
#ifdef SHOW_EMPTY_SLOT_LABEL
        if (mtProject.instrument[idx].isActive)
        {
#endif
            snprintf(actualInstrName,
                     SAMPLE_NAME_SIZE,
                     "%d. %s",
                     idx + 1,
                     mtProject.instrument[idx].sample.file_name);
#ifdef SHOW_EMPTY_SLOT_LABEL
        }
        else
        {
            snprintf(actualInstrName, SAMPLE_NAME_SIZE, "%d. Empty slot", idx + 1);
        }
#endif
    }

    display.setControlText(rightLabel, actualInstrName);
    display.setControlShow(rightLabel);
    display.refreshControl(rightLabel);
}

void TitleBar::setBatteryValue([[maybe_unused]] int valuePercent, [[maybe_unused]] bool charging)
{
#ifdef BATTERY_ENABLED
    if (charging)
    {
        display.setAddControlStyle(battery, controlStyleTransformImg);
    }
    else
    {
        display.setRemoveControlStyle(battery, controlStyleTransformImg);
    }

    display.setControlValue(battery, valuePercent);
    display.refreshControl(battery);
#endif
}

void TitleBar::showRightLabel(bool show)
{
    if (show)
    {
        display.setControlShow(rightLabel);
    }
    else
    {
        display.setControlHide(rightLabel);
    }
    display.refreshControl(rightLabel);
}

void TitleBar::showBattery(bool show)
{
    if (show)
    {
        display.setControlShow(battery);
    }
    else
    {
        display.setControlHide(battery);
    }
    display.refreshControl(battery);
}

void TitleBar::hide()
{
    display.setControlHide(titleLabel);
    // display.refreshControl(titleLabel);

    display.setControlHide(rightLabel);
    // display.refreshControl(rightLabel);

#ifdef BATTERY_ENABLED
    display.setControlHide(battery);
    // display.refreshControl(battery);
#endif

    display.setControlHide(bar);
    display.refreshControl(bar);

    visible = false;
}

void TitleBar::refresh()
{
#ifdef TRACKER_MINI
    const bool pattern=mtInterface.currentModuleForHelp()==&patternEditor;
    const bool sample=mtInterface.currentModuleForHelp()==&sampleRecorder;
    const auto next=static_cast<uint8_t>(bazill_header::mode(pattern,isEditMode(),sequencer.isRec(),sequencer.isPlay(),recorder.isRecordingActive(),sample&&sampleRecorder.startRecordingOnPreRollEnd));
    const unsigned pulseMs=breakline_motion::mode()==breakline_motion::Mode::full?500:1000;
    const bool pulse=next==3&&breakline_motion::mode()!=breakline_motion::Mode::off&&recordBadgeTimer>=pulseMs;
    if(next!=modeState||pulse){
        if(next!=modeState){modeState=next;recordPulse=false;}else recordPulse=!recordPulse;
        recordBadgeTimer=0;
        barLabelData.line.color=next==3?bazill_header::recordAccent:next==2?bazill_header::armedAccent:next==1?bazill_header::editAccent:0x2D405B;
        display.setControlValue(bar,surfaceVariant | (unsigned(modeState)<<8) | (recordPulse?1024u:0u));
        if(visible&&bar>=0)display.refreshControl(bar);
    }
    if(visible&&accentFrames&&accentTimer>=60){
        accentTimer=0;--accentFrames;uint32_t color=0;
        display.setControlValue(bar,surfaceVariant | (accentFrames==3 || accentFrames==2 ? 1 : 0) | (unsigned(modeState)<<8) | (recordPulse?1024u:0u));
        for(unsigned shift:{0u,8u,16u}){
            const unsigned quiet=(0x2D405B>>shift)&255,bright=(accentColor>>shift)&255;
            color|=((quiet*(accentTotal-accentFrames)+bright*accentFrames)/accentTotal)<<shift;
        }
        if(!modeState)barLabelData.line.color=color;if(bar>=0)display.refreshControl(bar);
    }
#endif

    if (refreshTimer < 300)
    {
        return;
    }

    refreshTimer = 0;

#if GUI_HANDLE_SYNTH
    Profiler::AudioProcessorUsage usage;
    Profiler::getInstance()->getAudioProcessingUsagePercent(usage, true);

    bool showBox = false;
    uint32_t boxColor = 0;

    if (usage.tempMaximum >= kPerformance1Treshold)
    {
        showBox = true;
        boxShowLoopCount = 0;

        if (usage.tempMaximum >= kPerformance3Treshold)
        {
            boxColor = display.getTheme().red;
        }
        else if (usage.tempMaximum >= kPerformance2Treshold)
        {
            boxColor = display.getTheme().orange;
        }
        else if (usage.tempMaximum >= kPerformance1Treshold)
        {
            boxColor = display.getTheme().yellow;
        }
    }

    if (showBox && boxLastColor != boxColor)
    {
        boxLastColor = boxColor;
        display.setControlColors(performBox, &boxLastColor);
        display.setControlShow(performBox);
        display.refreshControl(performBox);
    }
    else if (!showBox && boxLastColor)
    {
        if (boxShowLoopCount >= kBoxHideDelayLoopCount)
        {
            display.setControlHide(performBox);
            display.refreshControl(performBox);
            boxLastColor = 0;
        }
        else
        {
            boxShowLoopCount++;
        }
    }
#endif

#ifdef BATTERY_ENABLED
    if (!visible)
    {
        return;
    }

    bool state = batteryDriver->getState();
    int level = state ? batteryDriver->getLevel() : kBatteryNotPresent;
    bool charging = state ? batteryDriver->getCharging() : false;

    if (lastBatteryLevel != level || charging != lastBatteryCharging)
    {
        lastBatteryCharging = charging;
        lastBatteryLevel = level;
        setBatteryValue(lastBatteryLevel, lastBatteryCharging);
    }
#endif
}
