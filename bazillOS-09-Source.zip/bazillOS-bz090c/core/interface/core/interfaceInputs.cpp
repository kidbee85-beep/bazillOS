#include "core/interface.h"
#include "core/interfacePopups.h"

#include "Platform.h"
#include "breaklineFunctionKey.h"
#ifdef TRACKER_MINI
#include "breaklineActionKey.h"
#include "gameSynth/gameSynth.h"
#include "samplePlayback/BazillStudio.h"
#include "samplePlayback/BazillDrumLab.h"
#include "samplePlayback/samplePlayback.h"
#include "patternEditor/patternEditor.h"
#include "patternEditor/BazillComposer.h"
#include "performanceMode/BazillPunchDeck.h"
#include "instrumentEditor/instrumentEditor.h"
#include <cstring>
#endif
#include <stdio.h>

#ifdef TRACKER_MINI
bool fnButtonShiftPressed[4] = { false, false, false, false };

// Tracks currently active directional/middle button; 0 means none locked.
static uint8_t activeNavButton = 0;
static bool handleBreaklineActionKey(uint8_t button, uint8_t state);
static bool handleExplicitHelp(uint8_t button,uint8_t state);
static bool explicitHelpVisible=false;
static uint8_t explicitHelpPage=0;
static uint64_t helpSuppressedButtons=0;
static void beginBreaklineActionAdjustment();
static bool breaklineActionHelpVisible();


static inline bool isNavButton(uint8_t b)
{
    return b == interfaceButtonMiniMiddle || b == interfaceButtonUp || b == interfaceButtonDown ||
           b == interfaceButtonLeft || b == interfaceButtonRight;
}
#endif

//=======================================================================
void Interface::potChange(uint8_t n, int16_t value)
{
#ifdef TRACKER_MINI
    if (breaklineActionHelpVisible()) return;
    if (value) beginBreaklineActionAdjustment();
#endif
    ip->processPotsInput(n, value);
}

//=======================================================================
void Interface::buttonChange(uint8_t n, uint8_t value)
{
#ifdef TRACKER_MINI
    if (handleExplicitHelp(n,value)) return;
    if (handleBreaklineActionKey(n, value)) return;
    if(bazillComposer.isActive()&&n==interfaceButtonMiniMiddle&&value==buttonHold)return;
    if (isNavButton(n))
    {
        // If another nav button is locked, ignore this event until it releases.
        if (activeNavButton != 0 && n != activeNavButton)
        {
            return;
        }

        if (value == buttonPress)
        {
            activeNavButton = n;
        }
        else if (value == buttonRelease && n == activeNavButton)
        {
            activeNavButton = 0;
        }
    }
#endif

    if (value == buttonHold &&
        ((n >= 25 && n <= 27) || (n >= 30 && n <= 32) || n == interfaceButtonMiniMiddle))
    {
        ip->processButtonsInput(n, buttonPress);
    }
    else
    {
        ip->processButtonsInput(n, value);
    }
}

//=======================================================================
bool Interface::powerButtonChange(uint8_t state)
{
    if (ip->isPowerButtonBlocked())
    {
        return false;
    }

    if (state == 1 && getPlatform()->getButtons()->isButtonPressed(interfaceButtonShift))
    {
        display.scheduleScreenShot(1);

        return true;
    }

    return ip->processPowerButton(state);
}

//=======================================================================
void Interface::padPressed(uint8_t n, int8_t, int8_t, uint8_t velo)
{
    ip->processPadsInput(n, 1, velo);
}

//=======================================================================
void Interface::padReleased(uint8_t n)
{
    ip->processPadsInput(n, 0, 0);
}

//=======================================================================
void Interface::padHold(uint8_t n)
{
    ip->processPadsInput(n, 2, 0);
}

//=======================================================================
#ifdef TRACKER_MINI
// Configurable shortcuts retain their captured Shift binding until release.
// Context help is explicitly opened with Shift+Menu; ordinary holds never open it.
static breakline_function_key::State breaklineFnState[4];
static uint8_t breaklineHelpOwner = 255;
static char breaklineHelpTitle[64];
static char breaklineHelpShortcut[72];

static void showBreaklineFunctionHelp(uint8_t key, uint8_t binding)
{
    uint8_t context = 0;
    for (uint8_t i = 0; i < kMenuModulesCount; ++i)
        if (InterfaceMenuPopup::modules[i].module == mtInterface.currentModuleForHelp()) context = i;
    snprintf(breaklineHelpTitle, sizeof breaklineHelpTitle,
             "HELP / %s", kModuleNamesList[context]);
    snprintf(breaklineHelpShortcut, sizeof breaklineHelpShortcut,
             "Tap %u opens %s", unsigned(key+1), kModuleNamesList[binding]);
    static const char* const contextHints[12] = {
        "Arrows: cursor. +/-: edit selected value.",
        "Arrows: parameter. +/-: change its value.",
        "Arrows: playback setting. +/-: adjust.",
        "Arrows: mixer selection. +/-: level.",
        "Arrows: song position. +/-: pattern.",
        "Shift+Preview: random on this page.",
        "Arrows: browse files. Follow bottom labels.",
        "Arrows: select setting. +/-: change value.",
        "Use labelled actions for performance FX.",
        "Select an edit tool; use +/- to adjust.",
        "Choose recording source before recording.",
        "D-pad: steer. Middle: note."
    };
    display.setHelpModal(true);
    mtPopups.show(0, breaklineHelpTitle, breaklineHelpShortcut,
                  contextHints[context], "Release: back. Menu: modules.", 255);
}

static void functMiniFn(uint8_t key, uint8_t state)
{
    using namespace breakline_function_key;
    uint8_t binding = 0;
    if (state == buttonPress)
    {
        fnButtonShiftPressed[key] =
          mtInterface.getPlatform()->getButtons()->isButtonPressed(interfaceButtonShift);
        binding = mtConfig.interface.functionKeysBinding[key + (fnButtonShiftPressed[key] ? 4 : 0)];
        if (binding >= kMenuModulesCount) binding = 0;
    }
    Event event;
    if (state == buttonPress) event = Event::Press;
    else if (state == buttonHold) event = Event::Hold;
    else if (state == buttonRelease) event = Event::Release;
    else return;
    const Action action = update(breaklineFnState[key], event, binding);
    if (action == Action::ShowHelp && breaklineHelpOwner == 255)
    {
        breaklineHelpOwner = key;
        showBreaklineFunctionHelp(key, breaklineFnState[key].binding);
    }
    else if (action == Action::HideHelp && breaklineHelpOwner == key)
    {
        mtPopups.hide();display.setHelpModal(false);
        breaklineHelpOwner = 255;
    }
    else if (action == Action::Tap && breaklineHelpOwner == 255)
    {
        const uint8_t button = InterfaceMenuPopup::modules[breaklineFnState[key].binding].button;
        mtInterface.ip->processButtonsInput(button, buttonPress);
        mtInterface.ip->processButtonsInput(button, buttonRelease);
    }
    if (state == buttonRelease) fnButtonShiftPressed[key] = false;
}

static void functMiniFn1(uint8_t state) { functMiniFn(0, state); }
static void functMiniFn2(uint8_t state) { functMiniFn(1, state); }
static void functMiniFn3(uint8_t state) { functMiniFn(2, state); }
static void functMiniFn4(uint8_t state) { functMiniFn(3, state); }

static void functMiniPlus10(uint8_t state)
{
    if (mtInterface.getPlatform()->getButtons()->isButtonPressed(interfaceButtonShift))
    {
        if (state == buttonPress || state == buttonHold)
        {
            mtInterface.changeMasterVolume(10);
            return;
        }
        return;
    }

    if (state == buttonPress || state == buttonHold)
    {
        mtInterface.ip->processPotsInput(interfacePot0, 10, state);
    }
    else if (state == buttonRelease)
    {
        mtInterface.ip->processPotsInput(interfacePot0, 0, state);
    }
}

static void functMiniPlus1(uint8_t state)
{
    if (mtInterface.getPlatform()->getButtons()->isButtonPressed(interfaceButtonShift))
    {
        if (state == buttonPress || state == buttonHold)
        {
            mtInterface.changeMasterVolume(1);
            return;
        }
        return;
    }

    if (state == buttonPress || state == buttonHold)
    {
        mtInterface.ip->processPotsInput(interfacePot0, 1, state);
    }
    else if (state == buttonRelease)
    {
        mtInterface.ip->processPotsInput(interfacePot0, 0, state);
    }
}

static void functMiniMinus1(uint8_t state)
{
    if (mtInterface.getPlatform()->getButtons()->isButtonPressed(interfaceButtonShift))
    {
        if (state == buttonPress || state == buttonHold)
        {
            mtInterface.changeMasterVolume(-1);
            return;
        }
        return;
    }

    if (state == buttonPress || state == buttonHold)
    {
        mtInterface.ip->processPotsInput(interfacePot0, -1, state);
    }
    else if (state == buttonRelease)
    {
        mtInterface.ip->processPotsInput(interfacePot0, 0, state);
    }
}

static void functMiniMinus10(uint8_t state)
{
    if (mtInterface.getPlatform()->getButtons()->isButtonPressed(interfaceButtonShift))
    {
        if (state == buttonPress || state == buttonHold)
        {
            mtInterface.changeMasterVolume(-10);
            return;
        }
        return;
    }

    if (state == buttonPress || state == buttonHold)
    {
        mtInterface.ip->processPotsInput(interfacePot0, -10, state);
    }
    else if (state == buttonRelease)
    {
        mtInterface.ip->processPotsInput(interfacePot0, 0, state);
    }
}
#endif

void Interface::initSpecialMiniTrackerButtons()
{
#ifdef TRACKER_MINI
    ip->setButtonObj(interfaceButtonMiniFn1, functMiniFn1);
    ip->setButtonObj(interfaceButtonMiniFn2, functMiniFn2);
    ip->setButtonObj(interfaceButtonMiniFn3, functMiniFn3);
    ip->setButtonObj(interfaceButtonMiniFn4, functMiniFn4);

    ip->setButtonObj(interfaceButtonMiniPlus10, functMiniPlus10);
    ip->setButtonObj(interfaceButtonMiniPlus1, functMiniPlus1);
    ip->setButtonObj(interfaceButtonMiniMinus1, functMiniMinus1);
    ip->setButtonObj(interfaceButtonMiniMinus10, functMiniMinus10);
#endif
}

#ifdef TRACKER_MINI
namespace {
using ActionGate=breakline_action_key::Gate;
using KeyEvent=breakline_action_key::Event;
using KeyAction=breakline_action_key::Action;
using KeyStamp=breakline_action_key::Stamp;
ActionGate lowerActionGate;
uint32_t lowerActionEpoch=0;
uint8_t lowerActionHelpOwner=255;
char lowerActionCaption[8][32]{};
char lowerActionTitle[64]{};
KeyStamp lowerActionContext(){
    uint8_t context=0;
    if(mtInterface.currentModuleForHelp()==&gameSynth)context=1;
    else if(mtInterface.currentModuleForHelp()==&samplePlayback&&samplePlayback.chopLabOpen)context=2;
    else if(mtInterface.currentModuleForHelp()==&patternEditor&&bazillComposer.isActive())context=6;
    else if(mtInterface.currentModuleForHelp()==&patternEditor&&patternEditor.patternQuickActionIsBound())context=3;
    else if(mtInterface.currentModuleForHelp()==&samplePlayback&&bazillDrumLab.isActive())context=5;
    else if(mtInterface.currentModuleForHelp()==&samplePlayback&&bazillStudio.isActive())context=4;
    return {lowerActionEpoch,context,context?mtInterface.getPlatform()->getButtons()->isButtonPressed(interfaceButtonShift):false};
}
void emitLowerAction(uint8_t key,KeyEvent event){
    const uint8_t state=event==KeyEvent::Press?buttonPress:event==KeyEvent::Hold?buttonHold:buttonRelease;
    mtInterface.ip->processButtonsInput(key,state);
}
void showLowerActionHelp(uint8_t key){
    static const char* const orbitHints[8]={
        "WRITE twice copies the last completed16-step bar to the selected Pattern position. Play a full bar first. Arrows cancel confirmation; native Undo restores.",
        "PRESET opens32 Arcade sounds. +/- chooses; LOAD confirms the shown DREAMS slot and applies sound, key, scale, rhythm and note length. Shift+PRESET changes gate. PLAY cancels selection.",
        "SCALE selects Pentatonic, Minor or Dorian for future notes. ROOT changes the key. The last completed bar retains the notes you actually heard.",
        "SOUND cycles existing melodic synth parts or loaded unsliced samples. No patch is replaced. A new project can use its ready VAP part.",
        "GAME switches Pulse Pong and Virus Breaker. PLAY starts/stops the project-clock motion; Middle serves a new ball. No game-over screen stops the music.",
        "AUTO follows the ball so you can hear a musical result immediately. The arrows take manual paddle control. Press AUTO to let it help again.",
        "ROOT minus lowers future notes by one semitone. The game and its project-synchronized timing stay unchanged.",
        "ROOT plus raises future notes by one semitone. After a full bar, WRITE twice captures your last complete musical phrase."
    };
    static const char* const chopHints[8]={
        "Chop Studio: STYLE +/- chooses a recipe. Slice Lab: MODE +/- chooses Onsets/Evenly/Grid/Phrases; Shift+/- changes Drums/Breaks/Melodic. Original markers/audio stay until KEEP CUTS.",
        "CUTS, then +/- changes the maximum number of cuts, or the project-tempo grid division. No automatic BPM detection is claimed.",
        "DETAIL, then +/- changes onset sensitivity or the silence gap for phrases. Equal and Tempo Grid ignore this setting.",
        "NUDGE, then +/- moves the selected cut. Left/Right chooses a cut. Insert splits that region; Delete joins it to its neighbour. First start stays at zero.",
        "CHOP rebuilds the preview from the current recipe. This discards manual preview edits. The source sample and stored markers are unchanged.",
        "LISTEN or Play auditions the selected staged cut. Shift auditions the original. Tap again to stop. Left/Right chooses another cut.",
        "KEEP CUTS twice replaces the original marker map and enables Beat Slice playback. BACK before confirming discards the staged edits.",
        "BACK discards every staged cut and returns to Sample Playback. Original audio, markers and playback mode are retained."
    };
    static const char* const patternQuickHints[]={
      "Name this pattern using the original keyboard.","Name this track. Track names are stored in the project.",
      "Edit Sound opens the instrument on the current note: sample editor, MIDI mapping or synth patch editor. On an empty step the selected instrument is used.",
      "View 4/8 switches eight compact note/instrument tracks and four detailed tracks with FX. FX1/FX2 returns to detail. Shift+View copies current edits to the next free pattern; the current pattern stays selected.",
      "Punch Deck opens the64 live sample-effect combinations. Left/Right chooses track; Up/Down changes bank.",
      "Master FX opens Master Lab with genre, reverb, delay, bass, width and EQ presets. Preview, compare, then Apply.",
      "Tap Tempo to select BPM; tap it again for global Swing. +/- edits; Shift makes fine BPM changes. Internal clock only. Native Swing FX takes priority.",
      "More cycles the three Pattern action pages. Shift+More switches4/8tracks directly from any normal Pattern page."
    };
    const auto context=explicitHelpVisible?lowerActionContext().context:lowerActionGate.stamp(key).context;
    if(context==1)gameSynth.cancelConfirmationForHelp();
    if(context==2){samplePlayback.chopApplyArmed=false;samplePlayback.showChopLab();}
    if(context==4)bazillStudio.cancelConfirmation();
    if(context==5)bazillDrumLab.cancelConfirmation();
    if(context==6)bazillComposer.cancelConfirmation();
    snprintf(lowerActionTitle,sizeof lowerActionTitle,"HELP / %s",context==1?"MUSIC ARCADE":context==2?"CHOP LAB":context==4?"bazillOS STUDIO":context==5?"DRUM LAB":context==6?"COMPOSER":"PATTERN");
    display.setHelpModal(true);
    mtPopups.show(0,lowerActionTitle,lowerActionCaption[key],
      context==1?orbitHints[key]:context==2?chopHints[key]:context==4?bazillStudio.help(key):context==5?bazillDrumLab.help(key):context==6?bazillComposer.help(key):
        patternQuickHints[key],
      "Left/Right: help page. Menu: return.",255);
}
}
void resetBreaklineActionHelp(){
    ++lowerActionEpoch;lowerActionGate.reset();
    if(explicitHelpVisible){mtPopups.hide();display.setHelpModal(false);explicitHelpVisible=false;}
    if(lowerActionHelpOwner!=255){mtPopups.hide();display.setHelpModal(false);lowerActionHelpOwner=255;}
}
bool isBreaklineActionHelpVisible(){return explicitHelpVisible||lowerActionHelpOwner!=255;}
static bool breaklineActionHelpVisible(){return isBreaklineActionHelpVisible();}
static void beginBreaklineActionAdjustment(){
    const auto context=lowerActionContext();
    if(!context.context||lowerActionHelpOwner!=255)return;
    int key;
    while((key=lowerActionGate.takeAdjustment(lowerActionContext()))>=0)
        breakline_action_key::dispatch(KeyAction::Press,key,lowerActionGate.stamp(key),lowerActionContext,emitLowerAction);
}
static bool handleBreaklineActionKey(uint8_t button,uint8_t state){
    const auto context=lowerActionContext();
    const bool accepts=breakline_action_key::eligible(context.context,button);
    if(button<8&&(accepts||lowerActionGate.down(button))){
        if(breaklineHelpOwner!=255){
            if(state==buttonRelease)lowerActionGate.key(button,KeyEvent::Release,context);
            return true; // A configurable Fn help already owns the popup.
        }
        if(state==buttonPress&&!lowerActionGate.down(button)&&
           !display.copyBottomActionCaption(button,lowerActionCaption[button],sizeof lowerActionCaption[button]))return false;
        const auto event=state==buttonPress?KeyEvent::Press:state==buttonHold?KeyEvent::Hold:KeyEvent::Release;
        const auto action=lowerActionGate.key(button,event,context);
        if(action==KeyAction::ShowHelp&&lowerActionHelpOwner==255){
            lowerActionHelpOwner=button;showLowerActionHelp(button);
        }else if(action==KeyAction::HideHelp&&lowerActionHelpOwner==button){
            mtPopups.hide();display.setHelpModal(false);lowerActionHelpOwner=255;
        }else if(lowerActionHelpOwner==255)
            breakline_action_key::dispatch(action,button,lowerActionGate.stamp(button),lowerActionContext,emitLowerAction);
        return true;
    }
    if(!context.context)return false;
    const bool adjust=isNavButton(button)||(button>=interfaceButtonMiniPlus10&&button<=interfaceButtonMiniMinus10);
    if(lowerActionHelpOwner!=255&&adjust)return true;
    if((button==interfaceButtonShift&&(state==buttonPress||state==buttonRelease))||
       (state==buttonPress&&(button==interfaceButtonMiniMenu||
        (button>=interfaceButtonMiniFn1&&button<=interfaceButtonMiniFn4))))resetBreaklineActionHelp();
    else if(adjust&&(state==buttonPress||state==buttonHold))beginBreaklineActionAdjustment();
    return false;
}

static void showExplicitHelpPage(){
    const auto context=lowerActionContext();
    if(context.context&&context.context!=3){
        display.copyBottomActionCaption(explicitHelpPage,lowerActionCaption[explicitHelpPage],sizeof lowerActionCaption[0]);
        showLowerActionHelp(explicitHelpPage);return;
    }
    char caption[32]{};display.copyBottomActionCaption(explicitHelpPage,caption,sizeof caption);
    unsigned module=0;for(unsigned i=0;i<kMenuModulesCount;++i)
        if(InterfaceMenuPopup::modules[i].module==mtInterface.currentModuleForHelp())module=i;
    static const char* const tips[12]={
      "REC toggles EDIT. Browse is cool blue; EDIT is turquoise. ARMED is amber; active recording is coral. Arrows select steps; +/- edits. Bottom labels show the current actions.",
      "Select a sample or synth instrument. Load Patch chooses a sound; Edit Patch changes its parameters. PERC notes select the individual drum sounds.",
      "Chop Studio builds and edits sample cuts. Chop Patterns arranges those cuts into rhythms. Drum Lab and Live Spectrum are separate tools.",
      "Arrows select mixer settings; +/- changes values. Master Lab adds genre, reverb and delay presets plus a live pre-codec spectrum. APPLY keeps a preview; BACK restores it. Original effects and routing remain available.",
      "Song mode arranges patterns. Demo Songs are available on the Projects page; save your edits before loading another project.",
      "Browse and preview a sample, then load it into an instrument slot. Drum Lab SOUND can use these loaded one-shots per role.",
      "Open Project loads your existing projects; Save As creates a separate copy. The Demo Songs button opens the supplied multi-genre library.",
      "Arrows select a setting and +/- adjusts it. Firmware shows the installed version and build.",
      "Punch Deck: press for an effect; release restores. Shift+Middle toggles latch. Left/Right selects the track; Up/Down selects the effect page; +/- changes intensity. REC clears all punches.",
      "Select a sample editing tool and follow the bottom labels. Chop Studio stages markers before applying them.",
      "Choose recording source and level first. The red REC header identifies active recording; ARMED is waiting for its trigger.",
      "Arcade Synth: Pong and Virus Breaker run on the project clock. Arrows move the paddle, Middle serves, AUTO helps. After a full bar, WRITE twice captures it."
    };
    std::snprintf(breaklineHelpTitle,sizeof breaklineHelpTitle,"HELP / %s / %u OF 8",kModuleNamesList[module],explicitHelpPage+1);
    display.setHelpModal(true);
    mtPopups.show(0,breaklineHelpTitle,caption,tips[module],"Left/Right: help page. Menu: return. Shift+Menu opens help.",255);
}
static bool handleExplicitHelp(uint8_t button,uint8_t state){
    if(button>=64)return false;
    const uint64_t bit=uint64_t(1)<<button;
    if(explicitHelpVisible){
        if(state==buttonPress)helpSuppressedButtons|=bit;
        if(state==buttonRelease){helpSuppressedButtons&=~bit;if(button<8)lowerActionGate.key(button,KeyEvent::Release,lowerActionContext());}
        if(button==interfaceButtonMiniMenu&&state==buttonPress){
            resetBreaklineActionHelp();activeNavButton=0;return true;
        }
        if(state==buttonPress&&(button==interfaceButtonLeft||button==interfaceButtonRight)){
            explicitHelpPage=(explicitHelpPage+(button==interfaceButtonRight?1:7))%8;showExplicitHelpPage();
        }
        return true;
    }
    if(helpSuppressedButtons&bit){if(state==buttonRelease){helpSuppressedButtons&=~bit;if(button<8)lowerActionGate.key(button,KeyEvent::Release,lowerActionContext());}return true;}
    if(button!=interfaceButtonMiniMenu||state!=buttonPress||
       !mtInterface.getPlatform()->getButtons()->isButtonPressed(interfaceButtonShift)||
       display.isHelpModal())return false;
    // Never turn a pending action into a tap when opening/closing help.
    resetBreaklineActionHelp();activeNavButton=0;sequencer.stopManualNotes();instrumentEditor.cancelPercPreview();
    for(auto& key:breaklineFnState)key={};
    for(unsigned i=0;i<44;++i)if(mtInterface.getPlatform()->getButtons()->isButtonPressed(i))
        helpSuppressedButtons|=uint64_t(1)<<i;
    helpSuppressedButtons|=bit;
    explicitHelpVisible=true;explicitHelpPage=0;showExplicitHelpPage();return true;
}
#endif
