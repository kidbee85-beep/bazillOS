#include "interfaceMenuPopup.h"
#include "core/interface.h"
#ifdef TRACKER_MINI
#include "samplePlayback/samplePlayback.h"
#include "projectEditor/projectEditor.h"
#include "instrumentEditor/instrumentEditor.h"
#include "breakline/menu_routes.hpp"
#endif

InterfaceMenuPopup mtMenuPopup;

#ifdef TRACKER_MINI
const uint8_t kMenuModulesCount = 12;
#else
const uint8_t kMenuModulesCount = 11;
#endif
const char* const kModuleNamesList[kMenuModulesCount] = { "Pattern",
                                                          "Instrument Parameters",
                                                          "Sample Playback",
                                                          "Master",
                                                          "Song",
                                                          "Sample Loader",
                                                          "File",
                                                          "Config",
                                                          "Perform",
                                                          "Sample Editor",
                                                          "Sample Recorder"
#ifdef TRACKER_MINI
                                                        , "Arcade Synth"
#endif
};

#ifdef TRACKER_MINI

uint32_t instrumentParamOptions[2] = { 1, 2 };
InterfaceMenuPopup::ModuleModes instrumentParamModes = { 2, instrumentParamOptions, { 2, 0 } };
uint32_t masterOptions[4] = { (1 << 8), (2 << 8), (3 << 8), (4 << 8) };
InterfaceMenuPopup::ModuleModes masterModes = { 4, masterOptions, { 4, 0 } };
uint32_t performOptions[3] = { 100, 1, 2 };
InterfaceMenuPopup::ModuleModes performModes = { 3, performOptions, { 3, 0 } };
uint32_t performancePageOptions[2]={1,2};
InterfaceMenuPopup::ModuleModes performancePageModes={2,performancePageOptions,{2,0}};

uint32_t sampleStudioOptions[7]={100,101,102,103,104,105,106};
InterfaceMenuPopup::ModuleModes sampleStudioModes={7,sampleStudioOptions,{7,0}};
uint32_t musicGameOptions[2]={100,101};
InterfaceMenuPopup::ModuleModes musicGameModes={2,musicGameOptions,{2,0}};
uint32_t chopWorkspaceOptions[3]={101,106,105};
InterfaceMenuPopup::ModuleModes chopWorkspaceModes={3,chopWorkspaceOptions,{3,0}};
static InterfaceMenuPopup::ModuleModes* tileModes(unsigned kind){
 switch(kind){case 1:return &chopWorkspaceModes;case 2:return &instrumentParamModes;case 3:return &musicGameModes;case 4:return &performancePageModes;case 5:return &masterModes;default:return nullptr;}
}


const InterfaceMenuPopup::ModuleRef InterfaceMenuPopup::modules[kMenuModulesCount] = {
    { mtInterface.modules[2], interfaceButtonPattern, 0, nullptr },
    { mtInterface.modules[5], interfaceButtonParams, 0, &instrumentParamModes },
    { mtInterface.modules[3], interfaceButtonSamplePlay, 100, &sampleStudioModes },
    { mtInterface.modules[12], interfaceButtonMaster, 0, &masterModes },
    { mtInterface.modules[4], interfaceButtonSong, 0, nullptr },
    { mtInterface.modules[1], interfaceButtonSampleLoad, 0, nullptr },
    { mtInterface.modules[0], interfaceButtonFile, 0, nullptr },
    { mtInterface.modules[7], interfaceButtonConfig, 0, nullptr },
    { mtInterface.modules[9], interfaceButtonPerformance, 100, &performModes },
    { mtInterface.modules[6], interfaceButtonSampleEdit, 0, nullptr },
    { mtInterface.modules[8], interfaceButtonSampleRec, 0, nullptr },
    { mtInterface.modules[11], interfaceButtonGame, 0, &musicGameModes },

};

static void functLeftPopup();
static void functRightPopup();
static void functUpPopup();
static void functDownPopup();
static void functMiddlePopup();
static void functTogglePopup(uint8_t state);

static void functEncoderPopup(int16_t value);

void InterfaceMenuPopup::initPopupsDisplayControls()
{
    boxMenuData.columnsCount = kMenuColumnsCount;
    boxMenuData.rowsCount = kMenuRowsCount;
    boxMenuData.textList = (char**)modulesMenuTexts;
    boxMenuData.modes = modulesMenuModes;

    strControlProperties prop;
    prop.x = (800 - kMenuWidth) / 2;
    prop.y = 32;
    prop.w = kMenuWidth;
    prop.h = kMenuHeight;
    prop.style = controlStyleCenterX | controlStyleCenterY | controlStyleFont3;
    prop.data = &boxMenuData;
    prop.text = nullptr;
    prop.colors = display.getTheme().miniBoxMenuColors;
    boxMenu = display.createControl<cBoxMenu>(&prop);
}

void InterfaceMenuPopup::refreshColors()
{
    display.setControlColors(boxMenu, display.getTheme().miniBoxMenuColors);
}

void InterfaceMenuPopup::showModulePopup(ModuleBase* sourceModule,
                                         void (*switchModuleCallback)(uint8_t))
{
    constexpr int boxesCount = kMenuRowsCount * kMenuColumnsCount;

    InterfaceMenuPopup::switchModuleCallback = switchModuleCallback;

    selectedModuleOnShow=0;
    for(unsigned m=0;m<kMenuModulesCount;++m)if(modules[m].module==sourceModule){selectedModuleOnShow=m;break;}
    const auto& original=modules[selectedModuleOnShow];
    sourceStartOption=original.defaultOption;
    if(original.modes){const unsigned mode=sourceModule->getCurrentModeIdx();if(mode<original.modes->count)sourceStartOption=original.modes->options[mode];}
    selectedBox=0;bool found=false;
    for(unsigned box=0;box<boxesCount;++box){
        const auto& tile=bazill_menu::tiles[box];
        menuFunctions[box]=tile.module;
        auto* pages=tileModes(tile.pages);menuModes[box]=pages;
        uint32_t option=tile.option;
        if(pages){
            // Remember each tool's page independently, with the active view first.
            if(tile.module==selectedModuleOnShow)for(unsigned p=0;p<pages->count;++p)if(pages->options[p]==sourceStartOption)pages->modes.current=p;
            if(pages->modes.current>=pages->count)pages->modes.current=0;
            option=pages->options[pages->modes.current];
        }
        menuStartOptions[box]=option;
        modulesMenuModes[box]=pages?&pages->modes:nullptr;
        modulesMenuTexts[box]=bazill_menu::name(tile.module,option);
        if(tile.module==selectedModuleOnShow&&(!found||option==sourceStartOption)){
            if(!found||option==sourceStartOption){selectedBox=box;found=true;}
            if(option==sourceStartOption)found=true;
        }
    }
    this->sourceModule = sourceModule;
    isVisible = true;

    setModulePopupFunct();

    display.setMenuModal(true, boxMenu);
    sourceModule->hideControlsUnderMiniMenu();

    display.setControlValue(boxMenu, selectedBox);
    display.setControlShow(boxMenu);
    display.refreshControl(boxMenu);

    display.synchronizeRefresh();
}

void InterfaceMenuPopup::hideModulePopup(ModuleBase* modulePtr)
{
    if(!isVisible)return;
    display.setMenuModal(false);
    display.setControlHide(boxMenu);

    mtInterface.ip->clearButton(interfaceButtonLeft);
    mtInterface.ip->clearButton(interfaceButtonRight);
    mtInterface.ip->clearButton(interfaceButtonUp);
    mtInterface.ip->clearButton(interfaceButtonDown);
    mtInterface.ip->clearButton(interfaceButtonMiniMiddle);

    mtInterface.ip->clearAllPots();

    display.refreshControl(boxMenu);

    display.synchronizeRefresh();

    isVisible = false;

    uint8_t moduleToSwitch = modules[menuFunctions[selectedBox]].button;
    uint32_t startOptions = menuStartOptions[selectedBox];
    
    if(menuFunctions[selectedBox]==1&&startOptions==100)instrumentEditor.synthShortcutRequested=8;
    if(menuFunctions[selectedBox]==1&&startOptions==101)instrumentEditor.synthShortcutRequested=5;
    // Editor/Recorder callbacks carry only the button. Retain this harmless UI mode
    // preference while they complete their existing save/recording safeguards.
    if(menuFunctions[selectedBox]==2 && startOptions>=100 && startOptions<=106)
        samplePlayback.studioMode=static_cast<uint8_t>(startOptions-100);

    if (modules[selectedModuleOnShow].button != modules[menuFunctions[selectedBox]].button)
    {
        if (switchModuleCallback != nullptr)
        {
            switchModuleCallback(moduleToSwitch);
            switchModuleCallback = nullptr;
        }
        else
        {
            modulePtr->eventFunct(eventSwitchModule, modulePtr, &moduleToSwitch, &startOptions);
        }
    }
    else
    {
        if (switchModuleCallback != nullptr)
        {
            switchModuleCallback(moduleToSwitch);
            switchModuleCallback = nullptr;
        }
        else
        {
            modulePtr->start(startOptions);
        }
    }
}

void InterfaceMenuPopup::setModulePopupFunct()
{
    mtInterface.ip->clearButtonsRange(interfaceButton0, interfaceButton32);

    mtInterface.ip->setPotObj(interfacePot0, functEncoderPopup);

    mtInterface.ip->setButtonObj(interfaceButtonLeft, buttonPress, functLeftPopup);
    mtInterface.ip->setButtonObj(interfaceButtonRight, buttonPress, functRightPopup);
    mtInterface.ip->setButtonObj(interfaceButtonUp, buttonPress, functUpPopup);
    mtInterface.ip->setButtonObj(interfaceButtonDown, buttonPress, functDownPopup);

    mtInterface.ip->setButtonObj(interfaceButtonMiniMiddle, buttonPress, functMiddlePopup);
    mtInterface.ip->setButtonObj(interfaceButtonMiniMenu,functTogglePopup);
}

void InterfaceMenuPopup::handleFailedSwitching()
{
    // source module handles functions assignment
    display.setMenuModal(false);
    display.setControlHide(boxMenu);
    display.refreshControl(boxMenu);
    display.synchronizeRefresh();

    isVisible = false;
}

void InterfaceMenuPopup::changeModulePopupValue(int16_t value, uint8_t dir)
{
    if (dir > 0)
    {
        switch (dir)
        {
            case 1:
                selectedBox = selectedBox < kMenuColumnsCount
                                ? ((kMenuRowsCount - 1) * kMenuColumnsCount) + selectedBox
                                : selectedBox - kMenuColumnsCount;
                break;
            case 2:
                selectedBox = selectedBox % kMenuColumnsCount >= kMenuColumnsCount - 1
                                ? selectedBox - (kMenuColumnsCount - 1)
                                : selectedBox + 1;
                break;
            case 3:
                selectedBox = selectedBox >= (kMenuRowsCount - 1) * kMenuColumnsCount
                                ? selectedBox - ((kMenuRowsCount - 1) * kMenuColumnsCount)
                                : selectedBox + kMenuColumnsCount;
                break;
            case 4:
                selectedBox = selectedBox % kMenuColumnsCount == 0
                                ? selectedBox + (kMenuColumnsCount - 1)
                                : selectedBox - 1;
                break;
            default: selectedBox = 0; break;
        }
        if (selectedBox >= kMenuRowsCount*kMenuColumnsCount)
        {
            selectedBox = kMenuRowsCount*kMenuColumnsCount - 1;
        }
    }
    else
    {
        if (selectedBox + value < 0)
        {
            selectedBox = 0;
        }
        else if (selectedBox + value > (kMenuRowsCount*kMenuColumnsCount - 1))
        {
            selectedBox = kMenuRowsCount*kMenuColumnsCount - 1;
        }
        else
        {
            selectedBox += value;
        }
    }
    display.setControlValue(boxMenu, selectedBox);
    display.refreshControl(boxMenu);
}

void InterfaceMenuPopup::setModulePopupValue(int16_t value)
{
    selectedBox = value<0?0:value>=kMenuRowsCount*kMenuColumnsCount?kMenuRowsCount*kMenuColumnsCount-1:value;

    display.setControlValue(boxMenu, value);
    display.refreshControl(boxMenu);
}

void InterfaceMenuPopup::changeModuleMode(int16_t direction)
{
    if(!isVisible||selectedBox>=kMenuRowsCount*kMenuColumnsCount)return;
    auto* modes=menuModes[selectedBox];
    if(!modes||!modes->count)return;
    const int count=modes->count;
    const unsigned next=(int(modes->modes.current)+(direction<0?-1:1)+count)%count;
    modes->modes.current=next;menuStartOptions[selectedBox]=modes->options[next];
    modulesMenuTexts[selectedBox]=bazill_menu::name(menuFunctions[selectedBox],menuStartOptions[selectedBox]);
    display.refreshControl(boxMenu);
}
void InterfaceMenuPopup::confirmModulePopup(){if(isVisible)hideModulePopup(sourceModule);}
void InterfaceMenuPopup::cancelModulePopup(){
    if(!isVisible)return;switchModuleCallback=nullptr;
    // A page may have changed while the menu was open. Cancel must return to
    // the source module even if no tile currently shows its original option.
    unsigned sourceBox=0;bool found=false;
    for(unsigned box=0;box<kMenuRowsCount*kMenuColumnsCount;++box){
        if(menuFunctions[box]!=selectedModuleOnShow)continue;
        if(!found||menuStartOptions[box]==sourceStartOption){sourceBox=box;found=true;}
        if(menuStartOptions[box]==sourceStartOption)break;
    }
    if(found)selectedBox=sourceBox;
    menuStartOptions[selectedBox]=sourceStartOption;hideModulePopup(sourceModule);
}

//******************************************************************************************************
static void functLeftPopup()
{
    mtMenuPopup.changeModulePopupValue(0, 4);
}

static void functRightPopup()
{
    mtMenuPopup.changeModulePopupValue(0, 2);
}

static void functUpPopup()
{
    mtMenuPopup.changeModulePopupValue(0, 1);
}

static void functDownPopup()
{
    mtMenuPopup.changeModulePopupValue(0, 3);
}

static void functEncoderPopup(int16_t value)
{
    if(value)mtMenuPopup.changeModuleMode(value<0?-1:1);
}

static void functMiddlePopup()
{
    mtMenuPopup.confirmModulePopup();
}
static void functTogglePopup(uint8_t state){if(state==buttonPress)mtMenuPopup.cancelModulePopup();}


#endif
