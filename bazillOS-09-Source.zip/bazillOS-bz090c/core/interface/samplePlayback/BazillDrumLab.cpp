#include "config.h"
#ifdef TRACKER_MINI
#include "BazillDrumLab.h"
#include "BazillStudio.h"
#include "samplePlayback.h"
#include "patternEditor/patternEditor.h"
#include "instrumentEditor/instrumentEditor.h"
#include "core/interface.h"
#include "core/interfaceMenuPopup.h"
#include "core/songTimer.h"
#include "Platform.h"
#include "Synth.h"
#include "mtAudioEngine.h"
#include "engines/BazillPercPresets.h"
#include "fileManager.h"
#include "FT812.h"
#include "BazillSurface.h"
#include "BazillTryAlloc.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
BazillDrumLab bazillDrumLab;
namespace {
constexpr int16_t noteSource=940;
uint32_t clockUs(){return mtInterface.getPlatform()->getTimer()->micros();}
uint32_t stepUs(){const float f=sequencer.getStepPeriodMs()*1000;return std::isfinite(f)?static_cast<uint32_t>(std::clamp(f,10000.f,1000000.f)):125000;}
void rect(int x,int y,int w,int h,uint32_t c){API_COLOR(c);API_BEGIN(RECTS);API_VERTEX2F(x,y);API_VERTEX2F(x+w-1,y+h-1);API_END();}
void text(int x,int y,const char* s,uint32_t c=0xBED0DB){API_COLOR(c);API_CMD_TEXT(x,y,fonts[0].handle,0,s);}
void bitmapText(int x,int y,const char* s,uint32_t color){
 API_SAVE_CONTEXT();API_COLOR(color);API_BITMAP_HANDLE(fonts[0].handle);API_BEGIN(BITMAPS);
 for(unsigned i=0;s[i];++i){const auto c=static_cast<unsigned char>(s[i]);if(x<=511)API_VERTEX2II(x,y,fonts[0].handle,c);else{API_CELL(c);API_VERTEX2F(x,y);}x+=fonts[0].data[c];}
 API_END();API_RESTORE_CONTEXT();
}
class DrumControl:public cDisplayControl {public:explicit DrumControl(strControlProperties*p):cDisplayControl(controlIdTemplate,1){style=p->style;}
 void setStyle(uint32_t s)override{style=s;}void setText(const char*)override{}void setValue(int)override{}void setColors(const uint32_t*)override{}void setData(void*)override{}
 void update()override{bazillDrumLab.draw();}};
void key(uint8_t k,uint8_t s){bazillDrumLab.action(k,s);}void change(int16_t d){bazillDrumLab.change(d);}
void left(){bazillDrumLab.move(-1,0);}void right(){bazillDrumLab.move(1,0);}void up(){bazillDrumLab.move(0,-1);}void down(){bazillDrumLab.move(0,1);}
void middle(){bazillDrumLab.middle();}void play(){bazillDrumLab.play();}
void menu(uint8_t s){if(s==buttonPress)mtMenuPopup.showModulePopup(&samplePlayback);else if(s==buttonRelease)mtMenuPopup.hideModulePopup(&samplePlayback);}
void switchModule(uint8_t k){samplePlayback.eventFunct(eventSwitchModule,&samplePlayback,&k,nullptr);}
}
void BazillDrumLab::initDisplayControls(){strControlProperties p{};panel=display.createControl<DrumControl>(&p);}
void BazillDrumLab::start(uint32_t){
 stop();active=true;ready=false;armed=kitArmed=false;compare=false;sequencer.stop();sequencer.recEnable(false);resetBreaklineActionHelp();
 if(!grid)grid.reset(bazill_alloc::create<bazill_drums::Workbench>());
 track=0;startRow=0; // Compact exports begin at Track 1; untouched tracks retain authored data.
 unsigned available=128;if(const auto* p=sequencer.getActualPattern())available=p->track[0].length+1;
 bars=std::min<unsigned>(bars,std::max<unsigned>(1,available/16));mapPercVoices();
 for(auto h:{samplePlayback.frameControl,samplePlayback.playModeListControl,samplePlayback.spectrumControl[0],samplePlayback.spectrumControl[1],samplePlayback.pointsControl,samplePlayback.slicePointsControl,samplePlayback.progressCursor,samplePlayback.granularCursor,samplePlayback.wtPositionCursor,samplePlayback.chopInfoControl})display.setControlHide(h);
 songTimer.hide();titleBar->show(false);titleBar->setTitle("DRUM LAB");bind();labels();display.setControlShow(panel);
 if(grid)generate();else std::snprintf(notice,sizeof notice,"Not enough RAM for Drum Lab. BACK restores Sample Playback.");redraw();
}
void BazillDrumLab::resume(){resetBreaklineActionHelp();bind();labels();songTimer.hide();titleBar->show(false);titleBar->setTitle("DRUM LAB");display.setControlShow(panel);redraw();}
void BazillDrumLab::stopNotes(){for(unsigned i=0;i<8;++i){pending[i]=false;if(sounding[i]){sequencer.handleNoteOff(Sequencer::GRID_OUTSIDE_PATTERN,note(i),0,noteSource+i);sounding[i]=false;}}}
void BazillDrumLab::stop(){if(!active)return;stopNotes();if(compare)sequencer.stop();running=false;active=false;grid.reset();ready=false;songTimer.show();resetBreaklineActionHelp();display.setControlHide(panel);}
void BazillDrumLab::hideControlsUnderMiniMenu(){stopNotes();if(compare)sequencer.stop();running=false;display.setControlHide(panel);}
void BazillDrumLab::bind(){ip->clearButtonsRange(interfaceButton0,interfaceButton32);ip->clearAllPots();
 for(unsigned i=0;i<8;++i)ip->setButtonObj(i,key);
 ip->setButtonObj(interfaceButtonLeft,buttonPress,left);ip->setButtonObj(interfaceButtonRight,buttonPress,right);ip->setButtonObj(interfaceButtonUp,buttonPress,up);ip->setButtonObj(interfaceButtonDown,buttonPress,down);
 ip->setButtonObj(interfaceButtonMiniMiddle,buttonPress,::middle);ip->setButtonObj(interfaceButtonPlay,buttonPress,::play);ip->setPotObj(interfacePot0,::change);ip->setButtonObj(interfaceButtonMiniMenu,::menu);
 for(unsigned k=interfaceButtonParams;k<=interfaceButtonPattern;++k)ip->setButtonObj(k,buttonPress,switchModule);ip->setButtonObj(interfaceButtonGame,buttonPress,switchModule);
}
void BazillDrumLab::labels(){const char* names[]={"PERC KIT","RHYTHM","GROOVE","SOUND","GENERATE","PLAY/STOP","WRITE","BACK"};
 for(unsigned i=0;i<8;++i){auto h=samplePlayback.label[i];display.setControlPosition(h,i*100+50,424);display.setControlSize(h,96,55);display.setControlData(h,nullptr);display.setControlStyle2(h,controlStyleShow|controlStyleCenterX|controlStyleCenterY|controlStyleFont3);display.setControlText(h,names[i]);display.setControlText2(h,"");display.setControlValue(h,0);display.setControlColors(h,display.getTheme().activeLabelsColors);display.setControlShow(h);display.refreshControl(h);}
}
void BazillDrumLab::cancelConfirmation(){armed=kitArmed=false;}
void BazillDrumLab::redraw(){if(active){std::snprintf(values[6],sizeof values[6],"%s %uT",armed?"CONFIRM":"WRITE",grid?grid->packing.tracks:0);display.setControlText(samplePlayback.label[6],values[6]);display.refreshControl(samplePlayback.label[6]);display.refreshControl(panel);}}
bool BazillDrumLab::validVoice(unsigned i)const{
 if(i>=8)return false;const unsigned v=voice[i];
 if(v>=64&&v<67){
  const unsigned type=mtProject.values.synthPart[v-64].synthType;
  if(type==4)return synth&&mtProject.values.synthPart[v-64].voiceCount>0;
  if(type!=7||!synth)return false;
  const auto model=synth->getPatch(v-64).getParamValue(0);
  return model&&*model>=10.f&&*model<=12.f;
 }if(v>=48)return false;
 const auto& ins=mtProject.instrument[v];return ins.isActive&&ins.sample.type==mtSampleTypeWaveFile&&ins.sample.length>0&&ins.playMode!=playModeBeatSlice&&ins.playMode!=playModeSlice;
}
void BazillDrumLab::updatePacking(){
 if(!grid)return;uint8_t enabled=0,reserved=0;uint16_t hold[8]{};
 // Half a nominal step is the shortest native/global swing interval. Reserve
 // full source audio (not just an amplitude estimate), plus delayed-step margin.
 const uint64_t period=std::max<uint32_t>(1,stepUs()/2);
 for(unsigned r=0;r<8;++r)if(validVoice(r)){
  enabled|=1u<<r;
  if(voice[r]<48){reserved|=1u<<r;const auto&i=mtProject.instrument[voice[r]];
   hold[r]=std::min<uint64_t>(grid->size(),std::max<uint64_t>(1,(uint64_t(i.sample.length)*1000000+44100*period-1)/(44100*period)));
   // Modulated pitch, looping modes and an external clock have no bounded tail
   // in step units. Keep a dedicated column rather than guessing at its end.
   if(i.playMode!=playModeSingleShot||i.tune||i.fineTune||i.glide||i.isEnvEnabled(envFinetune)||i.lfo[envFinetune].speed||!sequencer.isSetInternalClock())hold[r]=grid->size();
  }else if(mtProject.values.synthPart[voice[r]-64].synthType!=4){
   // Only native PERC ignores note-off. DREAMS percussion must not be cut off
   // by another role assigned to the same pattern track.
   reserved|=1u<<r;hold[r]=grid->size();
  }
 }
 if(compact)bazill_drums::pack(grid->packing,grid->size(),enabled,reserved,hold,[&](unsigned r,unsigned n){return grid->at(r,n);});
 else{auto&out=grid->packing;std::memset(out.destination,255,sizeof out.destination);out.tracks=8;out.valid=true;for(unsigned r=0;r<8;++r)if(enabled&(1u<<r))for(unsigned n=0;n<grid->size();++n)if(grid->at(r,n).velocity)out.destination[r][n]=r;}
}
bool BazillDrumLab::validDestination()const{
 if(!grid||!grid->size()||!grid->packing.valid||!grid->packing.tracks)return false;const auto*p=sequencer.getActualPattern();if(!p||track+grid->packing.tracks>8)return false;
 for(unsigned t=0;t<grid->packing.tracks;++t)if(startRow+grid->size()>unsigned(p->track[track+t].length)+1)return false;
 bool any=false;for(unsigned r=0;r<8;++r)for(unsigned n=0;n<grid->size();++n)if(grid->at(r,n).velocity&&voice[r]!=255){if(!validVoice(r)||grid->packing.destination[r][n]>=grid->packing.tracks)return false;any=true;}
 return any;
}
uint32_t BazillDrumLab::fingerprint()const{
 const auto*p=sequencer.getActualPattern();if(!p||!grid||!grid->packing.valid)return 0;uint32_t hash=2166136261u;
 auto add=[&](uint8_t b){hash=(hash^b)*16777619u;};add(mtProject.values.actualPattern);add(track);add(startRow);add(compact);add(grid->packing.tracks);add(sequencer.isSetInternalClock());
 for(unsigned t=0;t<grid->packing.tracks;++t){if(track+t>=8)return 0;add(p->track[track+t].length);for(unsigned n=0;n<grid->size();++n){if(startRow+n>p->track[track+t].length)return 0;const auto&v=p->track[track+t].step[startRow+n];add(v.note);add(v.instrument);add(v.volume);add(v.micromove);for(unsigned k=0;k<2;++k){add(v.fx[k].type);add(v.fx[k].value);}}}
 for(unsigned r=0;r<8;++r){add(voice[r]);for(unsigned n=0;n<grid->size();++n){add(grid->at(r,n).velocity);add(grid->at(r,n).micro);add(grid->packing.destination[r][n]);}
  if(voice[r]<48){const auto&i=mtProject.instrument[voice[r]];const uint32_t h=mtProject.sampleMemory[voice[r]].sampleHash;for(unsigned b=0;b<4;++b)add(h>>(b*8));const auto*bytes=reinterpret_cast<const uint8_t*>(&i);for(unsigned b=0;b<sizeof i;++b)add(bytes[b]);const unsigned bpm=std::isfinite(mtProject.values.globalTempo)?std::lround(mtProject.values.globalTempo*10):0;add(bpm);add(bpm>>8);}
  else if(voice[r]>=64&&voice[r]<67){const auto&v=mtProject.values.synthPart[voice[r]-64];add(v.synthType);add(v.voiceCount);}
 }return hash;
}
void BazillDrumLab::generate(){stopNotes();sequencer.stop();running=false;cancelConfirmation();
 if(!grid||!grid->generate(preset,bars*16,seed,variation,swing)){std::snprintf(notice,sizeof notice,"Cannot generate this grid. BACK and reopen Drum Lab.");redraw();return;}
 updatePacking();ready=validDestination();sourceHash=fingerprint();cursor=std::min<unsigned>(cursor,grid->size()-1);
 std::snprintf(notice,sizeof notice,ready?"Ready: PLAY starts the beat. RHYTHM +/- changes it. SOUND replaces one role. WRITE twice commits.":"No PERC kit: press PERC KIT twice to set up, or open a new project. The shown destination tracks must fit.");redraw();
}
void BazillDrumLab::apply(){if(newFileManager.getStatus()!=fmIdle||!ready||!validDestination()||fingerprint()!=sourceHash){armed=false;std::snprintf(notice,sizeof notice,"Source changed or voices/range invalid. GENERATE a fresh preview.");redraw();return;}
 if(!armed){armed=true;std::snprintf(notice,sizeof notice,"WRITE again: replace Tracks %u-%u, rows %u-%u. Other tracks stay. Undo restores.",track+1,track+grid->packing.tracks,startRow+1,startRow+grid->size());redraw();return;}
 stopNotes();sequencer.stop();sequencer.recEnable(false);running=false;newFileManager.storePatternUndoRevision();auto*p=sequencer.getActualPattern();
 for(unsigned t=0;t<grid->packing.tracks;++t)for(unsigned n=0;n<grid->size();++n){auto&out=p->track[track+t].step[startRow+n];out.note=-1;out.instrument=0;out.volume=-1;out.micromove=-1;for(auto&fx:out.fx){fx.type=0;fx.value=0;}}
 for(unsigned r=0;r<8;++r)for(unsigned n=0;n<grid->size();++n)if(grid->packing.destination[r][n]<grid->packing.tracks){const auto&c=grid->at(r,n);auto&out=p->track[track+grid->packing.destination[r][n]].step[startRow+n];out.note=note(r);out.instrument=voice[r];out.volume=(c.velocity*100+63)/127;out.micromove=c.micro*100/96;}
 newFileManager.setActualPatternStructChanged();sourceHash=fingerprint();armed=false;std::snprintf(notice,sizeof notice,"Drums written. Existing Undo restores the previous pattern. Save As keeps original folders.");redraw();
}
// PERC owns a complete kit inside one native synth part. Two parts allow a
// separate shaker alongside clap, without changing the SDK's three-part limit.
uint8_t BazillDrumLab::note(unsigned i)const{
 static constexpr uint8_t notes[]={60,62,64,66,70,48,70,68};return voice[i]<48?60:notes[i];
}
void BazillDrumLab::mapPercVoices(){
 int main=-1,aux=-1;for(unsigned i=0;i<3;++i)if(mtProject.values.synthPart[i].synthType==4&&mtProject.values.synthPart[i].voiceCount>0){if(main<0)main=i;else if(aux<0)aux=i;}
 for(unsigned i=0;i<8;++i)voice[i]=(i==6?aux:main)<0?255:64+(i==6?aux:main);
 if(main>=0&&synth)for(unsigned n=0;n<bazill_perc::count;++n)if(synth->getPatchName(main)==bazill_perc::bank[n].name){kit=n;break;}
}
void BazillDrumLab::buildSynthKit(){
 if(!synth||newFileManager.getStatus()!=fmIdle)return;
 if(!kitArmed){kitArmed=true;armed=false;std::snprintf(notice,sizeof notice,"KIT again: replace S1/S2 with PERC kit + shaker. S3 and samples stay. Save As first.");return;}
 void* reserve=_malloc_r(nullptr,65536);if(!reserve){kitArmed=false;std::snprintf(notice,sizeof notice,"Not enough free RAM for the PERC kit. Existing project remains unchanged.");return;}std::free(reserve);
 stopNotes();sequencer.stop();sequencer.recEnable(false);bool ok=true;
 for(unsigned i=0;i<2;++i){synth->setVoiceCount(i,0);synth->setInstrumentType(i,polysynth::InstrumentTypeId::kDrumSynth);
  auto& settings=mtProject.values.synthPart[i];synth->initSynthPartSettings(i,settings);settings.synthType=4;settings.voiceCount=1;
  const char* name=i==0?bazill_perc::bank[kit].name:bazill_perc::shaker.name;ok&=synth->loadPatch(i,name);std::snprintf(settings.patchName,sizeof settings.patchName,"%s",name);synth->initSynthPartMacrosValues(i,settings);
 }
 synth->updateToSettings(mtProject.values);for(unsigned i=0;i<2;++i)engine.refreshSynthInstrumentParams(mtProject.values.synthPart[i],i);newFileManager.setProjectStructChanged();mapPercVoices();kitArmed=false;
 if(ok)generate();else {ready=false;std::snprintf(notice,sizeof notice,"PERC preset could not load. Check PERC in Synth Parameters.");}
}
void BazillDrumLab::action(uint8_t k,uint8_t state){if(state!=buttonPress||k>7)return;const bool shift=buttons->isButtonPressed(interfaceButtonShift);
 if(k==7){samplePlayback.start(100);return;}if(k==6){if(shift){stopNotes();running=false;cancelConfirmation();compact=!compact;updatePacking();ready=validDestination();sourceHash=fingerprint();std::snprintf(notice,sizeof notice,"%s export uses %u tracks. Shift+WRITE switches layout. Other tracks stay.",compact?"Compact":"Separate",grid?grid->packing.tracks:0);redraw();}else apply();return;}if(k==5){play();return;}
 bool hasPerc=false;for(unsigned i=0;i<3;++i)hasPerc|=mtProject.values.synthPart[i].synthType==4&&mtProject.values.synthPart[i].voiceCount>0;
 if(k==0&&!shift&&!hasPerc){buildSynthKit();redraw();return;}
 if(shift&&k==3&&voice[lane]>=64&&voice[lane]<67){mtProject.values.lastUsedInstrument=voice[lane];instrumentEditor.synthShortcutRequested=5;uint8_t button=interfaceButtonParams;uint32_t options=100;samplePlayback.eventFunct(eventSwitchModule,&samplePlayback,&button,&options);return;}
 cancelConfirmation();
 if(shift&&k==0){bars=bars%8+1;cursor=0;generate();return;}
 else if(shift&&k==1){++seed;generate();return;}
 else if(shift&&k==2){swing=swing==255?0:swing>=35?255:swing+5;generate();return;}
 else if(k<4){param=k;std::snprintf(notice,sizeof notice,k==0?"KIT +/- selects PERC presets. Existing assigned PERC parts only; sample replacements stay.":k==1?"RHYTHM +/- chooses the beat. Shift+RHYTHM changes seed.":k==2?"GROOVE +/- changes variation. Shift+GROOVE changes swing.":"Up/Down chooses a role. +/- selects a loaded one-shot or returns to PERC. Middle auditions.");}
 else if(k==4){generate();return;}
 redraw();
}
void BazillDrumLab::change(int16_t d){if(!d)return;stopNotes();sequencer.stop();running=false;cancelConfirmation();
 if(param==0){
  const auto next=std::clamp<int>(int(kit)+d,0,bazill_perc::count-1);
  if(next!=kit){kit=next;unsigned part=3;for(unsigned i=0;i<8;++i)if(i!=6&&voice[i]>=64&&voice[i]<67&&validVoice(i)){part=voice[i]-64;break;}
   if(part<3&&synth){if(synth->loadPatch(part,bazill_perc::bank[kit].name)){auto& settings=mtProject.values.synthPart[part];std::snprintf(settings.patchName,sizeof settings.patchName,"%s",bazill_perc::bank[kit].name);synth->initSynthPartMacrosValues(part,settings);engine.refreshSynthInstrumentParams(settings,part);newFileManager.setProjectStructChanged();}else{ready=false;std::snprintf(notice,sizeof notice,"PERC preset unavailable. Check Synth Parameters.");redraw();return;}}
   else{std::snprintf(notice,sizeof notice,"Press PERC KIT twice to set up S1/S2, or open a new project.");redraw();return;}
  }
 }else if(param==1)preset=std::clamp<int>(int(preset)+d,0,bazill_drums::recipeCount-1);
 else if(param==2)variation=std::clamp<int>(int(variation)+d,0,100);
 else if(param==3){
  // PERC is first in a compact list containing only usable, loaded one-shots.
  const uint8_t old=voice[lane];int value=old<48?old:-1;
  for(unsigned count=0;count<49;++count){value+=d>0?1:-1;if(value>47)value=-1;if(value< -1)value=47;
   if(value<0){int part=-1;for(unsigned i=0;i<3;++i)if(mtProject.values.synthPart[i].synthType==4&&mtProject.values.synthPart[i].voiceCount>0){if(lane!=6||part>=0){part=i;break;}part=i;}voice[lane]=part<0?255:64+part;break;}
   voice[lane]=value;if(validVoice(lane))break;voice[lane]=old;
  }
 }
 generate();if(param==3&&validVoice(lane)){pendingVelocity[lane]=100;trigger(lane);}redraw();
}
void BazillDrumLab::move(int x,int y){cancelConfirmation();lane=std::clamp<int>(int(lane)+y,0,7);if(grid&&grid->size())cursor=std::clamp<int>(int(cursor)+x*(buttons->isButtonPressed(interfaceButtonShift)?16:1),0,grid->size()-1);redraw();}
void BazillDrumLab::middle(){cancelConfirmation();if(param==3&&!buttons->isButtonPressed(interfaceButtonShift)){stopNotes();running=false;if(validVoice(lane)){pendingVelocity[lane]=100;trigger(lane);}return;}if(!grid||!ready||grid->size()!=bars*16||fingerprint()!=sourceHash){std::snprintf(notice,sizeof notice,"Set up the PERC KIT first; the grid must fit its destination tracks.");redraw();return;}stopNotes();running=false;if(buttons->isButtonPressed(interfaceButtonShift))grid->toggleLock(lane,cursor);else {grid->toggle(lane,cursor);if(grid->at(lane,cursor).velocity){pendingVelocity[lane]=grid->at(lane,cursor).velocity;trigger(lane);}else if(sounding[lane]){sequencer.handleNoteOff(Sequencer::GRID_OUTSIDE_PATTERN,note(lane),0,noteSource+lane);sounding[lane]=false;}}updatePacking();ready=validDestination();sourceHash=fingerprint();redraw();}
void BazillDrumLab::trigger(unsigned i){pending[i]=false;if(!pendingVelocity[i]||!validVoice(i))return;
 if(sounding[i])sequencer.handleNoteOff(Sequencer::GRID_OUTSIDE_PATTERN,note(i),0,noteSource+i);
 const auto old=mtProject.values.lastUsedInstrument;mtProject.values.lastUsedInstrument=voice[i];sequencer.handleNoteOn(Sequencer::GRID_OUTSIDE_PATTERN,note(i),pendingVelocity[i],noteSource+i);mtProject.values.lastUsedInstrument=old;sounding[i]=true;
}
void BazillDrumLab::play(){cancelConfirmation();if(compare){if(sequencer.isPlay())sequencer.stop();else sequencer.playPattern();return;}
 if(!ready||!validDestination()||fingerprint()!=sourceHash){std::snprintf(notice,sizeof notice,"Set up PERC KIT first. Generated grid must fit its destination tracks.");redraw();return;}
 stopNotes();sequencer.stop();running=!running;playingStep=0;nextStep=clockUs();redraw();
}
void BazillDrumLab::update(){if(!active)return;
 if(mtMenuPopup.isPopupVisible()||display.isHelpModal()||newFileManager.getStatus()!=fmIdle){stopNotes();running=false;if(newFileManager.getStatus()!=fmIdle)ready=false;return;}
 const uint32_t t=clockUs();
 for(unsigned i=0;i<8;++i)if(pending[i]&&int32_t(t-pendingAt[i])>=0)trigger(i);
 if(running&&grid&&int32_t(t-nextStep)>=0){const auto duration=stepUs();cursor=playingStep;
  for(unsigned i=0;i<8;++i){const auto&c=grid->at(i,playingStep);pendingVelocity[i]=c.velocity;pending[i]=c.velocity&&validVoice(i);pendingAt[i]=nextStep+uint32_t(uint64_t(duration)*c.micro/96);}
  playingStep=(playingStep+1)%grid->size();nextStep+=duration;if(int32_t(t-nextStep)>=0)nextStep=t+duration;redraw();
 }
 for(unsigned i=0;i<8;++i)if(pending[i]&&int32_t(t-pendingAt[i])>=0)trigger(i);
}
const char* BazillDrumLab::help(uint8_t k)const{static const char* tips[]={
 "New projects have PERC kit + shaker ready in S1/S2. KIT +/- chooses 64 presets. With no PERC, KIT twice explicitly replaces S1/S2. Shift+KIT: length.",
 "RHYTHM +/- selects 32 genre recipes and rebuilds the preview. Shift+RHYTHM changes the repeatable seed. Project notes stay unchanged.",
 "GROOVE +/- changes variation. Shift+GROOVE cycles swing. Kick/snare anchors stay stable.",
 "Up/Down selects a drum role. SOUND then +/- selects only loaded individual one-shots, or returns to PERC. Middle auditions. Shift+SOUND opens PERC; EDIT changes that sound.",
 "Generate refreshes the preview without writing notes. Each PERC lane uses the correct drum note, rather than slicing a sample.",
 "Play/Stop auditions the staged drum grid. The physical Play button does the same.",
 "WRITE twice replaces only the shown number of tracks, starting at Track 1. Other tracks stay. Shift+WRITE switches Compact/Separate. Sample tails are reserved at the current tempo; pitch changes, loops and external clock keep a dedicated column. One Undo restores.",
 "Return to Sample Playback and stop preview notes. Original sample, slice and synth editors remain available."};return tips[k<8?k:7];}
void BazillDrumLab::draw(){
 API_SAVE_CONTEXT();rect(0,30,800,394,0x080D13);bazill_surface::texture(0,30,800,394,0x8797BB,30);bazill_surface::mascot(748,42,10,0xEAB0F7,215);
 char line[112];std::snprintf(line,sizeof line,"DRUM LAB / PERC KIT / %s",running?"PLAYING":"READY");text(24,48,line,0x6BE6C2);
 std::snprintf(line,sizeof line,"%s  VAR %u  SEED %lu  BARS %u",bazill_drums::recipes[preset].name,variation,static_cast<unsigned long>(seed),bars);text(24,76,line);
 std::snprintf(line,sizeof line,"%s: %u TRACKS / %u UNTOUCHED / SHIFT+WRITE",compact?"COMPACT":"SEPARATE",grid?grid->packing.tracks:0,grid?8-grid->packing.tracks:8);text(24,103,line,0x91A8B8);
 const unsigned first=(cursor/32)*32;const int gx=174,gy=148,cw=18,rh=27;
 rect(18,gy+lane*rh,748,rh,0x251D35);
 API_COLOR(0x233044);API_LINE_WIDTH(8);API_BEGIN(LINES);for(unsigned x=0;x<=32;++x){API_VERTEX2F(gx+x*cw,gy);API_VERTEX2F(gx+x*cw,gy+8*rh);}for(unsigned y=0;y<=8;++y){API_VERTEX2F(gx,gy+y*rh);API_VERTEX2F(gx+32*cw,gy+y*rh);}API_END();
 static const char* const roleNames[]={"KICK","SNARE","C.HAT","O.HAT","CLAP","TOM","SHAKER","RIDE"};
 for(unsigned i=0;i<8;++i){char slot[8];if(voice[i]==255)std::snprintf(slot,sizeof slot,"--");else if(voice[i]>=64)std::snprintf(slot,sizeof slot,"S%u",voice[i]-63);else std::snprintf(slot,sizeof slot,"%02u",voice[i]+1);
  char name[24];std::snprintf(name,sizeof name,"%s %s",roleNames[i],slot);bitmapText(24,gy+i*rh+5,name,i==lane?0xEAB0F7:validVoice(i)?0x6BE6C2:0x65748D);
  if(!grid)continue;API_COLOR(validVoice(i)?bazill_surface::speciesColors[i%6]:0x3D4256);API_POINT_SIZE(11*16);API_BEGIN(FTPOINTS);
  for(unsigned x=0;x<32&&first+x<grid->size();++x)if(grid->at(i,first+x).velocity)API_VERTEX2F(gx+x*cw+cw/2,gy+i*rh+rh/2);API_END();
  API_COLOR(0xF8BD62);API_POINT_SIZE(2*16);API_BEGIN(FTPOINTS);for(unsigned x=0;x<32&&first+x<(grid?grid->size():0);++x)if(grid->at(i,first+x).locked)API_VERTEX2F(gx+x*cw+cw-3,gy+i*rh+3);API_END();
 }
 bazill_surface::faultFrame(gx+(cursor-first)*cw+1,gy+lane*rh+1,cw-2,rh-2,0xEAB0F7,255);
 std::snprintf(line,sizeof line,"STEPS %u-%u/%u / %s",first+1,std::min<unsigned>(first+32,bars*16),bars*16,armed?"WRITE ARMED":ready?"PREVIEW READY":"SETUP PERC KIT");text(24,122,line,armed?0xFF8588:0x91A8B8);
 char selected[81];if(param==0)std::snprintf(selected,sizeof selected,"KIT %02u/%u: %s",kit+1,unsigned(bazill_perc::count),bazill_perc::bank[kit].name);
 else if(param==3&&voice[lane]<48)std::snprintf(selected,sizeof selected,"%s: %02u %s / +/- REPLACE / MIDDLE HEAR",roleNames[lane],voice[lane]+1,mtProject.instrument[voice[lane]].sample.file_name);
 else std::snprintf(selected,sizeof selected,"%s",notice);
 selected[79]=0;text(24,394,selected,0x91A8B8);API_RESTORE_CONTEXT();
}
#endif
