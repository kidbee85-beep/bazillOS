#pragma once
#ifdef TRACKER_MINI
#include "core/modulesBase.h"
#include "breakline/beat_workbench.hpp"
#include "breakline/audio_scope.hpp"
#include "Profiler.h"
#include "BazillTryAlloc.h"
#include <memory>
class BazillStudio:public ModuleBase {
public:
 enum View:uint8_t {Beat,Scope,Memory};
 void initDisplayControls()override;void destroyDisplayControls()override{}
 void start(uint32_t options)override;void stop()override;void update()override;
 void hideControlsUnderMiniMenu()override;
 bool isActive()const{return active;}
 uint8_t getCurrentModeIdx()override{return view;}
 void action(uint8_t key,uint8_t state);void change(int16_t delta);void move(int x,int y);void middle();void play();void record();
 void draw();const char* help(uint8_t key)const;void cancelConfirmation();
private:
 bool snapshot();bool unchanged()const;void generate();void apply();void redraw();void bind();void labels();void stopNotes();
 void triggerPending();
 void beginExtract();void updateExtract();
 void updateHealth();
 bazill_beats::Step readStep(unsigned step)const;
 bazill_alloc::Ptr<bazill_beats::Workbench> work;
 bazill_alloc::Ptr<bazill_scope::Analyzer> analyzer;
 hControl panel=-1;
 char notice[100]="",valueText[8][24]{};
 uint8_t view=Beat,param=0,cursor=0,preset=0,amount=50,bars=1,target=0,track=0,startStep=0,scopeMode=0;
 uint8_t task=1,downbeat=0,selectedInstrument=0,sliceCount=0,extractAt=0;
 uint16_t sliceStarts[48]{},slicePeaks[48]{};
 uint32_t seed=1,sampleHash=0,sampleLength=0,nextFrame=0,nextStep=0,pendingAt=0;
 bazill_beats::Step pendingStep{};bool pending=false;
 uint8_t playingStep=0,previewNote=0;
 bool active=false,compare=false,armed=false,running=false,noteActive=false,extracting=false,scopeHold=false;
 float meter[32]{},peakHold[32]{};
 uint32_t peakUntil[32]{},lastScopeFrame=0;
 uint32_t nextHealthFrame=0,entryDlBytes=0;
 Profiler::AudioProcessorUsage audioHealth{};
 size_t freeHeapBlocks=0,stackWatermark=0;
};
extern BazillStudio bazillStudio;
#endif
