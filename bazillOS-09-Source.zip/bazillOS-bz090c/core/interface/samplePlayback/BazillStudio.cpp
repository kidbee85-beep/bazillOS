#include "config.h"
#ifdef TRACKER_MINI
#include "BazillStudio.h"
#include "samplePlayback.h"
#include "patternEditor/patternEditor.h"
#include "core/interface.h"
#include "core/interfaceMenuPopup.h"
#include "core/interfacePopups.h"
#include "core/songTimer.h"
#include "Platform.h"
#include "fileManager.h"
#include "mtAudioEngine.h"
#include "VoiceStreamManager.h"
#include "BazillSlicePreview.h"
#include "BazillTryAlloc.h"
#include "BreaklineMotion.h"
#include "FT812.h"
#include "AudioStream.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <new>
BazillStudio bazillStudio;
namespace {
constexpr int16_t source=916;
uint32_t now(){return mtInterface.getPlatform()->getTimer()->micros();}
uint32_t interval(){const float n=sequencer.getStepPeriodMs()*1000;return std::isfinite(n)?static_cast<uint32_t>(std::clamp(n,10000.f,1000000.f)):125000;}
void rect(int x,int y,int w,int h,uint32_t color){if(w<=0||h<=0)return;API_COLOR(color);API_BEGIN(RECTS);API_VERTEX2F(x,y);API_VERTEX2F(x+w-1,y+h-1);API_END();}
void text(int x,int y,const char* s,uint32_t color=0xBED0DB,int f=0){
 if(!s||x>=776)return;
 char clipped[160];unsigned n=0,width=0;const unsigned available=776-x;
 while(s[n]&&n<sizeof(clipped)-1&&width+fonts[f].data[static_cast<uint8_t>(s[n])]<=available){clipped[n]=s[n];width+=fonts[f].data[static_cast<uint8_t>(s[n])];++n;}
 if(s[n]){const unsigned dots=3*fonts[f].data[static_cast<uint8_t>('.')];while(n&&width+dots>available)width-=fonts[f].data[static_cast<uint8_t>(clipped[--n])];
  if(width+dots<=available&&n+3<sizeof clipped){clipped[n++]='.';clipped[n++]='.';clipped[n++]='.';}}
 clipped[n]=0;API_COLOR(color);API_CMD_TEXT(x,y,fonts[f].handle,0,clipped);
}
class StudioControl:public cDisplayControl {
public:
 explicit StudioControl(strControlProperties* p):cDisplayControl(controlIdTemplate,1){style=p->style;posX=0;posY=30;width=800;height=394;}
 void setStyle(uint32_t s)override{style=s;}void setText(const char*)override{}void setValue(int)override{}
 void setColors(const uint32_t*)override{}void setData(void*)override{}
 void update()override{bazillStudio.draw();}
};
void action(uint8_t key,uint8_t state){bazillStudio.action(key,state);}
void change(int16_t d){bazillStudio.change(d);}void left(){bazillStudio.move(-1,0);}void right(){bazillStudio.move(1,0);}
void up(){bazillStudio.move(0,-1);}void down(){bazillStudio.move(0,1);}void middle(){bazillStudio.middle();}
void play(){bazillStudio.play();}void record(){bazillStudio.record();}
void menu(uint8_t state){if(state==buttonPress)mtMenuPopup.showModulePopup(&samplePlayback);else if(state==buttonRelease)mtMenuPopup.hideModulePopup(&samplePlayback);}
void switchModule(uint8_t key){samplePlayback.eventFunct(eventSwitchModule,&samplePlayback,&key,nullptr);}
const char* const tasks[]={"ORIGINAL CHOPS","RHYTHM CHOPS","LOCKED VARIATION","APPLY GROOVE"};
}
void BazillStudio::initDisplayControls(){strControlProperties p{};panel=display.createControl<StudioControl>(&p);}
void BazillStudio::start(uint32_t options){
 stop();view=static_cast<uint8_t>(std::min<uint32_t>(options,Memory));active=true;armed=false;running=false;compare=false;extracting=false;
 resetBreaklineActionHelp();
 selectedInstrument=mtProject.values.lastUsedInstrument;target=selectedInstrument;
 if(view==Beat){sequencer.stop();sequencer.recEnable(false);sequencer.stopManualNotes();
  if(!work)work.reset(bazill_alloc::create<bazill_beats::Workbench>());
  if(!snapshot())std::snprintf(notice,sizeof notice,"Select a track with room for at least 16 steps. No pattern edits made.");
  else std::snprintf(notice,sizeof notice,"Generate stages a phrase. Middle locks a cell. WRITE needs two taps.");
 }else if(view==Scope){analyzer.reset(bazill_alloc::create<bazill_scope::Analyzer>());
  AudioNoInterrupts();bazill_scope::capture.resetStopped();bazill_scope::capture.enable(analyzer!=nullptr);AudioInterrupts();scopeHold=false;
  std::fill(meter,meter+32,0.f);std::fill(peakHold,peakHold+32,0.f);lastScopeFrame=now();nextHealthFrame=lastScopeFrame;entryDlBytes=display.composedDisplayListBytes();updateHealth();
  std::snprintf(notice,sizeof notice,analyzer?"Live software output / stereo power / 1024 frames. PLAY controls transport.":"Not enough memory for spectrum analysis. Playback remains available.");
 }else std::snprintf(notice,sizeof notice,"Resident/streamed sample overview. No automatic deletion or trimming.");
 for(auto h:{samplePlayback.frameControl,samplePlayback.playModeListControl,samplePlayback.spectrumControl[0],samplePlayback.spectrumControl[1],samplePlayback.pointsControl,samplePlayback.slicePointsControl,samplePlayback.progressCursor,samplePlayback.granularCursor,samplePlayback.wtPositionCursor,samplePlayback.chopInfoControl})display.setControlHide(h);
 titleBar->setTitle(view==Beat?"bazillOS / BEAT LAB":view==Scope?"bazillOS / SPECTRUM":"bazillOS / SAMPLE MEMORY");
 display.setControlShow(panel);bind();labels();redraw();nextFrame=now();
}
void BazillStudio::stopNotes(){pending=false;if(noteActive){sequencer.handleNoteOff(Sequencer::GRID_OUTSIDE_PATTERN,previewNote,0,source);noteActive=false;}}
void BazillStudio::stop(){
 if(!active)return;
 resetBreaklineActionHelp();stopNotes();running=false;extracting=false;active=false;bazill_scope::capture.enable(false);analyzer.reset();
 display.setControlHide(panel);
}
void BazillStudio::hideControlsUnderMiniMenu(){stopNotes();running=false;bazill_scope::capture.enable(false);display.setControlHide(panel);}
void BazillStudio::bind(){
 ip->clearButtonsRange(interfaceButton0,interfaceButton32);ip->clearAllPots();
 for(uint8_t k=0;k<8;++k)ip->setButtonObj(k,::action);
 ip->setButtonObj(interfaceButtonLeft,buttonPress,::left);ip->setButtonObj(interfaceButtonRight,buttonPress,::right);
 ip->setButtonObj(interfaceButtonUp,buttonPress,::up);ip->setButtonObj(interfaceButtonDown,buttonPress,::down);
 ip->setButtonObj(interfaceButtonMiniMiddle,buttonPress,::middle);ip->setButtonObj(interfaceButtonPlay,buttonPress,::play);ip->setButtonObj(interfaceButtonRec,buttonPress,::record);
 ip->setPotObj(interfacePot0,::change);ip->setButtonObj(interfaceButtonMiniMenu,::menu);
 for(uint8_t k=interfaceButtonParams;k<=interfaceButtonPattern;++k)ip->setButtonObj(k,buttonPress,::switchModule);
 ip->setButtonObj(interfaceButtonGame,buttonPress,::switchModule);
}
bazill_beats::Step BazillStudio::readStep(unsigned at)const{
 bazill_beats::Step result;const auto* p=sequencer.getActualPattern();if(!p||track>=kAllTracks||at>p->track[track].length)return result;
 const auto& in=p->track[track].step[at];result.note=in.note;result.instrument=in.instrument;result.volume=in.volume;result.micro=in.micromove;
 for(unsigned k=0;k<2;++k){result.fx[k].type=in.fx[k].type;result.fx[k].value=in.fx[k].value;}return result;
}
bool BazillStudio::snapshot(){
 if(!work) return false;
 work->clearSnapshot();track=patternEditor.trackerPattern.selectStartTrack;startStep=patternEditor.trackerPattern.selectStartStep;
 auto* p=sequencer.getActualPattern();if(!p||track>=kAllTracks||startStep>p->track[track].length)return false;
 const unsigned available=p->track[track].length+1-startStep;const unsigned count=std::min<unsigned>(bars*16,available/16*16);
 if(count<16)return false;
 bazill_beats::Step steps[128];for(unsigned i=0;i<count;++i)steps[i]=readStep(startStep+i);
 if(!work->snapshot(steps,count))return false;
 cursor=0;sampleHash=selectedInstrument<48?mtProject.sampleMemory[selectedInstrument].sampleHash:0;
 sampleLength=selectedInstrument<48?mtProject.instrument[selectedInstrument].sample.length:0;
 sliceCount=selectedInstrument<48?mtProject.instrument[selectedInstrument].sliceNumber:0;
 if(selectedInstrument<48)std::memcpy(sliceStarts,mtProject.instrument[selectedInstrument].slices,sizeof sliceStarts);
 return true;
}
bool BazillStudio::unchanged()const{
 if(!work||!work->size()||selectedInstrument!=mtProject.values.lastUsedInstrument)return false;
 const auto* p=sequencer.getActualPattern();if(!p||track>=kAllTracks||startStep+work->size()>unsigned(p->track[track].length)+1)return false;
 if(selectedInstrument<48&&(mtProject.sampleMemory[selectedInstrument].sampleHash!=sampleHash||mtProject.instrument[selectedInstrument].sample.length!=sampleLength))return false;
 bazill_beats::Step steps[128];for(unsigned i=0;i<work->size();++i)steps[i]=readStep(startStep+i);return work->unchanged(steps,work->size());
}
void BazillStudio::generate(){
 cancelConfirmation();stopNotes();running=false;
 if(!unchanged()){std::snprintf(notice,sizeof notice,"Source changed. Reopen Beat Lab to capture the current pattern.");redraw();return;}
 bazill_beats::Config c;c.task=static_cast<bazill_beats::Task>(task);c.preset=preset;c.amount=amount;c.seed=seed;c.instrument=target;
 c.beatSlice=target<48&&mtProject.instrument[target].playMode==playModeBeatSlice;c.slices=c.beatSlice?std::max<uint8_t>(1,mtProject.instrument[target].sliceNumber):1;c.note=mtProject.values.lastUsedNote;
 c.offsetFrames=sliceCount?static_cast<uint32_t>(uint64_t(sliceStarts[std::min<uint8_t>(downbeat,sliceCount-1)])*sampleLength/65535):0;
 const bool ok=work->generate(c,sliceStarts,sliceCount,sampleLength,mtProject.values.globalTempo);
 std::snprintf(notice,sizeof notice,ok?"PLAY: notes/timing/velocity. Step FX are heard after WRITE in Pattern. A/B compares.":"Cannot generate: choose BeatSlice for Chops, or extract a Groove first. Collisions need finer grid.");
 compare=false;redraw();
}
void BazillStudio::cancelConfirmation(){armed=false;}
void BazillStudio::apply(){
 if(!work||!work->isReady()||!unchanged()){armed=false;std::snprintf(notice,sizeof notice,"Nothing valid to write. Generate a fresh preview first.");redraw();return;}
 if(!armed){armed=true;std::snprintf(notice,sizeof notice,"WRITE again: replace Track %u, rows %u-%u. One Undo restores.",track+1,startStep+1,unsigned(startStep+work->size()));redraw();return;}
 sequencer.stop();sequencer.recEnable(false);stopNotes();running=false;newFileManager.storePatternUndoRevision();
 auto* p=sequencer.getActualPattern();const auto* src=work->view();
 for(unsigned i=0;i<work->size();++i){auto& out=p->track[track].step[startStep+i];out.note=src[i].note;out.instrument=src[i].instrument;out.volume=src[i].volume;out.micromove=src[i].micro;
  for(unsigned k=0;k<2;++k){out.fx[k].type=src[i].fx[k].type;out.fx[k].value=src[i].fx[k].value;}}
 newFileManager.setActualPatternStructChanged();snapshot();armed=false;std::snprintf(notice,sizeof notice,"Phrase written. Original project folder remains protected by Save As.");redraw();
}
void BazillStudio::beginExtract(){
 if(!unchanged()||selectedInstrument>=48||!sliceCount){std::snprintf(notice,sizeof notice,"Select a sliced sample first. Choose its downbeat slice with Up/Down and +/-.");redraw();return;}
 extracting=true;extractAt=0;running=false;stopNotes();std::fill(slicePeaks,slicePeaks+48,0);
 std::snprintf(notice,sizeof notice,"Extracting timing and local attack peaks. Project BPM defines the grid.");redraw();
}
void BazillStudio::updateExtract(){
 if(!unchanged()||newFileManager.getStatus()!=fmIdle){extracting=false;std::snprintf(notice,sizeof notice,"Extraction canceled: source changed or storage busy.");redraw();return;}
 const auto& m=mtProject.sampleMemory[selectedInstrument];const uint32_t offset=static_cast<uint32_t>(uint64_t(sliceStarts[extractAt])*sampleLength/65535);
 const uint32_t n=std::min<uint32_t>(256,sampleLength-offset);int16_t chunk[256];uint32_t peak=0;
 for(unsigned ch=0;ch<(m.isStereo?2u:1u);++ch){const int16_t* data=nullptr;
  if(m.isStreamed){if(!voiceStreamManager.readInstrumentFramesBlocking(selectedInstrument,ch,offset,n,chunk)){extracting=false;std::snprintf(notice,sizeof notice,"Extraction read failed. Pattern remains unchanged.");redraw();return;}data=chunk;}
  else if(m.address[ch])data=m.address[ch]+offset;
  if(!data){extracting=false;return;}
  for(uint32_t i=0;i<n;++i)peak=std::max<uint32_t>(peak,data[i]<0?-int32_t(data[i]):data[i]);
 }
 slicePeaks[extractAt]=static_cast<uint16_t>(peak);if(++extractAt<sliceCount)return;
 extracting=false;const bool ok=work->extract(sliceStarts,slicePeaks,sliceCount,sampleLength,mtProject.values.globalTempo,static_cast<uint32_t>(uint64_t(sliceStarts[std::min<uint8_t>(downbeat,sliceCount-1)])*sampleLength/65535));
 std::snprintf(notice,sizeof notice,ok?"Groove captured. Choose APPLY GROOVE; GENERATE stages timing/velocity changes.":"Extraction did not fit this sample/grid. Source remains unchanged.");redraw();
}
void BazillStudio::labels(){
 static const char* const beat[]={"TASK","PRESET","AMOUNT","SEED","GENERATE","A/B","WRITE","BACK"};
 static const char* const scope[]={"STYLE","HOLD","RESET","HEALTH","","","","BACK"};
 static const char* const memory[]={"PREV","NEXT","","","","","","BACK"};
 for(unsigned i=0;i<8;++i){const auto h=samplePlayback.label[i];display.setControlPosition(h,i*100+50,424);display.setControlSize(h,96,55);
  display.setControlData(h,nullptr);display.setControlStyle2(h,controlStyleShow|controlStyleCenterX|controlStyleCenterY|controlStyleFont3);
  display.setControlText(h,view==Beat?beat[i]:view==Scope?scope[i]:memory[i]);display.setControlText2(h,"");display.setControlValue(h,0);
  display.setControlColors(h,display.getTheme().activeLabelsColors);display.setControlShow(h);display.refreshControl(h);}
}
void BazillStudio::action(uint8_t key,uint8_t state){
 if(state!=buttonPress||key>7)return;
 if(key==7){samplePlayback.studioMode=0;samplePlayback.start(100);return;}
 if(view==Beat){if(key<4){param=key;cancelConfirmation();}else if(key==4)generate();else if(key==5){
   if(buttons->isButtonPressed(interfaceButtonShift))beginExtract();else{compare=!compare;cancelConfirmation();}}
  else if(key==6)apply();
 }else if(view==Scope){if(key==0)scopeMode=scopeMode>=2?0:scopeMode+1;else if(key==1){scopeHold=!scopeHold;bazill_scope::capture.enable(!scopeHold&&analyzer!=nullptr);}else if(key==2){std::fill(peakHold,peakHold+32,0.f);}else if(key==3){entryDlBytes=display.composedDisplayListBytes();scopeMode=3;updateHealth();}}
 else if(view==Memory){if(key==0)cursor=cursor?cursor-1:0;else if(key==1)cursor=std::min<unsigned>(47,cursor+1);}
 redraw();
}
void BazillStudio::change(int16_t d){
 if(!d) return;
 cancelConfirmation();
 if(view==Beat&&work)work->invalidate();
 if(view==Beat){running=false;stopNotes();if(param==0)task=static_cast<uint8_t>(std::clamp<int>(task+(d>0?1:-1),0,3));
  else if(param==1)preset=static_cast<uint8_t>(std::clamp<int>(preset+d,0,bazill_beats::presetCount-1));
  else if(param==2)amount=static_cast<uint8_t>(std::clamp<int>(amount+d,0,100));
  else if(param==3)seed=std::max<int64_t>(1,std::min<int64_t>(0x7fffffff,int64_t(seed)+d));
  else if(param==4){bars=static_cast<uint8_t>(std::clamp<int>(bars+(d>0?1:-1),1,8));snapshot();}
  else if(param==5)target=static_cast<uint8_t>(std::clamp<int>(target+d,0,kTotalInstrumentsCount-1));
  else if(param==6)downbeat=static_cast<uint8_t>(std::clamp<int>(downbeat+d,0,std::max<int>(0,sliceCount-1)));
 }else if(view==Memory)cursor=static_cast<uint8_t>(std::clamp<int>(cursor+d,0,47));else scopeMode=(scopeMode+(d>0?1:2))%3;
 redraw();
}
void BazillStudio::move(int x,int y){cancelConfirmation();if(view==Beat){if(y)param=static_cast<uint8_t>(std::clamp<int>(param+y,0,6));if(x&&work&&work->size())cursor=static_cast<uint8_t>(std::clamp<int>(cursor+x*(buttons->isButtonPressed(interfaceButtonShift)?16:1),0,work->size()-1));}else if(view==Memory)cursor=static_cast<uint8_t>(std::clamp<int>(cursor+x+y*8,0,47));else scopeMode=(scopeMode+(x+y>0?1:2))%3;redraw();}
void BazillStudio::middle(){cancelConfirmation();if(view==Beat&&work){work->toggleLock(cursor);running=false;stopNotes();}redraw();}
void BazillStudio::record(){if(view==Beat)beginExtract();}
void BazillStudio::play(){
 if(view!=Beat){if(sequencer.getSeqState()==Sequencer::SEQ_STATE_STOP)sequencer.playPattern();else sequencer.stop();return;}
 if(!work||!work->size()||(!work->isReady()&&!compare)) return;
 cancelConfirmation();running=!running;stopNotes();playingStep=0;nextStep=now();redraw();
}
void BazillStudio::update(){
 if(!active)return;
 if(view==Beat&&extracting)updateExtract();
 if(display.isHelpModal()||mtMenuPopup.isPopupVisible()){stopNotes();running=false;return;}
 const uint32_t t=now();
 if(view==Scope&&scopeMode==3&&static_cast<int32_t>(t-nextHealthFrame)>=0){updateHealth();nextHealthFrame=t+250000;redraw();}
 if(view==Scope&&analyzer&&!scopeHold&&static_cast<int32_t>(t-nextFrame)>=0){const int frame=bazill_scope::capture.acquire();if(frame>=0){analyzer->analyze(bazill_scope::capture.channel(frame,0),bazill_scope::capture.channel(frame,1));bazill_scope::capture.release();
  const float decay=std::min<uint32_t>(t-lastScopeFrame,250000)*.0000006f;lastScopeFrame=t;
  for(unsigned i=0;i<32;++i){meter[i]=analyzer->result.level[i];
   if(meter[i]>=peakHold[i]){peakHold[i]=meter[i];peakUntil[i]=t+750000;}
   else if(static_cast<int32_t>(t-peakUntil[i])>=0)peakHold[i]=std::max(meter[i],peakHold[i]-decay);
  }redraw();}
  nextFrame=t+(breakline_motion::mode()==breakline_motion::Mode::full?33333:100000);
 }
 if(pending&&static_cast<int32_t>(t-pendingAt)>=0)triggerPending();
 if(view==Beat&&running&&work&&static_cast<int32_t>(t-nextStep)>=0){
  pendingStep=work->view(compare)[playingStep];cursor=playingStep;
  const auto duration=interval();pendingAt=nextStep+static_cast<uint32_t>(uint64_t(duration)*std::max<int>(0,pendingStep.micro)/100);pending=true;
  playingStep=(playingStep+1)%work->size();nextStep+=duration;
  if(static_cast<int32_t>(t-nextStep)>=0){nextStep=t+duration;pendingAt=t;}
  redraw();
 }
 if(pending&&static_cast<int32_t>(t-pendingAt)>=0)triggerPending();

}
void BazillStudio::triggerPending(){
 const auto step=pendingStep;pending=false;
 if(step.note<=Sequencer::STEP_NOTE_OFF_FADE){stopNotes();return;}
 if(step.note<0)return;
 stopNotes();const auto previous=mtProject.values.lastUsedInstrument;
 mtProject.values.lastUsedInstrument=step.instrument;
 sequencer.handleNoteOn(Sequencer::GRID_OUTSIDE_PATTERN,step.note,step.volume<0?127:step.volume*127/100,source);
 mtProject.values.lastUsedInstrument=previous;previewNote=step.note;noteActive=true;
}
void BazillStudio::redraw(){if(active)display.refreshControl(panel);}
void BazillStudio::updateHealth(){
 auto* p=Profiler::getInstance();p->getAudioProcessingUsageUs(audioHealth);
 freeHeapBlocks=p->freeRamBytes();stackWatermark=p->maxStackBytes();
}
const char* BazillStudio::help(uint8_t key)const{
 static const char* const h[]={"Select Task. +/- changes Original Chops, Rhythm Chops, Variation or Apply Groove.","Select one of 32 named rhythm recipes. Existing synth and sample presets stay available.","Select variation/groove strength, 0-100 percent.","Select a repeatable seed. Up/Down also reaches Bars and Target Instrument.","Generate into a preview. Pattern data stays unchanged until WRITE twice.","Compare source/preview. REC or Shift+A/B extracts groove from current sample slices.","Tap twice to replace the shown track/range. Existing Undo restores the previous phrase.","Return to ordinary Sample Playback. Stops local audition and leaves the pattern intact."};
 if(view==Beat) return h[key<8?key:7];
 return view==Scope?"Live stereo output analysis. STYLE changes view, HOLD freezes analysis. HEALTH shows measured audio time, graphics usage and memory estimates; it writes no files. BACK restores Sample Playback.":"Inspect resident/streaming samples and free RAM. This view deletes or trims nothing.";
}
void BazillStudio::draw(){
 API_SAVE_CONTEXT();rect(0,30,800,394,0x080D13);rect(24,38,48,3,0x63F6C5);rect(728,38,48,3,0xD19AFF);
 char line[160];
 if(view==Beat){
  std::snprintf(line,sizeof line,"%c TASK %s    %s",param==0?'>':' ',tasks[task],compare?"SOURCE A":"PREVIEW B");text(24,52,line,0x63F6C5,1);
  std::snprintf(line,sizeof line,"%c %s   %c AMOUNT %u   %c SEED %lu",param==1?'>':' ',bazill_beats::presets[preset].name,param==2?'>':' ',amount,param==3?'>':' ',static_cast<unsigned long>(seed));text(24,83,line);
  std::snprintf(line,sizeof line,"%c BARS %u  %c INSTR %u  %c DOWNBEAT S%u  TRACK %u / ROW %u",param==4?'>':' ',bars,param==5?'>':' ',target+1,param==6?'>':' ',downbeat+1,track+1,startStep+1);text(24,108,line,0x91A8B8);
  if(work){const auto* steps=work->view(compare);const unsigned first=(cursor/32)*32;
   std::snprintf(line,sizeof line,"CELLS %u-%u / %u   SHIFT+LEFT/RIGHT: JUMP 16",first+1,std::min(first+32,work->size()),work->size());text(24,138,line,0x607B90);
   for(unsigned i=first;i<std::min(first+32,work->size());++i){const int x=24+((i-first)%16)*47,y=180+((i-first)/16)*76;
    rect(x,y,43,62,i==cursor?0x263C49:0x121D29);
    if(steps[i].note>=0){const uint32_t color=steps[i].instrument==target?0x63F6C5:0xD19AFF;rect(x+4,y+5,35,3,color);char n[8];std::snprintf(n,sizeof n,"%02u",unsigned(steps[i].note));text(x+8,y+25,n,color,1);}
    if(work->locked(i))rect(x+36,y+2,5,5,0xF8BD62);
   }}
 }else if(view==Scope){
  if(scopeMode==3){
   text(24,52,"SYSTEM HEALTH / LIVE MEASUREMENTS",0x63F6C5,1);
   std::snprintf(line,sizeof line,"AUDIO / last %d us / average %d us / peak %d us",audioHealth.last,audioHealth.average,audioHealth.maximum);text(24,100,line);
   std::snprintf(line,sizeof line,"AUDIO BLOCK / %u frames / %.1f us budget",unsigned(AUDIO_BLOCK_SAMPLES),AUDIO_BLOCK_SAMPLES*1000000./44100.);text(24,131,line,0x91A8B8);
   std::snprintf(line,sizeof line,"GRAPHICS DL / now %lu B / peak %lu B / at entry %lu B",static_cast<unsigned long>(display.composedDisplayListBytes()),static_cast<unsigned long>(display.peakDisplayListBytes()),static_cast<unsigned long>(entryDlBytes));text(24,179,line);
   std::snprintf(line,sizeof line,"CLIPPED COMPOSITIONS / %lu",static_cast<unsigned long>(display.clippedCompositions()));text(24,210,line,display.clippedCompositions()?0xF8BD62:0x63F6C5);
   std::snprintf(line,sizeof line,"ALLOCATOR FREE BLOCKS / %lu bytes",static_cast<unsigned long>(freeHeapBlocks));text(24,258,line);
   std::snprintf(line,sizeof line,"STACK USED / %lu bytes / watermark estimate",static_cast<unsigned long>(stackWatermark));text(24,289,line,0x91A8B8);
   text(24,337,"Observe during playback. Peak values cover this boot session.",0x607B90);
   text(24,365,"STYLE returns to analysis. No performance rating or SD writes.",0x607B90);
  }else{
  text(24,52,scopeMode==0?"SPECTRUM / 32 BANDS":scopeMode==1?"STEREO OSCILLOSCOPE":"STEREO PHASE",0x63F6C5,1);
  text(24,82,scopeHold?"HOLD / audio playback continues":"LIVE / sample peaks, no intersample true-peak measurement",0x91A8B8);
  if(scopeMode==0){for(unsigned i=0;i<32;++i){const int x=24+i*23,h=static_cast<int>(meter[i]*214);rect(x,350-h,17,h,i<10?0x63F6C5:i<23?0x71BDDD:0xD19AFF);rect(x,349-static_cast<int>(peakHold[i]*214),17,2,0xF8BD62);}text(24,363,"43 Hz                  1 kHz                       22 kHz",0x607B90);}
  else if(analyzer){
   for(unsigned ch=0;ch<(scopeMode==1?2u:1u);++ch){
    API_COLOR(ch?0xD19AFF:0x63F6C5);API_LINE_WIDTH(16);API_BEGIN(LINE_STRIP);
    for(unsigned i=0;i<64;++i){const auto& r=analyzer->result;const int x=scopeMode==1?24+i*752/63:400+r.waveform[0][i]*300/32768;
     const int y=240-r.waveform[scopeMode==1?ch:1][i]*110/32768;API_VERTEX2F(x,y);}API_END();
   }
  }
  if(analyzer){const auto& r=analyzer->result;std::snprintf(line,sizeof line,"L %5.1f dB  R %5.1f dB   CORRELATION %+0.2f",20*std::log10(std::max(r.peak[0],1e-6f)),20*std::log10(std::max(r.peak[1],1e-6f)),r.correlation);text(24,111,line);}
  }
 }else{
  const auto free=mtProject.used_memory<mtProject.max_memory?mtProject.max_memory-mtProject.used_memory:0;
  std::snprintf(line,sizeof line,"SAMPLE RAM / %.2f MiB used / %.2f MiB free",mtProject.used_memory/1048576.,free/1048576.);text(24,52,line,0x63F6C5,1);
  const unsigned first=(cursor/32)*32;
  for(unsigned i=first;i<std::min(first+32,48u);++i){const int x=24+((i-first)%8)*94,y=104+((i-first)/8)*48;const auto& m=mtProject.sampleMemory[i];const auto& inst=mtProject.instrument[i];
   rect(x,y,88,35,i==cursor?0x263C49:0x121D29);std::snprintf(line,sizeof line,"%02u %s",i+1,!inst.sample.length?"--":m.isStreamed?"SD":"RAM");text(x+6,y+9,line,!inst.sample.length?0x607B90:m.isStreamed?0xD19AFF:0x63F6C5);
  }
  const auto& inst=mtProject.instrument[cursor];std::snprintf(line,sizeof line,"SLOT %u / %.2f sec / %s / %u slices",cursor+1,inst.sample.length/44100.,mtProject.sampleMemory[cursor].isStereo?"STEREO":"MONO",inst.sliceNumber);text(24,365,line);
 }
 text(24,397,notice,armed?0xF8BD62:0x91A8B8);API_RESTORE_CONTEXT();
}
#endif
