// SPDX-License-Identifier: MIT
#pragma once
#ifdef TRACKER_MINI
#include "core/modulesBase.h"
#include "breakline/drum_workbench.hpp"
#include "BazillTryAlloc.h"
#include <memory>
class BazillDrumLab:public ModuleBase {
public:
 void initDisplayControls()override;void destroyDisplayControls()override{}
 void start(uint32_t options=0)override;void stop()override;void update()override;
 void hideControlsUnderMiniMenu()override;
 bool isActive()const{return active;}
 void action(uint8_t key,uint8_t state);void change(int16_t d);void move(int x,int y);void middle();void play();
 void draw();void resume();void cancelConfirmation();const char* help(uint8_t key)const;
private:
 void bind();void labels();void redraw();void stopNotes();void trigger(unsigned lane);
 void generate();void apply();void updatePacking();void buildSynthKit();void mapPercVoices();uint8_t note(unsigned lane)const;
 bool validVoice(unsigned lane)const;bool validDestination()const;uint32_t fingerprint()const;
 bazill_alloc::Ptr<bazill_drums::Workbench> grid;
 hControl panel=-1;bool active=false,running=false,compare=false,ready=false,armed=false,kitArmed=false,compact=true;
 uint8_t sourceMode=1,kit=0,preset=0,variation=30,bars=2,swing=255,param=1,lane=0,cursor=0,track=0,startRow=0;
 uint8_t voice[8]={255,255,255,255,255,255,255,255};
 bool sounding[8]{},pending[8]{};
 uint8_t pendingVelocity[8]{};uint32_t pendingAt[8]{},nextStep=0,seed=1,sourceHash=0;unsigned playingStep=0;
 char notice[112]="",values[8][24]{};
};
extern BazillDrumLab bazillDrumLab;
#endif
