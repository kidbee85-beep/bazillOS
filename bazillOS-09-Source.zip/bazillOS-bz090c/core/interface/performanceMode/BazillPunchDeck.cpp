// SPDX-License-Identifier: MIT
#include "config.h"
#ifdef TRACKER_MINI
#include "BazillPunchDeck.h"
#include "performanceMode.h"
#include "performanceEngine.h"
#include "core/interface.h"
#include "core/interfaceMenuPopup.h"
#include "core/interfacePopups.h"
#include "core/songTimer.h"
#include "fileManager.h"
#include "Platform.h"
#include "FT812.h"
#include "BazillSurface.h"
#include "BazillPunchVisuals.h"
#include "BreaklineMotion.h"
#include <cstdio>
BazillPunchDeck bazillPunchDeck;
namespace {
class PunchControl:public cDisplayControl {public:explicit PunchControl(strControlProperties*p):cDisplayControl(controlIdTemplate,1){style=p->style;}
 void setStyle(uint32_t s)override{style=s;}void setText(const char*)override{}void setValue(int)override{}void setColors(const uint32_t*)override{}void setData(void*)override{}
 void update()override{bazillPunchDeck.draw();}};
void key(uint8_t k,uint8_t s){bazillPunchDeck.action(k,s);}void change(int16_t d){bazillPunchDeck.change(d);}
void left(){bazillPunchDeck.move(-1,0);}void right(){bazillPunchDeck.move(1,0);}void up(){bazillPunchDeck.move(0,-1);}void down(){bazillPunchDeck.move(0,1);}
void middle(){bazillPunchDeck.middle();}void play(){bazillPunchDeck.play();}void panic(){bazillPunchDeck.panic();}
void menu(uint8_t s){if(s==buttonPress)mtMenuPopup.showModulePopup(&performanceMode);else if(s==buttonRelease)mtMenuPopup.hideModulePopup(&performanceMode);}
void switchModule(uint8_t k){performanceMode.eventFunct(eventSwitchModule,&performanceMode,&k,nullptr);}
void rect(int x,int y,int w,int h,uint32_t c){API_COLOR(c);API_BEGIN(RECTS);API_VERTEX2F(x,y);API_VERTEX2F(x+w-1,y+h-1);API_END();}
void text(int x,int y,const char*s,uint32_t color){API_COLOR(color);API_CMD_TEXT(x,y,fonts[0].handle,0,s);}
void cardText(int x,int y,const char*s,uint32_t color,unsigned face=0,unsigned maxWidth=156){
 API_SAVE_CONTEXT();API_COLOR(color);API_BITMAP_HANDLE(fonts[face].handle);API_VERTEX_TRANSLATE_X(x*16);API_BEGIN(BITMAPS);
 unsigned at=0;for(unsigned i=0;s[i];++i){const auto c=static_cast<unsigned char>(s[i]);const unsigned advance=fonts[face].data[c];if(at+advance>maxWidth)break;API_VERTEX2II(at,y,fonts[face].handle,c);at+=advance;}
 API_END();API_RESTORE_CONTEXT();
}
}
void BazillPunchDeck::initDisplayControls(){strControlProperties p{};panel=display.createControl<PunchControl>(&p);}
void BazillPunchDeck::start(uint32_t){
 stop();if(performance.turnOff()){
  newFileManager.loadWorkspacePatternNow(mtProject.values.actualPattern);sequencer.switchRamPatternsNow();
 }performanceMode.moduleRefresh=1;active=true;deck.clear();visualClock.reset();lastMotion=breakline_motion::mode();sequencer.recEnable(false);resetBreaklineActionHelp();
 for(auto h:{performanceMode.frameControl,performanceMode.bgLabel})display.setControlHide(h);
 for(unsigned i=0;i<12;++i){display.setControlHide(performanceMode.textLabel[i]);display.setControlHide(performanceMode.value1Label[i]);}
 songTimer.hide();titleBar->show(false);titleBar->setTitle("PUNCH DECK");bind();labels();display.setControlShow(panel);redraw();
}
void BazillPunchDeck::closeHelp(){if(helpVisible){mtPopups.hide();display.setHelpModal(false);helpVisible=false;}}
void BazillPunchDeck::panic(){deck.clear();visualClock.reset();closeHelp();sync();redraw();}
void BazillPunchDeck::stop(){if(!active)return;performanceMode.moduleRefresh=0;panic();active=false;songTimer.show();display.setControlHide(panel);}
void BazillPunchDeck::hideControlsUnderMiniMenu(){panic();display.setControlHide(panel);}
void BazillPunchDeck::bind(){
 ip->clearButtonsRange(interfaceButton0,interfaceButton32);ip->clearAllPots();
 for(unsigned i=0;i<8;++i)ip->setButtonObj(i,key);
 ip->setButtonObj(interfaceButtonLeft,buttonPress,left);ip->setButtonObj(interfaceButtonRight,buttonPress,right);ip->setButtonObj(interfaceButtonUp,buttonPress,up);ip->setButtonObj(interfaceButtonDown,buttonPress,down);
 ip->setButtonObj(interfaceButtonMiniMiddle,buttonPress,::middle);ip->setButtonObj(interfaceButtonPlay,buttonPress,::play);ip->setButtonObj(interfaceButtonRec,buttonPress,::panic);ip->setPotObj(interfacePot0,::change);ip->setButtonObj(interfaceButtonMiniMenu,::menu);
 for(unsigned k=interfaceButtonParams;k<=interfaceButtonPattern;++k)ip->setButtonObj(k,buttonPress,switchModule);ip->setButtonObj(interfaceButtonGame,buttonPress,switchModule);
}
void BazillPunchDeck::labels(){for(unsigned i=0;i<8;++i){auto h=performanceMode.label[i];display.setControlPosition(h,i*100+50,424);display.setControlSize(h,96,55);display.setControlData(h,nullptr);display.setControlStyle2(h,controlStyleShow|controlStyleCenterX|controlStyleCenterY|controlStyleFont3);display.setControlText(h,bazill_punch::recipes[deck.bank*8+i].name);display.setControlText2(h,"");display.setControlValue(h,0);display.setControlColors(h,display.getTheme().activeLabelsColors);display.setControlShow(h);display.refreshControl(h);}}
void BazillPunchDeck::redraw(){if(active)display.refreshControl(panel);}
void BazillPunchDeck::sync(){
 using namespace bazill_punch;const auto target=deck.frame();
 for(unsigned t=0;t<8;++t){const Frame next=(deck.tracks&(1u<<t))?target:clean();auto& old=applied[t];auto& player=instrumentPlayer[t];
  for(unsigned p=0;p<Count;++p){if(next[p]==old[p])continue;const bool clear=next[p]==unset;const int v=clear?0:next[p];
   switch(p){
    case Volume:if(clear)player.endVolumePerformanceMode();else player.changeVolumePerformanceMode(v);break;
    case Tune:if(clear)player.endTunePerformanceMode();else player.changeTunePerformanceMode(v);break;
    case Pan:if(clear)player.endPanningPerformanceMode();else player.changePanningPerformanceMode(v);break;
    case Filter:if(clear)player.endFilterTypePerformanceMode();else player.changeFilterTypePerformanceMode(v);break;
    case Cutoff:if(clear)player.endCutoffPerformanceMode();else player.changeCutoffPerformanceMode(v);break;
    case Bits:if(clear)player.endBitDepthPerformanceMode();else player.changeBitDepthPerformanceMode(v);break;
    case Drive:if(clear)player.endOverdrivePerformanceMode();else player.changeOverdrivePerformanceMode(v);break;
    case Delay:if(clear)player.endDelaySendPerformanceMode();else player.changeDelaySendPerformanceMode(v);break;
    case bazill_punch::Reverb:if(clear)player.endReverbSendPerformanceMode();else player.changeReverbSendPerformanceMode(v);break;
    case Reverse:if(clear)player.endSamplePlaybackPerformanceMode();else player.changeSamplePlaybackPerformanceMode(v);break;
    case Repeat:sequencer.setStepRepeater(t,v);break;
   }
  }old=next;
 }
}
void BazillPunchDeck::action(uint8_t k,uint8_t state){if(k>=8)return;
 if(helpVisible){if(state==buttonRelease&&deck.help==k){deck.release(k);closeHelp();redraw();}return;}
 if(state==buttonPress)deck.press(k);
 else if(state==buttonRelease)deck.release(k);
 else if(state==buttonHold)return; // Keep the punch active until release. Help: Shift+Menu.

 sync();redraw();
}
void BazillPunchDeck::move(int x,int y){if(helpVisible)return;deck.clear();if(y){deck.nextBank(y);labels();}if(x)deck.cursor=std::clamp<int>(int(deck.cursor)+x,0,7);sync();redraw();}
void BazillPunchDeck::middle(){if(helpVisible)return;deck.clear();if(buttons->isButtonPressed(interfaceButtonShift))deck.toggleLatch();else deck.tracks^=1u<<deck.cursor;sync();redraw();}
void BazillPunchDeck::change(int16_t d){if(helpVisible)return;deck.intensity=std::clamp<int>(int(deck.intensity)+d,0,100);sync();redraw();}
void BazillPunchDeck::play(){panic();if(sequencer.isPlay())sequencer.stop();else sequencer.playPattern();}
void BazillPunchDeck::update(){if(!active)return;if(mtMenuPopup.isPopupVisible()||newFileManager.getStatus()!=fmIdle){panic();return;}
 if(display.isHelpModal()){if(!helpVisible){deck.clear();sync();}return;}
 const auto motion=breakline_motion::mode();
 if(motion!=lastMotion){lastMotion=motion;visualClock.reset();redraw();}
 const bool eligible=motion==breakline_motion::Mode::full&&deck.active&&deck.tracks&&deck.intensity;
 const uint32_t now=eligible?breakline_motion::nowMs():0;
 if(visualClock.poll(now,eligible,eligible&&display.isControlsRefreshProcessIdle()))redraw();
}
void BazillPunchDeck::draw(){
 const auto motion=breakline_motion::mode();const bool visual=deck.active&&deck.tracks&&deck.intensity&&motion!=breakline_motion::Mode::off;
 const bool moving=visual&&motion==breakline_motion::Mode::full;const unsigned phase=moving?visualClock.phase():0;
 API_SAVE_CONTEXT();rect(0,30,800,394,0x080D13);bazill_surface::texture(0,30,800,394,0x8797BB,30);bazill_surface::mascot(748,42,visual?(moving?phase/4:11):10,0xEAB0F7,215);
 char line[100];std::snprintf(line,sizeof line,"PUNCH DECK / %s",bazill_punch::banks[deck.bank]);text(24,48,line,0x6BE6C2);
 std::snprintf(line,sizeof line,"%s / INTENSITY %u / SAMPLE TRACKS ONLY",deck.latch?"LATCH":"MOMENTARY",deck.intensity);text(24,75,line,deck.active?0xF8BD62:0x91A8B8);
 for(unsigned i=0;i<8;++i){const int x=24+i*93;rect(x,102,84,28,deck.tracks&(1u<<i)?0x2C6257:0x223044);std::snprintf(line,sizeof line,"T%u %s",i+1,deck.tracks&(1u<<i)?"ON":"OFF");cardText(x+7,109,line,i==deck.cursor?0xF8BD62:0xBED0DB,2,70);if(i==deck.cursor)bazill_surface::faultFrame(x,102,84,28,0xEAB0F7,255);}
 if(visual)bazill_punch_visuals::strip(phase,bazill_punch_visuals::ink(deck.bank));
 for(unsigned i=0;i<8;++i){const int x=24+(i%4)*190,y=151+(i/4)*111;const bool on=deck.active&(1u<<i);const auto&r=bazill_punch::recipes[deck.bank*8+i];rect(x,y,176,96,on?0x304F47:0x1B293B);bazill_surface::faultFrame(x,y,176,96,on?0x6BE6C2:0x34405B,on?255:130);std::snprintf(line,sizeof line,"%u / %s",i+1,r.name);cardText(x+10,y+15,line,on?0xA6ED72:0xBED0DB,2);cardText(x+10,y+43,r.detail,0x91A8B8);if(on&&visual)bazill_punch_visuals::band(deck.bank*8+i,x,y,phase+i*3,moving,bazill_punch_visuals::ink(deck.bank));rect(x+10,y+90,156*deck.intensity/100+1,3,on?0x6BE6C2:0x34405B);}
 text(24,383,"L/R TRACK   U/D PAGE   MIDDLE: TARGET   +/-: AMOUNT",0x91A8B8);
 text(24,402,"SHIFT+MENU HELP / REC CLEAR / SHIFT+MIDDLE LATCH",0x91A8B8);API_RESTORE_CONTEXT();
}
#endif
