// SPDX-License-Identifier: MIT
#pragma once
#ifdef TRACKER_MINI
#include "core/modulesBase.h"
#include "breakline/punch_deck.hpp"
#include "breakline/punch_visuals.hpp"
#include "BreaklineMotion.h"
class BazillPunchDeck:public ModuleBase {
public:
 void initDisplayControls()override;void destroyDisplayControls()override{}
 void start(uint32_t=0)override;void stop()override;void update()override;
 void hideControlsUnderMiniMenu()override;bool isActive()const{return active;}
 void action(uint8_t,uint8_t);void move(int,int);void middle();void change(int16_t);void play();void panic();void draw();
private:
 void bind();void labels();void sync();void closeHelp();void redraw();
 bazill_punch::Deck deck;
 bazill_punch::Frame applied[8]={bazill_punch::clean(),bazill_punch::clean(),bazill_punch::clean(),bazill_punch::clean(),bazill_punch::clean(),bazill_punch::clean(),bazill_punch::clean(),bazill_punch::clean()};
 bool active=false,helpVisible=false;hControl panel=-1;
 bazill_punch_visuals::Cadence visualClock;
 breakline_motion::Mode lastMotion=breakline_motion::Mode::off;
};
extern BazillPunchDeck bazillPunchDeck;
#endif
