// SPDX-License-Identifier: MIT
#include "config.h"
#ifdef TRACKER_MINI
#include "BazillComposer.h"
#include "patternEditor.h"
#include "core/interface.h"
#include "core/songTimer.h"
#include "Platform.h"
#include "fileManager.h"
#include "FT812.h"
#include "scales.h"
#include "BazillSurface.h"
#include "breakline/mutable_fill.hpp"
#include "breakline/global_swing.hpp"
#include <cmath>
#include <cstdio>
#include <cstring>
using namespace bazill_composer;
BazillComposer bazillComposer;
namespace {
constexpr int sourceBase=1040;
uint32_t clockUs(){return mtInterface.getPlatform()->getTimer()->micros();}
uint32_t stepUs(){const float t=sequencer.getStepPeriodMs()*1000.f;return std::isfinite(t)?std::clamp(t,10000.f,1000000.f):125000;}
uint32_t previewStepUs(unsigned step){const auto base=stepUs();const unsigned swing=bazill_swing::read(mtProject.values.midiInstrument[0].reserved);return uint32_t(uint64_t(base)*(step%2?200-2*swing:2*swing)/100);}
void rect(int x,int y,int w,int h,uint32_t c){API_COLOR(c);API_BEGIN(RECTS);API_VERTEX2F(x,y);API_VERTEX2F(x+w-1,y+h-1);API_END();}
void text(int x,int y,const char*s,uint32_t c=0xBED0DB){
 API_COLOR(c);API_BITMAP_HANDLE(fonts[0].handle);API_BEGIN(BITMAPS);
 for(unsigned n=0;s[n]&&n<111;++n){const unsigned ch=static_cast<unsigned char>(s[n]);if(ch>=128||x+fonts[0].data[ch]>784)break;
  if(x<=511)API_VERTEX2II(x,y,fonts[0].handle,ch);else{API_CELL(ch);API_VERTEX2F(x,y);}x+=fonts[0].data[ch];}
 API_END();
}
class ComposerControl:public cDisplayControl {public:explicit ComposerControl(strControlProperties*p):cDisplayControl(controlIdTemplate,1){style=p->style;}
 void setStyle(uint32_t s)override{style=s;}void setText(const char*)override{}void setValue(int)override{}void setColors(const uint32_t*)override{}void setData(void*)override{}void update()override{bazillComposer.draw();}};
void key(uint8_t k,uint8_t s){bazillComposer.action(k,s);}void change(int16_t d){bazillComposer.change(d);}
void left(){bazillComposer.move(-1,0);}void right(){bazillComposer.move(1,0);}void up(){bazillComposer.move(0,-1);}void down(){bazillComposer.move(0,1);}
void middle(){bazillComposer.middle();}void play(){bazillComposer.play();}void menu(uint8_t s){if(s==buttonPress)bazillComposer.action(7,buttonPress);}
}
void BazillComposer::initDisplayControls(){strControlProperties p{};panel=display.createControl<ComposerControl>(&p);}
unsigned BazillComposer::count()const{unsigned n=0;if(data)for(const auto&l:data->lanes)n+=l.included;return n;}
void BazillComposer::start(uint32_t){
 if(newFileManager.getStatus()!=fmIdle)return;
 if(patternEditor.trackerPattern.actualTrack>=8){patternEditor.start(0);mtPopups.show(0,"Composer targets audio Tracks 1-8. Select an audio track first; MIDI tracks stay unchanged.");return;}
 stop();data.reset(bazill_alloc::create<Session>());
 if(!data){patternEditor.start(0);mtPopups.show(0,"Composer needs more free RAM. The project was not changed.");return;}
 active=true;ready=armed=running=false;lane=std::min<unsigned>(patternEditor.trackerPattern.actualTrack,7);param=tone=0;scaleIndex=1;
 sequencer.stop();sequencer.recEnable(false);resetBreaklineActionHelp();
 data->settings.length=sequencer.getActualPattern()?std::clamp<int>(sequencer.getActualPattern()->track[0].length+1,1,128):64;
 data->settings.scale=scaleDef[scaleIndex];
 for(unsigned t=0;t<8;++t){auto&l=data->lanes[t];l.role=Bass;l.sound=66;l.included=t==lane;
  const auto*p=sequencer.getActualPattern();if(p)for(unsigned n=0;n<=p->track[t].length&&n<128;++n)if(p->track[t].step[n].note>=0){l.sound=p->track[t].step[n].instrument;break;}}
 for(auto h:{patternEditor.bgLabel,patternEditor.patternControl,patternEditor.frameControl})display.setControlHide(h);
 songTimer.hide();titleBar->show(false);titleBar->setTitle("COMPOSER");bind();labels();display.setControlShow(panel);generate(false);
}
void BazillComposer::bind(){ip->clearButtonsRange(interfaceButton0,interfaceButton32);ip->clearAllPots();for(unsigned i=0;i<8;++i)ip->setButtonObj(i,key);
 ip->setButtonObj(interfaceButtonLeft,buttonPress,left);ip->setButtonObj(interfaceButtonRight,buttonPress,right);ip->setButtonObj(interfaceButtonUp,buttonPress,up);ip->setButtonObj(interfaceButtonDown,buttonPress,down);
 ip->setButtonObj(interfaceButtonMiniMiddle,buttonPress,::middle);ip->setButtonObj(interfaceButtonPlay,buttonPress,::play);ip->setPotObj(interfacePot0,::change);ip->setButtonObj(interfaceButtonMiniMenu,::menu);
}
void BazillComposer::labels(){const char*names[]={"TRACKS","STYLE","ROLE","SOUND","TONE","GENERATE","WRITE","BACK"};
 for(unsigned i=0;i<8;++i){auto h=patternEditor.label[i];display.setControlPosition(h,i*100+50,424);display.setControlSize(h,96,55);display.setControlData(h,nullptr);display.setControlStyle2(h,controlStyleShow|controlStyleCenterX|controlStyleCenterY|controlStyleFont3);display.setControlText(h,names[i]);display.setControlText2(h,"");display.setControlValue(h,0);display.setControlColors(h,display.getTheme().activeLabelsColors);display.setControlShow(h);display.refreshControl(h);}}
void BazillComposer::redraw(){if(!active)return;std::snprintf(writeLabel,sizeof writeLabel,"%s %uT",armed?"CONFIRM":"WRITE",count());display.setControlText(patternEditor.label[6],writeLabel);display.refreshControl(patternEditor.label[6]);display.refreshControl(panel);}
void BazillComposer::stopNotes(){for(unsigned t=0;t<8;++t)if(sounding[t]>=0){sequencer.handleNoteOff(Sequencer::GRID_OUTSIDE_PATTERN,sounding[t],0,sourceBase+t);sounding[t]=-1;}}
void BazillComposer::stop(){if(!active)return;stopNotes();active=ready=armed=running=false;data.reset();display.setControlHide(panel);songTimer.show();resetBreaklineActionHelp();}
void BazillComposer::back(){stop();patternEditor.start(0);}
void BazillComposer::hideControlsUnderMiniMenu(){stopNotes();running=false;armed=false;display.setControlHide(panel);}
bool BazillComposer::validSound(unsigned t)const{
 if(!data||t>=8)return false;
 const auto&l=data->lanes[t];const unsigned v=l.sound;
 if(v>=64&&v<67){const auto&p=mtProject.values.synthPart[v-64];return p.synthType&&p.voiceCount>0&&(drum(l.role)||p.synthType!=4);}
 if(v>=48)return false;
 const auto&i=mtProject.instrument[v];return i.isActive&&i.sample.type==mtSampleTypeWaveFile&&i.sample.length>0&&i.playMode!=playModeBeatSlice&&i.playMode!=playModeSlice;
}
bool BazillComposer::validStage()const{if(!data||!count()||!valid(data->settings)||!sequencer.getActualPattern())return false;for(unsigned t=0;t<8;++t)if(data->lanes[t].included&&!validSound(t))return false;return true;}
uint32_t BazillComposer::fingerprint()const{
 if(!data)return 0;
 const auto*p=sequencer.getActualPattern();if(!p)return 0;uint32_t h=2166136261u;auto add=[&](uint8_t b){h=(h^b)*16777619u;};
 add(mtProject.values.actualPattern);for(unsigned t=0;t<8;++t){add(p->track[t].length);if(!data->lanes[t].included)continue;for(unsigned n=0;n<128;++n){const auto&s=p->track[t].step[n];add(s.note);add(s.instrument);add(s.volume);add(s.micromove);for(auto f:s.fx){add(f.type);add(f.value);}}
  const unsigned v=data->lanes[t].sound;if(v<48){const auto&i=mtProject.instrument[v];const auto*b=reinterpret_cast<const uint8_t*>(&i);for(unsigned k=0;k<sizeof i;++k)add(b[k]);const uint32_t hash=mtProject.sampleMemory[v].sampleHash;for(unsigned k=0;k<4;++k)add(hash>>(8*k));}
  else if(v>=64&&v<67){const auto&s=mtProject.values.synthPart[v-64];const auto*b=reinterpret_cast<const uint8_t*>(&s);for(unsigned k=0;k<sizeof s;++k)add(b[k]);}
 }return h;
}
void BazillComposer::generate(bool reroll){if(!data)return;stopNotes();running=armed=false;if(reroll)++data->settings.seed;
 // Reuse the already integrated MIT Marbles stream, in the UI task only.
 float curve[16];uint8_t memory[16];bazill_fill::curve(false,data->settings.seed,curve);for(unsigned n=0;n<16;++n)memory[n]=std::isfinite(curve[n])?std::clamp<int>(curve[n]*127,0,127):64;
 ready=bazill_composer::generate(data->stage,data->settings,data->lanes,true,memory)&&validStage();sourceHash=fingerprint();
 std::snprintf(notice,sizeof notice,ready?"STAGED. Play auditions. Middle: include. Shift+Middle: lock. WRITE twice commits.":"Choose a ready sound for every included track. Melodic roles need a synth or unsliced sample.");redraw();
 if(ready){for(unsigned part=0;part<3;++part){unsigned used=0;for(const auto&l:data->lanes)used+=l.included&&!drum(l.role)&&l.sound==64+part;const int voices=mtProject.values.synthPart[part].voiceCount;if(used&&int(used)>voices){std::snprintf(notice,sizeof notice,"S%u has %u voice(s) shared by %u melodic lanes. Choose other sounds or raise its voice count.",part+1,unsigned(std::max(0,voices)),used);redraw();break;}}}
}
void BazillComposer::apply(){
 if(!ready||!validStage()||newFileManager.getStatus()!=fmIdle||fingerprint()!=sourceHash){armed=running=false;stopNotes();ready=false;std::snprintf(notice,sizeof notice,"Source changed or sound unavailable. GENERATE a new preview.");redraw();return;}
 if(!armed){armed=true;std::snprintf(notice,sizeof notice,"WRITE again: %u tracks replaced; ALL 8 lengths become %u. Other notes stay. One Undo restores.",count(),data->settings.length);redraw();return;}
 stopNotes();running=false;sequencer.stop();sequencer.recEnable(false);newFileManager.storePatternUndoRevision();auto*p=sequencer.getActualPattern();
 for(unsigned t=0;t<8;++t){p->track[t].length=data->settings.length-1;if(!data->lanes[t].included)continue;for(unsigned n=0;n<data->settings.length;++n){auto&out=p->track[t].step[n];const auto&c=data->stage.cells[t][n];out.note=c.note;out.instrument=c.note>=0?data->lanes[t].sound:0;out.volume=c.note>=0?c.velocity:-1;out.micromove=-1;for(auto&f:out.fx){f.type=0;f.value=0;}
   if(c.note>=0){if(c.gate){out.fx[0].type=Sequencer::strFxConsts::FX_TYPE_GATE_LENGTH;out.fx[0].value=c.gate;}if(data->settings.chance<100){out.fx[1].type=Sequencer::strFxConsts::FX_TYPE_CHANCE;out.fx[1].value=data->settings.chance;}}
 }}
 newFileManager.setActualPatternStructChanged();sourceHash=fingerprint();armed=false;std::snprintf(notice,sizeof notice,"Written. BACK returns to Pattern. Native Undo restores notes and lengths.");redraw();
}
void BazillComposer::action(uint8_t k,uint8_t s){if(s!=buttonPress||k>7||!data)return;const bool shift=buttons->isButtonPressed(interfaceButtonShift);
 if(k==7){back();return;}if(k==6){apply();return;}armed=false;
 if(k==5){if(shift){if(!ready||fingerprint()!=sourceHash){ready=false;std::snprintf(notice,sizeof notice,"Generate a fresh preview before mutation.");redraw();return;}stopNotes();running=false;++data->settings.seed;bazill_composer::mutate(data->stage,data->settings,data->lanes);std::snprintf(notice,sizeof notice,"MUTATED: rhythm retained; unlocked notes/accents varied. WRITE twice keeps it.");redraw();}else generate(true);return;}
 if(k==0&&shift){stopNotes();running=false;for(unsigned t=0;t<8;++t){auto&l=data->lanes[t];l.included=t<4;l.locked=false;l.role=t==0?Kick:t==1?Snare:t==2?ClosedHat:Bass;l.sound=t<3?64:66;}generate(false);return;}
 if(k==4&&param==4)tone=(tone+1)%7;
 param=k;redraw();
}
void BazillComposer::move(int x,int y){if(!active)return;armed=false;lane=std::clamp<int>(int(lane)+y,0,7);param=(param+x+5)%5;redraw();}
void BazillComposer::middle(){if(!data)return;stopNotes();running=armed=false;auto&l=data->lanes[lane];if(buttons->isButtonPressed(interfaceButtonShift)){l.locked=!l.locked;redraw();return;}l.included=!l.included;if(l.included)l.locked=false;generate(false);}
void BazillComposer::change(int16_t d){if(!d||!data)return;stopNotes();running=armed=false;auto&s=data->settings;auto&l=data->lanes[lane];
 // Sound selection alone never regenerates pitches; it also unlocks this lane.
 if(param==0){l.amount=std::clamp<int>(int(l.amount)+d,0,100);l.locked=false;}
 else if(param==1){s.style=std::clamp<int>(int(s.style)+d,0,styleCount-1);for(auto&v:data->lanes)v.locked=false;}
 else if(param==2){l.role=Role(std::clamp<int>(int(l.role)+d,0,roleCount-1));l.locked=false;}
 else if(param==3){int v=l.sound;for(int n=0;n<67;++n){v=(v+(d>0?1:66))%67;const auto old=l.sound;l.sound=v;const bool ok=validSound(lane);l.sound=old;if(ok){l.sound=v;break;}}}
 else {for(auto&v:data->lanes)v.locked=false;switch(tone){case 0:s.length=std::clamp<int>(int(s.length)+d,1,128);break;case 1:s.key=(int(s.key)+d%12+12)%12;break;case 2:scaleIndex=std::clamp<int>(int(scaleIndex)+d,0,MAX_SCALE);s.scale=scaleDef[scaleIndex];break;case 3:s.chance=std::clamp<int>(int(s.chance)+d,0,100);break;case 4:s.variation=std::clamp<int>(int(s.variation)+d,0,100);break;case 5:s.seed=uint32_t(s.seed+d);break;case 6:s.harmony=std::clamp<int>(int(s.harmony)+d,0,7);break;}}
 generate(false);
}
void BazillComposer::play(){armed=false;if(running){stopNotes();running=false;redraw();return;}if(!ready||!validStage()||fingerprint()!=sourceHash||!sequencer.isSetInternalClock()){std::snprintf(notice,sizeof notice,"Generate a ready preview. Audition uses the internal project clock.");redraw();return;}sequencer.stop();sequencer.recEnable(false);stopNotes();running=true;playingStep=0;nextStep=clockUs();redraw();}
void BazillComposer::update(){if(!active)return;
 // Workspace autosave runs every ten seconds and does not replace the project.
 // A copy/import/load may share a status, so allow only the exact autosave FSM.
 const bool autosave=newFileManager.getStatus()==fmSavingProjectToWorkspace&&newFileManager.getCurrentOperation()==fmSaveWorkspaceProject;
 if(display.isHelpModal()||(newFileManager.getStatus()!=fmIdle&&!autosave)){stopNotes();running=armed=false;if(newFileManager.getStatus()!=fmIdle)ready=false;return;}if(!running||!data)return;
 const uint32_t now=clockUs();for(unsigned t=0;t<8;++t)if(sounding[t]>=0&&int32_t(now-offAt[t])>=0){sequencer.handleNoteOff(Sequencer::GRID_OUTSIDE_PATTERN,sounding[t],0,sourceBase+t);sounding[t]=-1;}
 if(int32_t(now-nextStep)<0)return;
 const auto duration=previewStepUs(playingStep);for(unsigned t=0;t<8;++t){if(!data->lanes[t].included||!validSound(t))continue;const auto&c=data->stage.cells[t][playingStep];if(c.note<0||mix(data->settings.seed+t*131+playingStep*17)%100>=data->settings.chance)continue;
  if(sounding[t]>=0)sequencer.handleNoteOff(Sequencer::GRID_OUTSIDE_PATTERN,sounding[t],0,sourceBase+t);
  const auto old=mtProject.values.lastUsedInstrument;
  mtProject.values.lastUsedInstrument=data->lanes[t].sound;
  sequencer.handleNoteOn(Sequencer::GRID_OUTSIDE_PATTERN,c.note,(c.velocity*127+50)/100,sourceBase+t);
  mtProject.values.lastUsedInstrument=old;sounding[t]=c.note;offAt[t]=now+(c.gate?uint32_t(uint64_t(duration)*c.gate/100):duration*16);
 }
 playingStep=(playingStep+1)%data->settings.length;nextStep+=duration;if(int32_t(now-nextStep)>=0)nextStep=now+duration;redraw();
}
const char* BazillComposer::help(uint8_t k)const{static const char*tips[]={
 "Up/Down selects Track 1-8. Middle toggles inclusion. +/- sets amount. Shift+Middle locks its staged notes. Shift+TRACKS sets Kick/Snare/Hat/Bass using S1/S3; no patch is loaded.",
 "STYLE +/- chooses twelve original genre rules and a recommended BPM range. Tempo, sounds and synth voice counts stay unchanged. Repeated roles are allowed.",
 "ROLE +/- chooses Bass, Lead, Harp, Pad, Piano, Synth, Arp or five drums. Every track owns its own independent phrase, including three bass tracks.",
 "SOUND +/- chooses an existing melodic synth or loaded unsliced sample. A drum synth is available for drum roles. No patch or routing changes. Shared synth parts share polyphony.",
 "Tap TONE to cycle exact 1-128 steps, key, native scale, chance, variation, seed and harmony; +/- edits. Length becomes the native pattern length for all audio tracks only after WRITE. No rounding.",
 "GENERATE rerolls unlocked included tracks only. Locks retain notes on reroll. Editing global musical settings unlocks tracks. Shift+GENERATE mutates pitches/accents while keeping rhythm and locked lanes.",
 "WRITE twice replaces notes/instrument/volume/FX in included tracks, rows 1 to chosen length. All eight audio-track lengths change together, as native playback requires. Other track notes and rows beyond length stay. One Undo restores the complete pattern.",
 "BACK or Menu discards staging and stops preview notes. Play auditions on the internal project clock. Preview chance is repeatable; native Chance uses the sequencer. No project mutation until WRITE."};return tips[k<8?k:7];}
void BazillComposer::draw(){if(!data)return;API_SAVE_CONTEXT();rect(0,30,800,394,0x080D13);bazill_surface::mascot(752,42,8,0xD9ACED,200);
 const auto&s=data->settings;const auto&sty=styles[s.style];char b[112];text(16,42,"COMPOSER / ROLE-BASED FILL",0x6BE6C2);
 std::snprintf(b,sizeof b,"%s | %u-%u BPM recommended | seed %lu",sty.name,sty.low,sty.high,static_cast<unsigned long>(s.seed));text(16,67,b);
 std::snprintf(b,sizeof b,"%u steps | %s %s | chance %u%% | var %u | %s",s.length,allNotes[s.key],scaleNames[scaleIndex],s.chance,s.variation,harmonyNames[s.harmony]);text(16,91,b,0xCFB5F3);
 text(16,120,"USE  TRACK",0x91A8B8);text(172,120,"ROLE",0x91A8B8);text(368,120,"SOUND",0x91A8B8);text(490,120,"AMOUNT",0x91A8B8);text(650,120,"LOCK",0x91A8B8);
 for(unsigned t=0;t<8;++t){const auto&l=data->lanes[t];const int y=146+t*24;if(t==lane)rect(12,y-2,776,23,0x233748);
  std::snprintf(b,sizeof b,"%s    %u",l.included?"[x]":"[ ]",t+1);text(18,y,b,l.included?0x6BE6C2:0x91A8B8);text(172,y,roles[l.role]);
  if(l.sound<48)std::snprintf(b,sizeof b,"%02u",l.sound+1);else std::snprintf(b,sizeof b,"S%u",l.sound-63);text(368,y,b,validSound(t)?0xBED0DB:0xFF888C);
  std::snprintf(b,sizeof b,"%u%%",l.amount);text(490,y,b);text(650,y,l.locked?"LOCK":"-",0xD9ACED);
 }
 static const char*fields[]={"AMOUNT","STYLE","ROLE","SOUND","TONE"};static const char*tones[]={"STEPS","KEY","SCALE","CHANCE","VARIATION","SEED","HARMONY"};
 std::snprintf(b,sizeof b,"EDIT %s%s%s | %s | Play: audition",fields[param],param==4?" / ":"",param==4?tones[tone]:"",running?"PLAYING":ready?"STAGED":"CHECK SOUND");text(16,344,b,0xFFD38F);
 // One selected lane, binned into 32 columns for a bounded display list.
 for(unsigned bin=0;bin<32;++bin){bool hit=false;for(unsigned n=bin*s.length/32;n<(bin+1)*s.length/32;++n)hit|=data->stage.cells[lane][n].note>=0;rect(16+bin*24,371,21,hit?12:3,hit?0x6BE6C2:0x344250);}
 if(running)rect(16+unsigned(playingStep)*768/s.length,367,2,19,0xFFD38F);
 unsigned cut=std::min<size_t>(96,std::strlen(notice));if(notice[cut])while(cut&&notice[cut]!=' ')--cut;
 char first[97];std::memcpy(first,notice,cut);first[cut]=0;text(16,389,first,armed?0xFF888C:0xBED0DB);
 if(notice[cut])text(16,405,notice+cut+1,armed?0xFF888C:0xBED0DB);
 API_RESTORE_CONTEXT();
}
#endif
