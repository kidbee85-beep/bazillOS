#pragma once
#include <cstdint>
#ifdef TRACKER_MINI
void bazillBindPatternQuickActions();
void bazillRefreshPatternQuickActions();
bool bazillPatternQuickEncoder(int16_t delta);
#endif

bool bazillPatternFillShape(float out[4]);
