// SPDX-License-Identifier: MIT
#pragma once
#ifdef TRACKER_MINI
#include "core/modulesBase.h"
#include "BazillTryAlloc.h"
#include "breakline/pattern_composer.hpp"
class BazillComposer:public ModuleBase {
public:
 void initDisplayControls()override;void destroyDisplayControls()override{}
 void start(uint32_t=0)override;void stop()override;void update()override;void hideControlsUnderMiniMenu()override;
 bool isActive()const{return active;}void action(uint8_t,uint8_t);void change(int16_t);void move(int,int);void middle();void play();void draw();
 void cancelConfirmation(){armed=false;}const char* help(uint8_t)const;
private:
 struct Session{bazill_composer::Settings settings;bazill_composer::Lane lanes[8];bazill_composer::Stage stage;};
 void bind();void labels();void redraw();void generate(bool);void apply();void stopNotes();void back();
 bool validSound(unsigned)const;bool validStage()const;uint32_t fingerprint()const;unsigned count()const;
 bazill_alloc::Ptr<Session> data;hControl panel=-1;bool active=false,ready=false,armed=false,running=false;
 uint8_t lane=0,param=0,tone=0,scaleIndex=1,playingStep=0;uint32_t sourceHash=0,nextStep=0,offAt[8]{};int8_t sounding[8]={-1,-1,-1,-1,-1,-1,-1,-1};
 char notice[112]{},writeLabel[24]{};
};
extern BazillComposer bazillComposer;
#endif
