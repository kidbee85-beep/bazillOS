// SPDX-License-Identifier: MIT
#include "config.h"
#ifdef TRACKER_MINI
#include "BazillPatternQuick.h"
#include "patternEditor.h"
#include "core/interface.h"
#include "instrumentEditor/instrumentEditor.h"
#include "sampleEditor/sampleEditor.h"
#include "performanceMode/performanceMode.h"
#include "masterParams/masterParams.h"
#include "songEditor/songEditor.h"
#include "fileManager.h"
#include "AudioStream.h"
#include "Synth.h"
#include "breakline/global_swing.hpp"
#include <cmath>
#include <cstdio>
namespace {
bool swingMode=false;char timingValue[24]{};
bool open(ModuleBase* target,uint32_t options){if(newFileManager.getStatus()!=fmIdle)return false;newFileManager.saveWorkspacePatternNow(mtProject.values.actualPattern);mtInterface.deactivateModule(&patternEditor);mtInterface.activateModule(target,options);return true;}
void sound(){
 if(newFileManager.getStatus()!=fmIdle)return;
 const auto* p=sequencer.getActualPattern();const unsigned t=patternEditor.trackerPattern.actualTrack;const unsigned r=patternEditor.trackerPattern.actualStep;
 if(p&&t<kAllTracks&&r<=p->track[t].length){const auto&s=p->track[t].step[r];if(s.note>=0&&unsigned(s.instrument)<kTotalInstrumentsCount)mtProject.values.lastUsedInstrument=s.instrument;}
 const auto i=mtProject.values.lastUsedInstrument;
 if(unsigned(i)>=kTotalInstrumentsCount){mtPopups.show(0,"Select a valid instrument before editing its sound.");return;}
 if(isSampleInstrument(i)){if(!mtProject.instrument[i].isActive){mtPopups.show(0,"Load a sample before editing its sound.");return;}open(&sampleEditor,0);}
 else{if(open(&instrumentEditor,1)&&isSynthInstrument(i))instrumentEditor.editCurrentSynthShortcut();}
}
void punch(){open(&performanceMode,100);}
void effects(){open(&masterParams,4<<8);}
void timing(){auto&p=patternEditor;if(p.selectedPlace==6)swingMode=!swingMode;else swingMode=p.buttons->isButtonPressed(interfaceButtonShift);p.selectedPlace=6;p.unfocusPattern();p.activateLabelsBorder();bazillRefreshPatternQuickActions();}
}
void bazillBindPatternQuickActions(){auto*ip=patternEditor.ip;ip->setButtonObj(interfaceButton2,buttonPress,sound);ip->setButtonObj(interfaceButton4,buttonPress,punch);ip->setButtonObj(interfaceButton5,buttonPress,effects);ip->setButtonObj(interfaceButton6,buttonPress,timing);swingMode=false;}
void bazillRefreshPatternQuickActions(){auto&p=patternEditor;auto view=p.label[3];display.setControlText(view,"View 4/8");display.setControlText2(view,p.compactOverview?"8 compact":"4 detailed");display.setControlData(view,nullptr);display.setControlColors(view,display.getTheme().activeButtonLabelsColors);display.refreshControl(view);const char* names[]={"Edit Sound","Punch Deck","Master FX",swingMode?"Swing":"Tempo"};const unsigned ids[]={2,4,5,6};
 if(!sequencer.isSetInternalClock())std::snprintf(timingValue,sizeof timingValue,"EXT CLOCK");
 else if(swingMode)std::snprintf(timingValue,sizeof timingValue,"%u%%",unsigned(bazill_swing::read(mtProject.values.midiInstrument[0].reserved)));
 else std::snprintf(timingValue,sizeof timingValue,"%.1f BPM",double(mtProject.values.globalTempo));
 for(unsigned n=0;n<4;++n){auto h=p.label[ids[n]];display.setControlText(h,names[n]);display.setControlText2(h,n==3?timingValue:n==0?"selected":n==1?"64 punches":"presets");display.setControlValue(h,1);display.setControlData(h,nullptr);display.setControlColors(h,display.getTheme().activeButtonLabelsColors);display.refreshControl(h);}
}
bool bazillPatternQuickEncoder(int16_t value){auto&p=patternEditor;if(p.actualActionButtonsPage!=2||p.selectedPlace!=6)return false;
 if(!value||newFileManager.getStatus()!=fmIdle||!sequencer.isSetInternalClock())return true;
 if(swingMode){auto*data=mtProject.values.midiInstrument[0].reserved;const int before=bazill_swing::read(data),after=std::clamp(before+value,25,75);if(after!=before){AudioNoInterrupts();bazill_swing::write(data,after);AudioInterrupts();newFileManager.setProjectStructChanged();}}
 else songEditor.changeGlobalTempo(value*(p.buttons->isButtonPressed(interfaceButtonShift)?.1f:1.f));
 bazillRefreshPatternQuickActions();return true;
}
bool bazillPatternFillShape(float out[4]){
 const unsigned i=mtProject.values.lastUsedInstrument;
 if(i<64||i>=67||mtProject.values.synthPart[i-64].synthType!=8||!instrumentEditor.getSynth())return false;
 const auto&patch=instrumentEditor.getSynth()->getPatch(i-64);
 for(unsigned n=0;n<4;++n){const auto value=patch.getParamValue(n+1);if(!value||!std::isfinite(*value))return false;out[n]=*value;}
 return true;
}
#endif
