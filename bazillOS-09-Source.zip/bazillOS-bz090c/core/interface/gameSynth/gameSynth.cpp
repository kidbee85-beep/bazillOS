#ifdef TRACKER_MINI
#include "gameSynth/gameSynth.h"
#include "patternEditor/patternEditor.h"
#include "core/interfaceMenuPopup.h"
#include "core/interfacePopups.h"
#include "core/songTimer.h"
#include "Platform.h"
#include "mtSequencer.h"
#include "mtAudioEngine.h"
#include "Synth.h"
#include "fileManager.h"
#include "FT812.h"
#include "BreaklineMotion.h"
#include "BazillSurface.h"
#include "BazillTryAlloc.h"
#include <algorithm>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cstdlib>
cGameSynth gameSynth;
namespace {
constexpr int16_t kNoteSource=903;
uint32_t stepInterval(){const float v=sequencer.getStepPeriodMs()*1000;return std::isfinite(v)?uint32_t(std::clamp(v,10000.f,1000000.f)):125000;}
void rectangle(int x,int y,int w,int h,uint32_t color){API_COLOR(color);API_BEGIN(RECTS);API_VERTEX2F(x,y);API_VERTEX2F(x+w,y+h);API_END();}
void noteName(uint8_t n,char* text,size_t capacity){static const char* const names[]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};std::snprintf(text,capacity,"%s%u",names[n%12],unsigned(n/12));}
// Bitmap glyphs keep the EVE display-list cost bounded on dense chord boards.
void gardenText(int x,int y,const char* text){
 API_SAVE_CONTEXT();API_BITMAP_HANDLE(fonts[0].handle);API_BEGIN(BITMAPS);
 for(unsigned i=0;text[i];++i){const auto c=static_cast<unsigned char>(text[i]);if(x<=511)API_VERTEX2II(x,y,fonts[0].handle,c);else{API_CELL(c);API_VERTEX2F(x,y);}x+=fonts[0].data[c];}
 API_END();API_RESTORE_CONTEXT();
}
class GardenControl : public cDisplayControl {
public:
 explicit GardenControl(strControlProperties* p):cDisplayControl(controlIdTemplate,1){style=p->style;posX=p->x;posY=p->y;width=p->w;height=p->h;owner=static_cast<cGameSynth*>(p->data);}
 void setStyle(uint32_t v)override{style=v;}void setText(const char*)override{}void setValue(int)override{}void setColors(const uint32_t*)override{}void setData(void*p)override{owner=static_cast<cGameSynth*>(p);}void update()override{if(owner)owner->drawArcade();}
private:cGameSynth*owner=nullptr;
};
// Screen-space coordinates: UP is always the previous row, DOWN the next.
void moveLeft(){gameSynth.move(-1,0);}void moveRight(){gameSynth.move(1,0);}
void moveUp(){gameSynth.move(0,-1);}void moveDown(){gameSynth.move(0,1);}
void plant(){gameSynth.plant();}void play(){gameSynth.togglePlay();}
void presetDelta(int16_t d){gameSynth.selectPreset(d);}
void action(uint8_t b,uint8_t s){if(s==buttonPress&&b<=interfaceButton7)gameSynth.action(b);}
void menu(uint8_t s){if(s==buttonPress)mtMenuPopup.showModulePopup(&gameSynth);else if(s==buttonRelease)mtMenuPopup.hideModulePopup(&gameSynth);}
void switchModule(uint8_t b){gameSynth.eventFunct(eventSwitchModule,&gameSynth,&b,nullptr);}
}
void cGameSynth::initDisplayControls(){
 strControlProperties p;p.x=0;p.y=30;p.w=800;p.h=390;p.data=this;p.style=controlStyleShow;boardControl=display.createControl<GardenControl>(&p);
 static const char* const text[]={"WRITE","PRESET","SCALE","SOUND","GAME","AUTO","ROOT -","ROOT +"};
 for(uint8_t i=0;i<8;++i){p={};p.text=text[i];p.x=i*100+50;p.y=424;p.w=96;p.h=55;p.colors=display.getTheme().activeLabelsColors;p.style=controlStyleShow|controlStyleCenterX|controlStyleCenterY|controlStyleFont3;labels[i]=display.createControl<cLabel>(&p);}
}
void cGameSynth::bindInputs(){
 ip->clearButtonsRange(interfaceButton0,interfaceButton32);ip->clearAllPots();
 ip->setButtonObj(interfaceButtonLeft,buttonPress,moveLeft);ip->setButtonObj(interfaceButtonRight,buttonPress,moveRight);ip->setButtonObj(interfaceButtonUp,buttonPress,moveUp);ip->setButtonObj(interfaceButtonDown,buttonPress,moveDown);
 ip->setButtonObj(interfaceButtonMiniMiddle,buttonPress,::plant);ip->setButtonObj(interfaceButtonPlay,buttonPress,play);
 for(uint8_t i=0;i<8;++i)ip->setButtonObj(i,::action);
 ip->setPotObj(interfacePot0,presetDelta);
 for(uint8_t i=interfaceButtonParams;i<=interfaceButtonSong;++i)ip->setButtonObj(i,buttonPress,switchModule);
 ip->setButtonObj(interfaceButtonPattern,buttonPress,switchModule);ip->setButtonObj(interfaceButtonGame,buttonPress,switchModule);ip->setButtonObj(interfaceButtonMiniMenu,menu);
}
bool cGameSynth::validVoice(uint8_t v)const{
 if(v>=64&&v<67){const auto& s=mtProject.values.synthPart[v-64];return synth&&s.voiceCount>0&&s.synthType!=4;}
 if(v>=48)return false;
 const auto& i=mtProject.instrument[v];return i.isActive&&i.sample.type==mtSampleTypeWaveFile&&i.sample.length>0&&i.playMode!=playModeBeatSlice&&i.playMode!=playModeSlice;
}
void cGameSynth::chooseVoice(bool next){
 releaseNotes();
 if(!next){if(validVoice(voice))return;
  // On first entry prefer a melodic synth over a currently selected drum sample.
  // An explicitly chosen game sound remains selected while it is still usable.
  for(unsigned v=64;v<67;++v)if(validVoice(v)){voice=v;return;}
  voice=mtProject.values.lastUsedInstrument;if(validVoice(voice))return;
  for(unsigned v=64;v<67;++v)if(validVoice(v)){voice=v;return;}
 }
 const unsigned start=next&&voice<67?voice+1:0;
 for(unsigned n=0;n<67;++n){const auto v=uint8_t((start+n)%67);if(validVoice(v)){voice=v;return;}}
 voice=255;
}
void cGameSynth::start(uint32_t options){
 resetBreaklineActionHelp();releaseNotes();sequencer.stop();sequencer.recEnable(false);
 if(options>=100&&options<102)arcadeMode=options-100;
 moduleRefresh=1;chooseVoice();active=true;running=false;cancelConfirmation();songTimer.hide();titleBar->show();titleBar->setTitle("ARCADE SYNTH");bindInputs();display.setControlShow(boardControl);for(auto h:labels)display.setControlShow(h);redraw();
}
void cGameSynth::stop(){moduleRefresh=0;resetBreaklineActionHelp();releaseNotes();active=false;running=false;captureArmed=false;display.setControlHide(boardControl);for(auto h:labels)display.setControlHide(h);songTimer.show();}
void cGameSynth::hideControlsUnderMiniMenu(){moduleRefresh=0;resetBreaklineActionHelp();releaseNotes();running=false;cancelConfirmation();display.setControlHide(boardControl);for(auto h:labels)display.setControlHide(h);}
void cGameSynth::releaseNotes(){for(unsigned l=0;l<4;++l)if(sounding[l]){sequencer.handleNoteOff(Sequencer::GRID_OUTSIDE_PATTERN,previewNotes[l],0,kNoteSource+l);sounding[l]=false;}}
void cGameSynth::preview(unsigned lane,uint8_t note,uint8_t velocity){
 if(lane>=4||!validVoice(voice))return;
 if(sounding[lane])sequencer.handleNoteOff(Sequencer::GRID_OUTSIDE_PATTERN,previewNotes[lane],0,kNoteSource+lane);
 const auto old=mtProject.values.lastUsedInstrument;mtProject.values.lastUsedInstrument=voice;
 sequencer.handleNoteOn(Sequencer::GRID_OUTSIDE_PATTERN,note,velocity,kNoteSource+lane);mtProject.values.lastUsedInstrument=old;
 previewNotes[lane]=note;sounding[lane]=true;noteEnds[lane]=platform->getTimer()->micros()+std::max<uint32_t>(5000,stepInterval()*games[arcadeMode].lengthPercent()/100);
}
void cGameSynth::playStep(){const auto e=games[arcadeMode].tick();loopStep=(games[arcadeMode].column()+15)%16;if(e.trigger)preview(0,e.note,e.velocity);}
void cGameSynth::update(){
 if(!active)return;const uint32_t now=platform->getTimer()->micros();
 for(unsigned l=0;l<4;++l)if(sounding[l]&&int32_t(now-noteEnds[l])>=0){sequencer.handleNoteOff(Sequencer::GRID_OUTSIDE_PATTERN,previewNotes[l],0,kNoteSource+l);sounding[l]=false;}
 if(mtMenuPopup.isPopupVisible()||display.isHelpModal()||newFileManager.getStatus()!=fmIdle){releaseNotes();running=false;cancelConfirmation();return;}
 if(!validVoice(voice)){releaseNotes();running=false;return;}
 if(running&&int32_t(now-nextTick)>=0){playStep();const auto interval=stepInterval();nextTick+=interval;if(int32_t(now-nextTick)>=0)nextTick=now+interval;redraw();}
}
void cGameSynth::cancelConfirmationForHelp(){cancelConfirmation();redraw();}
void cGameSynth::cancelConfirmation(){captureArmed=false;captureFingerprint=0;presetMode=false;
 std::snprintf(noticeText,sizeof noticeText,"%s",voice==255?"No melodic sound. Enable a synth or load a sample, then return.":"PLAY: run/stop. Arrows: paddle. Middle: serve. AUTO helps. WRITE keeps the last full bar.");
}
int cGameSynth::dreamsPart()const{
 if(!synth)return -1;
 if(voice>=64&&voice<67){const auto&s=mtProject.values.synthPart[voice-64];if(s.synthType==7&&s.voiceCount>0)return voice-64;}
 for(int i=2;i>=0;--i){const auto&s=mtProject.values.synthPart[i];if(s.synthType==7&&s.voiceCount>0)return i;}
 return -1;
}
void cGameSynth::selectPreset(int16_t d){
 releaseNotes();running=false;cancelConfirmation();presetMode=true;
 auto&i=presetIndex[arcadeMode];i=(int(i)+(d>0?1:d<0?-1:0)+bazill_arcade_presets::count)%bazill_arcade_presets::count;
 const int p=dreamsPart();if(p<0)std::snprintf(noticeText,sizeof noticeText,"Enable DREAMS first: Menu > DREAMS Synth. Arrows or PLAY leave this browser.");
 else std::snprintf(noticeText,sizeof noticeText,"LOAD replaces Synth %d sound and game settings. +/- chooses. Other slots keep their sounds.",p+1);
 redraw();
}
void cGameSynth::loadPreset(){
 const int part=dreamsPart();if(part<0){std::snprintf(noticeText,sizeof noticeText,"Enable DREAMS first: Menu > DREAMS Synth. No sound or project settings changed.");redraw();return;}
 if(newFileManager.getStatus()!=fmIdle||mtMenuPopup.isPopupVisible()||display.isHelpModal())return;
 void* reserve=_malloc_r(nullptr,4096);if(!reserve){std::snprintf(noticeText,sizeof noticeText,"Not enough RAM to load this sound. Current sound and game settings retained.");redraw();return;}std::free(reserve);
 releaseNotes();running=false;const auto&p=bazill_arcade_presets::bank[presetIndex[arcadeMode]];
 if(!synth->loadPatch(part,p.name)){std::snprintf(noticeText,sizeof noticeText,"Preset could not load. Current game settings retained.");redraw();return;}
 auto&s=mtProject.values.synthPart[part];std::snprintf(s.patchName,sizeof s.patchName,"%s",p.name);
 synth->initSynthPartMacrosValues(part,s);engine.refreshSynthInstrumentParams(s,part);newFileManager.setProjectStructChanged();
 voice=64+part;games[arcadeMode].applyPreset(presetIndex[arcadeMode]);cancelConfirmation();
 std::snprintf(noticeText,sizeof noticeText,"%s loaded in S%d. PLAY starts. Shift+PRESET changes gate. Save project to keep sound.",p.name+8,part+1);redraw();
}
void cGameSynth::move(int dx,int dy){cancelConfirmation();auto&g=games[arcadeMode];g.move(dx,dy);if(!running)preview(0,g.pitch(g.y()),100);redraw();}
void cGameSynth::plant(){cancelConfirmation();games[arcadeMode].serve();if(!running)togglePlay();else redraw();}
void cGameSynth::togglePlay(){
 cancelConfirmation();if(!validVoice(voice)){redraw();return;}running=!running;releaseNotes();loopStep=0;
 if(running){games[arcadeMode].restartBar();playStep();nextTick=platform->getTimer()->micros()+stepInterval();}redraw();
}
void cGameSynth::action(uint8_t i){
 auto&g=games[arcadeMode];
 if(i==1){if(buttons->isButtonPressed(interfaceButtonShift)){cancelConfirmation();g.nextGate();redraw();}
  else if(presetMode)loadPreset();else selectPreset(0);return;}
 if(i==0&&presetMode){cancelConfirmation();redraw();return;}
 if(i==0){running=false;releaseNotes();if(!validVoice(voice)||!captureHandler){cancelConfirmation();redraw();return;}
  if(!g.ready()){cancelConfirmation();std::snprintf(noticeText,sizeof noticeText,"Play for one full bar (16 steps) before WRITE. Your project is unchanged.");redraw();return;}
  if(!captureArmed){captureFingerprint=captureHandler(g.captured(),1,voice,false,0);captureArmed=captureFingerprint!=0;
   const unsigned t=patternEditor.trackerPattern.selectStartTrack+1,s=patternEditor.trackerPattern.selectStartStep+1;
   if(captureArmed)std::snprintf(noticeText,sizeof noticeText,"WRITE again: replace T%u, rows %u-%u with the last full bar. Undo restores.",t,s,s+15);
   else std::snprintf(noticeText,sizeof noticeText,"Cannot write here. Select a fitting track and 16 rows in Pattern.");
  }else{const bool ok=captureHandler(g.captured(),1,voice,true,captureFingerprint)!=0;captureArmed=false;std::snprintf(noticeText,sizeof noticeText,ok?"Last full bar written to Pattern. Native Undo restores the previous steps.":"Destination changed or does not fit. Nothing written. Select a new destination.");}
 }else{
  cancelConfirmation();if(i==2)g.nextScale();else if(i==3){chooseVoice(true);cancelConfirmation();}else if(i==4){cycleGame();return;}else if(i==5)g.toggleAuto();else if(i==6)g.setRoot(g.root()-1);else if(i==7)g.setRoot(g.root()+1);
 }
 redraw();
}
void cGameSynth::cycleGame(){selectGame((arcadeMode+1)%2);}
void cGameSynth::selectGame(uint8_t which){if(which>=2)return;releaseNotes();running=false;arcadeMode=which;loopStep=0;chooseVoice();cancelConfirmation();if(active)redraw();}
void cGameSynth::drawArcade(){
 const auto&g=games[arcadeMode];API_SAVE_CONTEXT();rectangle(0,30,800,390,0x080D13);bazill_surface::texture(0,30,800,390,0x8797BB,28);
 API_COLOR(0x63F6C5);API_CMD_TEXT(20,43,fonts[2].handle,0,g.name());
 char line[96],root[8],sound[20];noteName(g.root(),root,sizeof root);
 if(voice>=64&&voice<67)std::snprintf(sound,sizeof sound,"S%u SYNTH",voice-63);else if(voice<48)std::snprintf(sound,sizeof sound,"SAMPLE %02u",voice+1);else std::snprintf(sound,sizeof sound,"NO SOUND");
 if(presetMode){const auto&p=bazill_arcade_presets::bank[presetIndex[arcadeMode]];
  std::snprintf(line,sizeof line,"PRESET %02u/%u / %s / %s",presetIndex[arcadeMode]+1,bazill_arcade_presets::count,p.name+8,p.category);API_COLOR(0xD5E0EC);gardenText(20,78,line);
  const int part=dreamsPart();if(part>=0)std::snprintf(line,sizeof line,"TARGET S%d DREAMS / +/- CHOOSE / LOAD TO APPLY",part+1);else std::snprintf(line,sizeof line,"DREAMS REQUIRED / MENU > DREAMS SYNTH / PLAY CANCELS");API_COLOR(0xEDBC75);gardenText(20,102,line);
 }else{
 if(voice>=64&&voice<67){char patch[32];std::snprintf(patch,sizeof patch,"%.31s",mtProject.values.synthPart[voice-64].patchName);API_COLOR(0xAABCCC);gardenText(310,45,patch);}
 std::snprintf(line,sizeof line,"%s / %s %s / 1/16 PROJECT CLOCK / %s",sound,root,g.scaleName(),running?"PLAYING":"PRESS PLAY");API_COLOR(0xD5E0EC);gardenText(20,78,line);
 std::snprintf(line,sizeof line,"%s / AUTO %s / SCORE %u / BAR %u / %s",g.gateName(),g.automatic()?"ON":"OFF",g.score(),g.bars(),g.ready()?"WRITE READY":"PLAY A FULL BAR");API_COLOR(0xAABCCC);gardenText(20,102,line);
 }
 const int left=48,top=136,cw=44,rh=27;
 rectangle(left-4,top-4,712,224,0x111E30);
 API_COLOR(0x2C4155);API_LINE_WIDTH(8);API_BEGIN(LINES);for(int x=0;x<=16;++x){API_VERTEX2F(left+x*cw,top);API_VERTEX2F(left+x*cw,top+8*rh);}for(int y=0;y<=8;++y){API_VERTEX2F(left,top+y*rh);API_VERTEX2F(left+16*cw,top+y*rh);}API_END();
 if(arcadeMode==0){rectangle(left+g.paddleX()*cw+6,top+(g.paddleY()-1)*rh+3,8,rh*3-6,0x6BE6C2);rectangle(left+16*cw-4,top,4,8*rh,0xD19AFF);}
 else{for(unsigned y=0;y<3;++y)for(unsigned x=0;x<16;++x)if(g.brick(x,y)){rectangle(left+x*cw+4,top+y*rh+5,cw-8,rh-10,y==0?0xC887B5:y==1?0xC89756:0x4DAA94);}rectangle(left+(g.paddleX()-1)*cw+3,top+g.paddleY()*rh+18,cw*3-6,7,0x6BE6C2);}
 bazill_surface::mascot(left+g.x()*cw+10,top+g.y()*rh+1,running?loopStep%12:0,0xEDBC75,255);
 for(unsigned i=0;i<16;++i){const auto&step=g.step(i);rectangle(left+i*cw+3,365,cw-6,9,step.active?0x5EC8AE:0x253548);}
 if(running)rectangle(left+loopStep*cw+3,377,cw-6,3,0xEDBC75);
 API_COLOR(0xD5E0EC);gardenText(16,393,noticeText);API_RESTORE_CONTEXT();
}
void cGameSynth::redraw(){display.setControlText(labels[0],captureArmed?"CONFIRM":"WRITE");display.setControlText(labels[1],presetMode?"LOAD":"PRESET");for(unsigned i=0;i<8;++i){display.setControlColors(labels[i],i==1&&presetMode?display.getTheme().highlightedButtonLabelsColors:display.getTheme().activeLabelsColors);display.refreshControl(labels[i]);}display.refreshControl(boardControl);display.synchronizeRefresh();}
#endif
