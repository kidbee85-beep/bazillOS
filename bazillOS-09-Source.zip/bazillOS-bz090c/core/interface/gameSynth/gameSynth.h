#pragma once
#include "core/modulesBase.h"
#include "breakline/arcade_synth.hpp"
class cGameSynth : public ModuleBase {
public:
    using CaptureHandler=uint32_t(*)(const breakline::GameStep*,uint8_t,uint8_t,bool,uint32_t);
    void update() override;
    void start(uint32_t options) override;
    void stop() override;
    void initDisplayControls() override;
    void destroyDisplayControls() override {}
    void hideControlsUnderMiniMenu() override;
    void setCaptureHandler(CaptureHandler h){captureHandler=h;}
    bool isRunning() const{return running;}
    uint8_t arcadeKind()const{return arcadeMode;}
    uint8_t getCurrentModeIdx() override{return arcadeMode;}
    void drawArcade();void cycleGame();void selectGame(uint8_t which);
    void move(int dx,int dy);void plant();void togglePlay();void action(uint8_t index);
    void cancelConfirmationForHelp();
    void selectPreset(int16_t direction);void loadPreset();int dreamsPart()const;
private:
    void preview(unsigned lane,uint8_t note,uint8_t velocity);
    void releaseNotes();void playStep();void redraw();void bindInputs();void cancelConfirmation();
    bool validVoice(uint8_t candidate)const;void chooseVoice(bool next=false);
    bazill_arcade_synth::Instrument games[2]={bazill_arcade_synth::Instrument(bazill_arcade_synth::Instrument::pong),bazill_arcade_synth::Instrument(bazill_arcade_synth::Instrument::breaker)};
    uint8_t arcadeMode=0,loopStep=0,voice=255;
    CaptureHandler captureHandler=nullptr;
    hControl boardControl=-1,labels[8]{};
    char noticeText[96]="Play runs at project tempo. Arrows move the paddle. AUTO helps.";
    uint32_t nextTick=0,noteEnds[4]{},captureFingerprint=0;
    uint8_t previewNotes[4]{};bool sounding[4]{};
    bool active=false,running=false,captureArmed=false;
    bool presetMode=false;uint8_t presetIndex[2]={0,16};
};
extern cGameSynth gameSynth;
