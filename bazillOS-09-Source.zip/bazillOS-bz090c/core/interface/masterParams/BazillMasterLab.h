#pragma once
#ifdef TRACKER_MINI
#include "core/modulesBase.h"
#include "BazillTryAlloc.h"
#include "breakline/master_lab.hpp"
#include "breakline/audio_scope.hpp"
class BazillMasterLab:public ModuleBase {
public:
 void initDisplayControls()override;void destroyDisplayControls()override{}
 void start(uint32_t=0)override;void stop()override;void update()override;void hideControlsUnderMiniMenu()override;
 bool isActive()const{return active;}void action(uint8_t);void change(int16_t);void move(int,int);void compare();void play();void draw();
 uint8_t requestedGroup=255;
private:
 void audio(bazill_master::Settings);void redraw();void labels();void bind();
 bazill_master::Settings original,draft,applied;bazill_alloc::Ptr<bazill_scope::Analyzer> analyzer;
 hControl panel=-1;bool active=false,originalAudition=false,appliedKnown=false,chosen[3]{};uint8_t group=0,band=0,presets[3]{};
 uint32_t nextFrame=0;float meter[32]{};char notice[96]="";
};
extern BazillMasterLab bazillMasterLab;
#endif
