// SPDX-License-Identifier: MIT
#include "config.h"
#ifdef TRACKER_MINI
#include "BazillMasterLab.h"
#include "masterParams.h"
#include "core/interfaceMenuPopup.h"
#include "fileManager.h"
#include "mtAudioEngine.h"
#include "mtMasterEnhancer.h"
#include "Platform.h"
#include "AudioStream.h"
#include "FT812.h"
#include "BazillSurface.h"
#include <cmath>
#include <cstdio>
BazillMasterLab bazillMasterLab;
namespace{
class MasterLabControl:public cDisplayControl{public:explicit MasterLabControl(strControlProperties*p):cDisplayControl(controlIdTemplate,1){style=p->style;}void setStyle(uint32_t v)override{style=v;}void setText(const char*)override{}void setValue(int)override{}void setColors(const uint32_t*)override{}void setData(void*)override{}void update()override{bazillMasterLab.draw();}};
void action(uint8_t b,uint8_t s){if(s==buttonPress&&b<8)bazillMasterLab.action(b);}void delta(int16_t d){bazillMasterLab.change(d);}void left(){bazillMasterLab.move(-1,0);}void right(){bazillMasterLab.move(1,0);}void up(){bazillMasterLab.move(0,1);}void down(){bazillMasterLab.move(0,-1);}void middle(){bazillMasterLab.compare();}void play(){bazillMasterLab.play();}
void menu(uint8_t s){if(s==buttonPress)mtMenuPopup.showModulePopup(&masterParams);else if(s==buttonRelease)mtMenuPopup.hideModulePopup(&masterParams);}void module(uint8_t b){masterParams.eventFunct(eventSwitchModule,&masterParams,&b,nullptr);}
void rect(int x,int y,int w,int h,uint32_t c){API_COLOR(c);API_BEGIN(RECTS);API_VERTEX2F(x,y);API_VERTEX2F(x+w,y+h);API_END();}
void text(int x,int y,const char*s,uint32_t c){API_SAVE_CONTEXT();API_COLOR(c);API_BITMAP_HANDLE(fonts[0].handle);API_BEGIN(BITMAPS);for(unsigned i=0;s[i];++i){unsigned ch=uint8_t(s[i]);if(x<512)API_VERTEX2II(x,y,fonts[0].handle,ch);else{API_CELL(ch);API_VERTEX2F(x,y);}x+=fonts[0].data[ch];}API_END();API_RESTORE_CONTEXT();}
}
void BazillMasterLab::initDisplayControls(){strControlProperties p{};panel=display.createControl<MasterLabControl>(&p);}
void BazillMasterLab::audio(bazill_master::Settings s){
 bool eqChanged=!appliedKnown;for(unsigned i=0;i<5;++i)eqChanged|=s.eq[i]!=applied.eq[i];
 if(eqChanged)masterEnhancer.fiveBandsEq.change(s.eq);
 if(!appliedKnown||s.bass!=applied.bass)masterEnhancer.changeBassBoost(s.bass);
 if(!appliedKnown||s.space!=applied.space)masterEnhancer.changeStereoBoost(s.space);
 if(!appliedKnown||s.saturation!=applied.saturation)engine.setSaturationType(static_cast<SaturationType>(s.saturation));
 if(!appliedKnown||s.size!=applied.size)engine.setReverbSize(s.size);
 if(!appliedKnown||s.damp!=applied.damp)engine.setReverbDamp(s.damp);
 if(!appliedKnown||s.predelay!=applied.predelay)engine.setReverbPredelay(s.predelay);
 if(!appliedKnown||s.diffusion!=applied.diffusion)engine.setReverbDiffusion(s.diffusion);
 const bool paramsChanged=!appliedKnown||s.delayParams!=applied.delayParams;
 if(paramsChanged)engine.setDelayParams(s.delayParams);
 if((s.delayParams&64)&&(paramsChanged||s.delayTime!=applied.delayTime))engine.setDelayTime(s.delayTime);
 if(!appliedKnown||s.feedback!=applied.feedback)engine.setDelayFeedback(s.feedback);
 if(!appliedKnown||s.delayFilter!=applied.delayFilter)engine.setDelayFilterFrequency(s.delayFilter);
 applied=s;appliedKnown=true;
}
void BazillMasterLab::start(uint32_t){
 stop();active=true;masterParams.moduleRefresh=1;original=draft=applied=bazill_master::Settings::read(mtProject.values);appliedKnown=true;originalAudition=false;group=requestedGroup<6?requestedGroup:0;requestedGroup=255;
 for(auto&v:chosen)v=false;for(auto&v:meter)v=0;
 analyzer.reset(bazill_alloc::create<bazill_scope::Analyzer>());AudioNoInterrupts();bazill_scope::capture.resetStopped();bazill_scope::capture.enable(analyzer!=nullptr);AudioInterrupts();
 for(auto h:{masterParams.bgLabel,masterParams.frameControl,masterParams.delayPingpongEnableList,masterParams.delaySyncEnableList,masterParams.delaySyncRateList,masterParams.limiterSidechainList,masterParams.saturationList})display.setControlHide(h);
 for(auto h:masterParams.barControl)display.setControlHide(h);for(auto h:masterParams.blankSpaceCover)display.setControlHide(h);for(auto h:masterParams.trackNameLabel)display.setControlHide(h);for(auto h:masterParams.trackVolumeBar)display.setControlHide(h);
 titleBar->show(false);titleBar->setTitle("MASTER LAB");bind();labels();display.setControlShow(panel);std::snprintf(notice,sizeof notice,"Preview changes sound. APPLY keeps it. BACK restores. Middle: original/preview.");nextFrame=0;redraw();
}
void BazillMasterLab::stop(){if(!active)return;audio(bazill_master::Settings::read(mtProject.values));bazill_scope::capture.enable(false);analyzer.reset();active=false;display.setControlHide(panel);}
void BazillMasterLab::hideControlsUnderMiniMenu(){if(!active)return;audio(bazill_master::Settings::read(mtProject.values));bazill_scope::capture.enable(false);analyzer.reset();display.setControlHide(panel);}
void BazillMasterLab::bind(){ip->clearButtonsRange(interfaceButton0,interfaceButton32);ip->clearAllPots();for(unsigned i=0;i<8;++i)ip->setButtonObj(i,::action);ip->setPotObj(interfacePot0,delta);ip->setButtonObj(interfaceButtonLeft,buttonPress,left);ip->setButtonObj(interfaceButtonRight,buttonPress,right);ip->setButtonObj(interfaceButtonUp,buttonPress,up);ip->setButtonObj(interfaceButtonDown,buttonPress,down);ip->setButtonObj(interfaceButtonMiniMiddle,buttonPress,middle);ip->setButtonObj(interfaceButtonPlay,buttonPress,::play);ip->setButtonObj(interfaceButtonMiniMenu,::menu);for(unsigned i=interfaceButtonParams;i<=interfaceButtonSong;++i)ip->setButtonObj(i,buttonPress,module);ip->setButtonObj(interfaceButtonPattern,buttonPress,module);ip->setButtonObj(interfaceButtonGame,buttonPress,module);}
void BazillMasterLab::labels(){const char* names[]={"GENRE","REVERB","DELAY","BASS","WIDTH","EQ","APPLY","BACK"};for(unsigned i=0;i<8;++i){auto h=masterParams.label[i];display.setControlPosition(h,i*100+50,424);display.setControlSize(h,96,55);display.setControlStyle2(h,controlStyleShow|controlStyleCenterX|controlStyleCenterY|controlStyleFont3);display.setControlText(h,names[i]);display.setControlText2(h,"");display.setControlValue(h,0);display.setControlColors(h,i==group?display.getTheme().highlightedButtonLabelsColors:display.getTheme().activeLabelsColors);display.setControlShow(h);display.refreshControl(h);}}
void BazillMasterLab::redraw(){if(active)display.refreshControl(panel);}
void BazillMasterLab::change(int16_t delta){if(!delta)return;originalAudition=false;const int d=delta>0?1:-1;
 if(group<3){presets[group]=(int(presets[group])+d+16)%16;chosen[group]=true;if(group==0)draft.genre(presets[0]);else if(group==1)draft.reverb(presets[1]);else draft.delay(presets[2]);}
 else if(group==3)draft.bass=std::clamp(int(draft.bass)+delta,0,100);else if(group==4)draft.space=std::clamp(int(draft.space)+d,0,8);else{draft.eq[band]=std::clamp(draft.eq[band]+delta*.025f,-1.f,1.f);chosen[0]=false;}
 audio(draft);redraw();
}
void BazillMasterLab::move(int x,int y){if(x){if(group==5)band=(int(band)+x%5+5)%5;else group=(int(group)+x%6+6)%6;labels();redraw();}if(y)change(y);}
void BazillMasterLab::compare(){originalAudition=!originalAudition;audio(originalAudition?original:draft);redraw();}
void BazillMasterLab::play(){if(sequencer.isPlay())sequencer.stop();else sequencer.playPattern();}
void BazillMasterLab::action(uint8_t b){if(b<6){group=b;labels();redraw();return;}if(b==7){stop();masterParams.start(1<<8);return;}if(b==6){if(!bazill_master::Settings::read(mtProject.values).same(original)){original=draft=bazill_master::Settings::read(mtProject.values);originalAudition=false;for(auto&v:chosen)v=false;audio(original);std::snprintf(notice,sizeof notice,"Master settings changed outside this preview. Current settings restored; edit again.");redraw();return;}if(originalAudition){std::snprintf(notice,sizeof notice,"Middle returns to Preview. Then APPLY keeps the edited settings.");redraw();return;}draft.write(mtProject.values);newFileManager.setProjectStructChanged();original=draft;std::snprintf(notice,sizeof notice,"Applied to this project. Save the project to keep these settings.");redraw();}}
void BazillMasterLab::update(){if(!active)return;const bool blocked=mtMenuPopup.isPopupVisible()||display.isHelpModal()||newFileManager.getStatus()!=fmIdle;bazill_scope::capture.enable(!blocked&&analyzer!=nullptr);if(blocked)return;const auto now=platform->getTimer()->micros();if(int32_t(now-nextFrame)<0)return;nextFrame=now+80000;if(analyzer){const int f=bazill_scope::capture.acquire();if(f>=0){analyzer->analyze(bazill_scope::capture.channel(f,0),bazill_scope::capture.channel(f,1));bazill_scope::capture.release();for(unsigned i=0;i<32;++i)meter[i]=analyzer->result.level[i];redraw();}}}
void BazillMasterLab::draw(){
 API_SAVE_CONTEXT();rect(0,30,800,390,0x080D13);bazill_surface::texture(0,30,800,390,0x8797BB,28);text(20,45,"MASTER LAB / LIVE EQ + FINISHING PRESETS",0x6BE6C2);
 char line[96];const char*name=group==0?(chosen[0]?bazill_master::genres[presets[0]].name:"CURRENT MIX"):group==1?(chosen[1]?bazill_master::reverbs[presets[1]].name:"CURRENT REVERB"):group==2?(chosen[2]?bazill_master::delays[presets[2]].name:"CURRENT DELAY"):group==3?"BASS BOOST":group==4?"STEREO WIDTH":"FIVE BAND EQ";
 std::snprintf(line,sizeof line,"%s / %s / +/- EDIT / MIDDLE A/B",name,originalAudition?"ORIGINAL":"PREVIEW");text(20,73,line,0xD5E0EC);
 text(20,99,analyzer?"LIVE SPECTRUM: SOFTWARE MASTER BEFORE CODEC EQ / BASS / WIDTH":"SPECTRUM RAM UNAVAILABLE / EQ AND PRESETS REMAIN AVAILABLE",0x9BAFC6);
 const auto&s=originalAudition?original:draft;const int left=40,top=143,w=720,h=170,zero=top+h/2;
 rect(left,top,w,h,0x142033);API_COLOR(0x33485F);API_LINE_WIDTH(8);API_BEGIN(LINES);for(int y=0;y<5;++y){API_VERTEX2F(left,top+y*h/4);API_VERTEX2F(left+w,top+y*h/4);}API_END();
 for(unsigned i=0;i<32;++i)rect(left+i*w/32+2,top+h-int(meter[i]*h),w/32-4,std::max(1,int(meter[i]*h)),0x347A76);
 constexpr int xs[]={113,235,362,490,628};API_COLOR(0xEDBC75);API_LINE_WIDTH(32);API_BEGIN(LINE_STRIP);for(unsigned i=0;i<5;++i)API_VERTEX2F(left+xs[i],zero-int(s.eq[i]*65));API_END();
 const char*freq[]={"115","330","990","3k","9.9k"};for(unsigned i=0;i<5;++i){rect(left+xs[i]-4,zero-int(s.eq[i]*65)-4,8,8,group==5&&band==i?0xEAB0F7:0xEDBC75);text(left+xs[i]-14,top+h+6,freq[i],0xC3D1E3);}
 std::snprintf(line,sizeof line,"BASS %u / WIDTH %u / EQ %s Hz: %+.1f dB approx",s.bass,s.space,freq[band],s.eq[band]*12.f);text(20,345,line,0xD5E0EC);
 text(20,369,group==1||group==2?"REVERB / DELAY PRESETS USE THE CURRENT TRACK SENDS AND RETURN MIX.":"AMBER: EQ SETTINGS / TEAL: MEASURED SPECTRUM / PLAY: TRANSPORT",0xAABCCC);
 text(16,397,notice,0xD5E0EC);API_RESTORE_CONTEXT();
}
#endif
