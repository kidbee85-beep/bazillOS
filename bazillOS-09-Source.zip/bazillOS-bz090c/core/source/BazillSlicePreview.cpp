#include "BazillSlicePreview.h"
#ifdef TRACKER_MINI
#include "breakline/preview_range.hpp"
#include "mtAudioEngine.h"
#include "mtPadBoard.h"
#include "mtSequencer.h"
#include "fileManager.h"
#include "VoiceStreamManager.h"
#include "core/interface.h"
#include "Platform.h"
#include "AudioStream.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
extern uint8_t externalRamScratchBuff[];
BazillSlicePreview bazillSlicePreview;
namespace {constexpr int16_t source=915;constexpr uint32_t maximum=44100*4;
uint32_t now(){return mtInterface.getPlatform()->getTimer()->micros();}}
bool BazillSlicePreview::request(uint8_t index,const uint16_t* cuts,uint8_t count,uint8_t selected){
 stop();
 std::snprintf(text,sizeof text,"Preview unavailable: sample empty or storage busy.");
 if(index>=kSampleInstrumentsCount||newFileManager.getStatus()!=fmIdle||newFileManager.getCurrentOperation()!=fmNoOperation)return false;
 const auto& inst=mtProject.instrument[index];const auto& m=mtProject.sampleMemory[index];
 if(inst.sample.type!=mtSampleTypeWaveFile)return false;
 const auto r=bazill_preview::range(inst.sample.length,cuts,count,selected,maximum);
 if(!r.frames||(!m.isStreamed&&(!m.address[0]||(m.isStereo&&!m.address[1]))))return false;
 static_assert((maximum+2)*2*sizeof(int16_t)<=SHARED_SCRATCH_MEMORY_SIZE);
 sequencer.stop();sequencer.recEnable(false);sequencer.stopManualNotes();engine.getSdPlayer()->stop();
 instrument=index;start=r.start;frames=r.frames;copied=0;hash=m.sampleHash;length=inst.sample.length;channels=m.isStereo?2:1;streamed=m.isStreamed;
 address[0]=reinterpret_cast<uintptr_t>(m.address[0]);address[1]=reinterpret_cast<uintptr_t>(m.address[1]);loading=true;
 std::snprintf(text,sizeof text,r.truncated?"Staging slice %u: first 4 seconds; source and markers unchanged.":"Staging slice %u; source and markers unchanged.",unsigned(selected+1));return true;
}
void BazillSlicePreview::update(){
 if(!loading&&!playing)return;
 const auto& inst=mtProject.instrument[instrument];const auto& m=mtProject.sampleMemory[instrument];
 if(mtProject.values.lastUsedInstrument!=instrument||inst.sample.length!=length||m.sampleHash!=hash||
   reinterpret_cast<uintptr_t>(m.address[0])!=address[0]||reinterpret_cast<uintptr_t>(m.address[1])!=address[1]||
   (m.isStereo?2:1)!=channels||m.isStreamed!=streamed||newFileManager.getStatus()!=fmIdle||newFileManager.getCurrentOperation()!=fmNoOperation){stop();std::snprintf(text,sizeof text,"Preview canceled: sample changed or storage is busy.");return;}
 if(playing){if(static_cast<int32_t>(now()-ends)>=0)stop();return;}
 const uint32_t n=std::min<uint32_t>(256,frames-copied);
 auto* pcm=reinterpret_cast<int16_t*>(externalRamScratchBuff);
 for(unsigned ch=0;ch<channels;++ch){auto* dst=pcm+ch*(maximum+2)+copied;
  if(m.isStreamed){if(!voiceStreamManager.readInstrumentFramesBlocking(instrument,ch,start+copied,n,dst)){stop();std::snprintf(text,sizeof text,"Preview read failed; source and markers unchanged.");return;}}
  else std::memcpy(dst,m.address[ch]+start+copied,n*sizeof(int16_t));
  // Tiny preview-only boundary fades avoid abrupt test-tone clicks.
  for(unsigned i=0;i<n;++i){const auto at=copied+i;const unsigned fade=std::min<unsigned>(32,std::min(at,frames-1-at));dst[i]=static_cast<int16_t>(int32_t(dst[i])*fade/32);}
 }
 copied+=n;if(copied<frames)return;
 for(unsigned ch=0;ch<channels;++ch){pcm[ch*(maximum+2)+frames]=0;pcm[ch*(maximum+2)+frames+1]=0;}
 std::vector<int16_t*> data{pcm,channels==2?pcm+maximum+2:pcm};
 AudioNoInterrupts();mtPadBoard.startNoteWithoutInstrument(60,data,frames,DEFAULT_INSTRUMENT_VOLUME,source);AudioInterrupts();
 loading=false;playing=true;ends=now()+static_cast<uint32_t>(uint64_t(frames)*1000000/44100)+100000;
 std::snprintf(text,sizeof text,"Auditioning staged slice. Tap again to stop. No sample edits.");
}
void BazillSlicePreview::stop(){
 if(playing){AudioNoInterrupts();mtPadBoard.stopInstrument(source);
  engine.setLimiterAttack(mtProject.values.limiterAttack);engine.setLimiterRelease(mtProject.values.limiterRelease);
  engine.setLimiterThreshold(mtProject.values.limiterThreshold);engine.setLimiterSidechain(mtProject.values.limiterSidechain);AudioInterrupts();}
 loading=false;playing=false;
}
#endif
