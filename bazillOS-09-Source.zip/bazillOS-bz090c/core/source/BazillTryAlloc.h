// SPDX-License-Identifier: MIT
#pragma once
#include <cstdlib>
#include <new>
#include <memory>
#include <utility>
#ifdef PLATFORM_IMX
#include <reent.h>
#endif
namespace bazill_alloc {
template<class T>struct Delete {void operator()(T* p)const{if(p){p->~T();std::free(p);}}};
template<class T>using Ptr=std::unique_ptr<T,Delete<T>>;
// Main/UI-thread only. The board's malloc wrapper deliberately asserts on OOM;
// use the same newlib allocator's nullable entry point for optional UI tools.
template<class T,class... Args>T* create(Args&&... args){
#ifdef PLATFORM_IMX
 void* memory=_malloc_r(nullptr,sizeof(T));
#else
 void* memory=std::malloc(sizeof(T));
#endif
 return memory?new(memory) T(std::forward<Args>(args)...):nullptr;
}
}
