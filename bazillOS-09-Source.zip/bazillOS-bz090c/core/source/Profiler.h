#ifndef SOURCE_PROFILER_H_
#define SOURCE_PROFILER_H_
#include "AudioStream.h"
#include "config.h"
#include "stddef.h"
#include "stdint.h"

class Profiler
{
  public:
    static Profiler* getInstance()
    {
        if (instance == nullptr)
        {
            instance = new Profiler;
        }

        return instance;
    }

    struct AudioProcessorUsage
    {
        int minimum;
        int maximum;
        int tempMaximum;
        int average;
        int last;
    };

    void init();

    size_t freeRamBytes();
    size_t maxStackBytes();
    void getAudioProcessingUsageUs(AudioProcessorUsage& usage, bool resetTempMaximum = false);
    void getAudioProcessingUsagePercent(AudioProcessorUsage& usage, bool resetTempMaximum = false);
    void startMeasuringAudio();
    void stopMeasuringAudio();
    void resetMeasuringAudio();

  private:
    static constexpr uint8_t kStackWatermark =
      0xAA; // this value should match the same value from initial code;
    static constexpr float kSamplePeriodUs = (1.0f / 44100.0f) * 1000000.0f;
    static constexpr int kMaxAudioUpdateTime = AUDIO_BLOCK_SAMPLES * kSamplePeriodUs;
    static Profiler* instance;
    int calculatePercentProcessorUsage(int processorUsageUs);

    uint32_t audioUpdateTimer = 0;
    int lastSampleUs = 0;
    uint64_t sumOfSamples = 0;
    uint64_t samples = 0;
    int minSampleUs = 0;
    int maxSampleUs = 0;
    int tempMaxSampleUs = 0;
};

#endif /* SOURCE_PROFILER_H_ */
