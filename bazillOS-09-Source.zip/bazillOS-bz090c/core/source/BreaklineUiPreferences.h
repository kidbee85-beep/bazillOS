#pragma once
#include <stdint.h>
class FileSystem;
namespace breakline_ui {
extern uint8_t motionSetting;
extern uint8_t scaleLockSetting;
void load(FileSystem* fs);
void applyAndSave();
}
