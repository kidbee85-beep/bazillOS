#include "config.h"
#ifdef TRACKER_MINI
#include "breakline/audio_scope.hpp"
namespace bazill_scope {Capture capture;}
#endif
