#include "BreaklineUiPreferences.h"
#ifdef TRACKER_MINI
#include "Platform.h"
#include "BreaklineMotion.h"
namespace breakline_ui {
uint8_t motionSetting=2;
uint8_t scaleLockSetting=0;
namespace { FileSystem* storage=nullptr; constexpr char path[]="breakline-ui.cfg"; }
void load(FileSystem* fs) {
    storage=fs;motionSetting=2;scaleLockSetting=0;
    if(storage){
        auto [ok,file]=storage->openFile(path,FileSystem::kRead);
        if(ok){
            unsigned char data[8]{};const auto n=storage->readFile(data,sizeof data,file);
            storage->closeFile(file);
            const bool magic=data[0]=='B' && data[1]=='L' && data[2]=='U';
            if(magic && n==6 && data[3]==1 && data[4]<=2 &&
               data[5]==static_cast<unsigned char>(data[4]^0xa5)) motionSetting=data[4];
            if(magic && n==7 && data[3]==2 && data[4]<=2 && data[5]<=1 &&
               data[6]==static_cast<unsigned char>(data[4]^data[5]^0xa5)) {
                motionSetting=data[4];scaleLockSetting=data[5];
            }
        }
    }
    breakline_motion::setMode(static_cast<breakline_motion::Mode>(motionSetting));
}
void applyAndSave() {
    if(motionSetting>2)motionSetting=2;
    if(scaleLockSetting>1)scaleLockSetting=0;
    breakline_motion::setMode(static_cast<breakline_motion::Mode>(motionSetting));
    if(!storage)return;
    // Main-loop Config action only, never called by display/audio callbacks.
    auto [ok,file]=storage->openFile(path,storage->exists(path)?FileSystem::kWriteOpen:FileSystem::kWriteCreateNew);
    if(!ok)return;
    const unsigned char data[]={'B','L','U',2,motionSetting,scaleLockSetting,static_cast<unsigned char>(motionSetting^scaleLockSetting^0xa5)};
    storage->writeFile(data,sizeof data,file);storage->closeFile(file);
}
}
#endif
