#pragma once
#include "config.h"
#ifdef TRACKER_MINI
#include <cstdint>
class BazillSlicePreview {
public:
 bool request(uint8_t instrument,const uint16_t* cuts,uint8_t count,uint8_t selected);
 void update();void stop();bool active()const{return loading||playing;}
 const char* status()const{return text;}
private:
 uint8_t instrument=0,channels=1;uint32_t start=0,frames=0,copied=0,hash=0,length=0,ends=0;
 uintptr_t address[2]{};bool loading=false,playing=false,streamed=false;
 char text[96]="Select a preview slice, then tap AUDITION or Play.";
};
extern BazillSlicePreview bazillSlicePreview;
#endif
