// SPDX-License-Identifier: MIT
#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
namespace bazill_arcade_presets {
// Hand-voiced musical starting points: model,timbre,harmonics,morph,attack,
// release,gain(dB), followed by game pitch/rhythm/articulation settings.
struct Preset {const char* name;const char* category;float sound[7];uint8_t root,scale,gate,length;uint16_t rhythm,accents;uint8_t velocity,accent;};
inline constexpr Preset bank[]={
 {"BZ GAME Round Sub","BASS",{2,.10f,.08f,.12f,.002f,.09f,-15.3f},24,1,0,72,0x1111,0x0101,92,112},
 {"BZ GAME Rubber Floor","BASS",{0,.21f,.12f,.24f,.003f,.08f,-15.1f},29,0,0,58,0x5151,0x0101,84,108},
 {"BZ GAME Dust Bass","BASS",{1,.25f,.14f,.18f,.004f,.11f,-12.2f},26,1,0,65,0x1551,0x1111,88,108},
 {"BZ GAME Deep Current","BASS",{2,.06f,.18f,.31f,.005f,.16f,-14.8f},31,2,2,82,0xFFFF,0x0101,82,105},
 {"BZ GAME Acid Pebble","BASS",{7,.24f,.23f,.16f,.002f,.055f,-12.6f},24,1,0,34,0x7777,0x1111,78,104},
 {"BZ GAME Bent Circuit","BASS",{5,.31f,.17f,.29f,.002f,.075f,-14.6f},33,0,0,46,0x5B5B,0x0101,80,109},
 {"BZ GAME Muted Wire","BASS",{4,.22f,.28f,.28f,.002f,.10f,-9.5f},28,2,0,50,0x2222,0x0202,88,108},
 {"BZ GAME Bounce Low","BASS",{1,.16f,.08f,.23f,.003f,.13f,-12.5f},29,0,1,76,0xFFFF,0x1111,86,112},
 {"BZ GAME Glass Drop","PLUCK",{0,.46f,.19f,.67f,.002f,.16f,-15.1f},48,0,0,35,0x5555,0x0101,80,108},
 {"BZ GAME Copper Seed","PLUCK",{3,.29f,.36f,.63f,.001f,.18f,-6.7f},45,1,0,40,0x1331,0x0101,87,110},
 {"BZ GAME Velvet Pick","PLUCK",{4,.27f,.19f,.51f,.002f,.14f,-9.7f},48,2,0,43,0x2525,0x0101,83,107},
 {"BZ GAME Tiny Atlas","PLUCK",{15,.19f,.34f,.27f,.003f,.095f,-13.2f},55,0,0,28,0x5555,0x1111,77,103},
 {"BZ GAME Hollow Key","PLUCK",{2,.23f,.31f,.44f,.004f,.17f,-14.9f},48,1,2,62,0xFFFF,0x0101,85,109},
 {"BZ GAME Soft Phase","PLUCK",{5,.24f,.42f,.32f,.003f,.12f,-13.8f},52,2,0,45,0x5A5A,0x0202,81,106},
 {"BZ GAME Bloom Stone","PLUCK",{18,.33f,.41f,.59f,.002f,.23f,-17.8f},43,0,1,50,0xFFFF,0x1111,84,111},
 {"BZ GAME Paper Bell","PLUCK",{0,.57f,.13f,.73f,.001f,.13f,-14.8f},57,1,0,26,0x4929,0x0101,77,105},
 {"BZ GAME Liquid Steps","ARP",{0,.32f,.23f,.44f,.003f,.12f,-14.7f},48,2,0,52,0xFFFF,0x1111,76,104},
 {"BZ GAME Moss Harp","ARP",{4,.38f,.28f,.68f,.002f,.19f,-10.8f},48,0,0,38,0x7777,0x0101,80,108},
 {"BZ GAME Neon Relay","ARP",{1,.38f,.21f,.49f,.002f,.075f,-13.5f},55,1,0,30,0xFFFF,0x1111,74,102},
 {"BZ GAME Chord Spores","ARP",{13,.18f,.32f,.24f,.006f,.19f,-12.0f},36,2,0,70,0x1111,0x0101,84,105},
 {"BZ GAME Star Tines","ARP",{2,.46f,.39f,.57f,.003f,.16f,-13.4f},60,0,0,42,0x5B5B,0x1111,76,104},
 {"BZ GAME Prism Runner","ARP",{15,.37f,.16f,.62f,.002f,.11f,-14.2f},48,1,0,48,0xFFFF,0x0101,78,108},
 {"BZ GAME Dub Skipper","ARP",{5,.19f,.32f,.21f,.004f,.14f,-14.5f},43,2,0,30,0x8888,0x0808,87,112},
 {"BZ GAME Amber Drift","ARP",{2,.18f,.27f,.73f,.008f,.29f,-15.0f},48,0,1,85,0xFFFF,0x0101,83,107},
 {"BZ GAME Talking Bugs","MUTANT",{16,.35f,.21f,.43f,.003f,.13f,-9.7f},43,1,0,55,0x3333,0x1111,80,110},
 {"BZ GAME Vowel Bounce","MUTANT",{17,.42f,.29f,.54f,.005f,.16f,-17.1f},48,0,1,68,0xFFFF,0x0101,82,108},
 {"BZ GAME Grain Marbles","MUTANT",{8,.37f,.24f,.36f,.002f,.10f,-10.5f},48,2,0,32,0x6B6B,0x0101,76,105},
 {"BZ GAME Pixel Moss","MUTANT",{9,.23f,.18f,.41f,.001f,.075f,-16.3f},55,0,0,25,0x5555,0x1111,79,108},
 {"BZ GAME Folded Wings","MUTANT",{7,.39f,.21f,.42f,.003f,.12f,-12.7f},48,1,0,46,0xADAD,0x0101,77,106},
 {"BZ GAME Swarm Trail","MUTANT",{14,.28f,.33f,.36f,.012f,.21f,-8.9f},43,2,2,78,0xFFFF,0x0101,81,107},
 {"BZ GAME Rust Chimes","MUTANT",{18,.51f,.58f,.37f,.002f,.18f,-16.4f},48,0,0,30,0x4929,0x0101,79,109},
 {"BZ GAME Broken Radio","MUTANT",{15,.62f,.27f,.49f,.003f,.09f,-13.4f},48,1,0,38,0xBBBB,0x1111,76,105}
};
inline constexpr unsigned count=sizeof(bank)/sizeof(bank[0]);
inline const Preset* find(const char* name){if(!name)return nullptr;for(const auto&p:bank)if(std::strcmp(name,p.name)==0)return &p;return nullptr;}
static_assert(count==32);
}
