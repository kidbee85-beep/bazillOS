#pragma once
#include <cstdint>
namespace breakline {
// Snapshot before the fill transaction: changing its first step cannot change
// which subsequent notes belong to the chosen instrument.
struct FillInstrumentFilter {
    std::uint8_t target=0;
    bool matches(int note,std::uint8_t instrument) const {return note>=0 && instrument==target;}
};
}
