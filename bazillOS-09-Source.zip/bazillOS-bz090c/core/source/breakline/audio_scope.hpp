// SPDX-License-Identifier: MIT
#pragma once
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
namespace bazill_scope {
constexpr unsigned frames=1024,bands=32;
// Single ISR producer, one UI consumer. A published frame is immutable until release.
class Capture {
public:
 // Caller holds audio interrupts disabled and has stopped the consumer.
 void resetStopped(){ready.store(-1,std::memory_order_release);writer=0;position=0;}
 void enable(bool v){enabled.store(v,std::memory_order_release);}
 bool isEnabled()const{return enabled.load(std::memory_order_acquire);}
 void push(const int16_t* l,const int16_t* r,unsigned count){
  if(!isEnabled())return;
  while(count){const unsigned n=std::min(count,frames-position);
   if(l)std::memcpy(data[writer][0]+position,l,n*sizeof(int16_t));else std::memset(data[writer][0]+position,0,n*sizeof(int16_t));
   if(r)std::memcpy(data[writer][1]+position,r,n*sizeof(int16_t));else std::memset(data[writer][1]+position,0,n*sizeof(int16_t));
   position+=n;count-=n;if(l)l+=n;if(r)r+=n;
   if(position==frames){
    if(ready.load(std::memory_order_acquire)==-1){ready.store(int(writer),std::memory_order_release);writer^=1;}
    position=0;
   }
  }
 }
 int acquire()const{return ready.load(std::memory_order_acquire);}
 const int16_t* channel(int index,unsigned ch)const{return index>=0&&index<2&&ch<2?data[index][ch]:nullptr;}
 void release(){ready.store(-1,std::memory_order_release);}
private:
 static_assert(std::atomic<int>::is_always_lock_free && std::atomic<bool>::is_always_lock_free,"ISR capture must stay lock free");
 alignas(4) int16_t data[2][2][frames]{};
 std::atomic<int> ready{-1};std::atomic<bool> enabled{false};unsigned writer=0,position=0;
};
struct Result {
 float level[bands]{},peak[2]{},rms[2]{},correlation=0;
 int16_t waveform[2][64]{};
};
class Analyzer {
public:
 Analyzer(){edges[0]=1;for(unsigned i=1;i<=bands;++i)edges[i]=std::max<unsigned>(edges[i-1]+1,unsigned(std::round(std::pow(512.f,float(i)/bands))));}
 unsigned bandForBin(unsigned bin)const{for(unsigned i=0;i<bands;++i)if(bin>=edges[i]&&bin<edges[i+1])return i;return bands;}
 Result result{};
 void analyze(const int16_t* left,const int16_t* right){
  if(!left||!right)return;
  std::fill(result.level,result.level+bands,0.f);
  double lr=0,ll=0,rr=0;
  for(unsigned ch=0;ch<2;++ch){
   const auto* input=ch?right:left;double energy=0;float peak=0;
   for(unsigned i=0;i<frames;++i){
    const float x=input[i]*(1.f/32768.f);peak=std::max(peak,std::abs(x));energy+=double(x)*x;
    if(!ch){const double r=right[i]*(1.0/32768);lr+=x*r;ll+=double(x)*x;rr+=r*r;}
    const float window=.5f-.5f*std::cos(6.283185307f*i/(frames-1));
    work[i][0]=x*window;work[i][1]=0;
   }
   result.peak[ch]=peak;result.rms[ch]=std::sqrt(energy/frames);
   for(unsigned i=0;i<64;++i)result.waveform[ch][i]=input[i*(frames-1)/63];
   fft();
   for(unsigned band=0;band<bands;++band){
    const unsigned lo=edges[band],hi=edges[band+1];
    float power=0;
    for(unsigned bin=lo;bin<std::min(hi,frames/2);++bin)power=std::max(power,work[bin][0]*work[bin][0]+work[bin][1]*work[bin][1]);
    // Stereo power is added, so opposite-polarity channels do not disappear.
    result.level[band]+=power;
   }
  }
  for(auto& x:result.level){const float amplitude=std::sqrt(x)*(.00390625f*.70710678f);x=std::clamp((20.f*std::log10(std::max(amplitude,1e-6f))+72.f)/72.f,0.f,1.f);}
  result.correlation=ll>0&&rr>0?float(std::clamp(lr/std::sqrt(ll*rr),-1.,1.)):0;
 }
private:
 uint16_t edges[bands+1]{};
 float work[frames][2]{};
 void fft(){
  for(unsigned i=1,j=0;i<frames;++i){unsigned bit=frames>>1;for(;j&bit;bit>>=1)j^=bit;j^=bit;
   if(i<j){std::swap(work[i][0],work[j][0]);std::swap(work[i][1],work[j][1]);}}
  for(unsigned length=2;length<=frames;length<<=1){
   const float angle=-6.283185307f/length,wr=std::cos(angle),wi=std::sin(angle);
   for(unsigned start=0;start<frames;start+=length){float xr=1,xi=0;
    for(unsigned j=0;j<length/2;++j){const unsigned a=start+j,b=a+length/2;
     const float vr=work[b][0]*xr-work[b][1]*xi,vi=work[b][0]*xi+work[b][1]*xr;
     const float ar=work[a][0],ai=work[a][1];work[a][0]=ar+vr;work[a][1]=ai+vi;work[b][0]=ar-vr;work[b][1]=ai-vi;
     const float next=xr*wr-xi*wi;xi=xr*wi+xi*wr;xr=next;
    }
   }
  }
 }
};
extern Capture capture;
}
