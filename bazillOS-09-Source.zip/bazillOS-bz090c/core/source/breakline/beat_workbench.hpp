// SPDX-License-Identifier: MIT
#pragma once
#include "groove.hpp"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
namespace bazill_beats {
struct Fx {uint8_t type=0,value=0;};
struct Step {int8_t note=-1;uint8_t instrument=0;Fx fx[2]{};int8_t volume=-1,micro=-1;};
static_assert(sizeof(Step)==8,"bounded native step adapter");
enum class Task:uint8_t {originalChops,rhythmChops,variation,applyGroove};
struct Preset {const char* name;breakline::GrooveStyle style;breakline::GrooveLane lane;uint8_t density,variation,swing,humanize;};
using S=breakline::GrooveStyle;using L=breakline::GrooveLane;
inline constexpr Preset presets[]={
 {"Dust Pocket",S::hiphop,L::chop,70,18,12,3},{"Late Night",S::hiphop,L::chop,55,25,20,5},
 {"Loose Hats",S::hiphop,L::hat,78,30,18,7},{"Kick Home",S::hiphop,L::kick,60,15,8,3},
 {"Snare Dust",S::hiphop,L::snare,50,18,12,4},{"Broken Vinyl",S::hiphop,L::chop,65,65,26,8},
 {"Mellow Steps",S::hiphop,L::hat,55,15,30,4},{"Dry Machine",S::hiphop,L::chop,85,10,0,0},
 {"Jungle Start",S::drum_and_bass,L::chop,85,45,2,2},{"Amen Scatter",S::drum_and_bass,L::chop,90,75,0,3},
 {"Ghost Break",S::drum_and_bass,L::snare,72,65,3,4},{"Rolling Hats",S::drum_and_bass,L::hat,95,35,0,2},
 {"Heavy TwoStep",S::drum_and_bass,L::kick,75,22,0,1},{"Liquid Space",S::drum_and_bass,L::chop,60,25,4,3},
 {"Tight Steppa",S::drum_and_bass,L::chop,78,18,0,0},{"Coder Chaos",S::drum_and_bass,L::chop,96,92,6,5},
 {"Sparse Chop",S::hiphop,L::chop,35,20,12,2},{"Tape Bounce",S::hiphop,L::chop,75,38,22,6},
 {"Heavy Swing",S::hiphop,L::hat,80,35,35,8},{"Back Alley",S::hiphop,L::snare,45,42,24,6},
 {"HalfTime Kick",S::hiphop,L::kick,40,20,4,1},{"Open Space",S::hiphop,L::chop,28,18,10,3},
 {"Chopped Keys",S::hiphop,L::chop,65,50,15,4},{"Neon Dust",S::hiphop,L::hat,82,55,16,8},
 {"Razor Break",S::drum_and_bass,L::chop,94,60,0,0},{"Tiny Ghosts",S::drum_and_bass,L::snare,38,55,6,3},
 {"Skitter",S::drum_and_bass,L::hat,88,70,5,5},{"Sub Space",S::drum_and_bass,L::kick,35,18,0,0},
 {"Metal Rain",S::drum_and_bass,L::hat,98,80,2,6},{"Broken Orbit",S::drum_and_bass,L::chop,72,80,9,7},
 {"Soft Roll",S::drum_and_bass,L::chop,65,35,5,2},{"Chip Jungle",S::drum_and_bass,L::chop,90,90,0,0}
};
inline constexpr unsigned presetCount=sizeof(presets)/sizeof(presets[0]);
struct Groove {uint8_t timing[128]{},velocity[128]{};bool occupied[128]{};uint8_t length=16;bool ready=false;};
struct Config {Task task=Task::rhythmChops;uint8_t preset=0,amount=50,instrument=0,note=60,slices=16;uint32_t seed=1,offsetFrames=0;bool beatSlice=true;};
class Workbench {
public:
 void clearSnapshot(){length=0;ready=false;}
 void invalidate(){ready=false;}
 bool snapshot(const Step* input,unsigned n){
  if(!input||n<16||n>128||n%16)return false;
  length=n;std::memcpy(original,input,n*sizeof(Step));std::memcpy(preview,input,n*sizeof(Step));
  std::fill(locks,locks+128,0);ready=false;return true;
 }
 bool unchanged(const Step* input,unsigned n)const{return input&&n==length&&std::memcmp(input,original,n*sizeof(Step))==0;}
 bool generate(const Config& c,const uint16_t* starts,unsigned slices,uint32_t frames,double bpm){
  ready=false;
  if(!length||c.preset>=presetCount||c.amount>100||c.instrument>=67||c.note>127||c.slices>48||!c.slices)return false;
  if(c.task!=Task::variation&&c.task!=Task::applyGroove&&!c.beatSlice)return false;
  if(c.task==Task::applyGroove&&!groove.ready)return false;
  if(c.task==Task::variation&&c.amount==0){std::memcpy(preview,original,length*sizeof(Step));ready=true;return true;}
  Step staged[128];std::memcpy(staged,original,length*sizeof(Step));
  if(c.task==Task::originalChops){
   if(!starts||!slices||slices>48||!frames||!std::isfinite(bpm)||bpm<20||bpm>400)return false;
   for(unsigned i=1;i<slices;++i)if(starts[i]<=starts[i-1])return false;
   for(unsigned i=0;i<length;++i)if(!locks[i])staged[i]=Step{};
   const double stepFrames=44100.*60./(bpm*4.);
   for(unsigned slice=0;slice<slices;++slice){
    const double sourcePosition=double(starts[slice])*frames/65535.;
    if(sourcePosition<c.offsetFrames)continue;
    const double position=(sourcePosition-c.offsetFrames)/stepFrames;
    const auto cell=static_cast<unsigned>(position);if(cell>=length)break;
    if(locks[cell])continue;
    if(staged[cell].note>=0)return false; // Avoid silently discarding colliding transients.
    staged[cell].note=static_cast<int8_t>(24+slice);staged[cell].instrument=c.instrument;
    staged[cell].volume=100;staged[cell].micro=static_cast<int8_t>(std::min(99.,std::floor((position-cell)*100.)));
   }
  }else if(c.task==Task::applyGroove){
   for(unsigned i=0;i<length;++i){auto& step=staged[i];const unsigned at=i%groove.length;
    if(locks[i]||step.note<0||step.instrument!=c.instrument||!groove.occupied[at])continue;
    const int oldVolume=step.volume<0?100:step.volume,oldMicro=step.micro<0?0:step.micro;
    step.volume=static_cast<int8_t>((oldVolume*(100-c.amount)+groove.velocity[at]*c.amount)/100);
    step.micro=static_cast<int8_t>((oldMicro*(100-c.amount)+groove.timing[at]*c.amount)/100);
   }
  }else{
   breakline::GrooveStep generated[128]{};const auto& p=presets[c.preset];
   for(unsigned i=0;i<length;++i){auto& out=generated[i];const auto& in=original[i];
    out.trigger=in.note>=0;out.velocity=static_cast<uint8_t>((in.volume<0?100:in.volume)*127/100);
    out.timing=static_cast<int8_t>((in.micro<0?0:in.micro)*96/100);out.slice=in.note>=24?in.note-24:0;
    if(locks[i]||(c.task==Task::variation&&((in.note>=0&&in.instrument!=c.instrument)||in.note==-2||in.note==-3||in.note==-4)))out.locks=breakline::lock_all;
   }
   breakline::GrooveConfig cfg;cfg.style=p.style;cfg.lane=p.lane;cfg.seed=c.seed;cfg.density=p.density;
   cfg.variation=static_cast<uint8_t>(p.variation*c.amount/100);cfg.swing=p.swing;cfg.humanize=p.humanize;cfg.slice_count=c.slices;
   if(breakline::generate_groove(cfg,generated,length)!=breakline::GrooveStatus::ok)return false;
   for(unsigned i=0;i<length;++i){if(generated[i].locks==breakline::lock_all)continue;
    auto& out=staged[i];const auto& g=generated[i];
    if(c.task==Task::rhythmChops)out=Step{};
    if(g.trigger){out.note=static_cast<int8_t>(c.beatSlice?24+g.slice:(original[i].note>=0?original[i].note:c.note));
     out.instrument=c.instrument;out.volume=static_cast<int8_t>(g.velocity*100/127);out.micro=static_cast<int8_t>(g.timing*100/96);
    }else{out.note=-1;out.instrument=0;out.volume=-1;out.micro=-1;}
   }
  }
  std::memcpy(preview,staged,length*sizeof(Step));ready=true;return true;
 }
 bool extract(const uint16_t* starts,const uint16_t* peaks,unsigned n,uint32_t frames,double bpm,uint32_t offsetFrames=0){
  if(!length||!starts||!peaks||!n||n>48||!frames||!std::isfinite(bpm)||bpm<20||bpm>400)return false;
  Groove g;g.length=static_cast<uint8_t>(length); // 128 fits uint8_t.
  const double stepFrames=44100.*60./(bpm*4.);
  uint16_t maximum=0;
  for(unsigned i=0;i<n;++i){const double at=double(starts[i])*frames/65535.;if(at>=offsetFrames&&(at-offsetFrames)/stepFrames<length)maximum=std::max(maximum,peaks[i]);}
  if(!maximum)return false;
  for(unsigned i=0;i<n;++i){
   if(i&&starts[i]<=starts[i-1])return false;
   const double sourcePosition=double(starts[i])*frames/65535.;if(sourcePosition<offsetFrames)continue;
   const double position=(sourcePosition-offsetFrames)/stepFrames;const auto cell=static_cast<unsigned>(position);
   if(cell>=length)break;
   if(!g.occupied[cell]||peaks[i]>g.velocity[cell]*maximum/100){
    g.occupied[cell]=true;g.timing[cell]=static_cast<uint8_t>(std::min(99.,std::floor((position-cell)*100.)));
    g.velocity[cell]=static_cast<uint8_t>(std::clamp<unsigned>(unsigned(peaks[i])*100/maximum,1,100));
   }
  }
  g.ready=true;groove=g;return true;
 }
 void toggleLock(unsigned step){if(step<length)locks[step]^=breakline::lock_all;ready=false;}
 const Step* view(bool compare=false)const{return compare?original:preview;}
 unsigned size()const{return length;}
 bool isReady()const{return ready;}
 bool locked(unsigned step)const{return step<length&&locks[step];}
 Groove groove{};
private:
 Step original[128]{},preview[128]{};uint8_t locks[128]{};unsigned length=0;bool ready=false;
};
}
