// SPDX-License-Identifier: MIT
#pragma once
#include "game.hpp"
#include "arcade_presets.hpp"
#include <algorithm>
#include <cstdint>
#include <cstdlib>
namespace bazill_arcade_synth {
// One deterministic physics step and one musical sixteenth-note slot per tick.
// No allocation, audio processing, timers, project writes or failure screens.
class Instrument {
public:
 enum Kind:uint8_t{pong,breaker};
 explicit Instrument(Kind k=pong):kind_(k){if(k==breaker){px_=8;py_=7;}refill();serve();}
 const char* name()const{return kind_==pong?"PULSE PONG":"VIRUS BREAKER";}
 Kind kind()const{return kind_;}unsigned x()const{return x_;}unsigned y()const{return y_;}
 unsigned paddleX()const{return px_;}unsigned paddleY()const{return py_;}
 bool automatic()const{return automatic_;}unsigned column()const{return column_;}
 unsigned score()const{return score_;}unsigned misses()const{return misses_;}
 unsigned bars()const{return bars_;}unsigned root()const{return root_;}unsigned gate()const{return gate_;}
 unsigned scale()const{return scale_;}bool ready()const{return bars_>0;}
 unsigned lengthPercent()const{return length_;}
 bool applyPreset(unsigned index){
  if(index>=bazill_arcade_presets::count)return false;
  const auto&p=bazill_arcade_presets::bank[index];root_=p.root;scale_=p.scale;gate_=p.gate;length_=p.length;
  rhythm_=p.rhythm;accents_=p.accents;velocity_=p.velocity;accent_=p.accent;
  automatic_=true;column_=0;bars_=score_=misses_=0;for(auto&n:phrase_)n={};for(auto&n:completed_)n={};refill();serve();return true;
 }
 const char* gateName()const{return gate_==0?(rhythm_==0xFFFF?"EVERY STEP":"PRESET RHYTHM"):gate_==1?"BOUNCES":"HALF DENSITY";}
 const char* scaleName()const{return scale_==0?"PENTA":scale_==1?"MINOR":"DORIAN";}
 bool brick(unsigned x,unsigned y)const{return x<16&&y<3&&(bricks_[y]&(1u<<x));}
 const breakline::GameStep* captured()const{return completed_;}
 const breakline::GameStep& step(unsigned i)const{return phrase_[i%16];}
 uint8_t pitch(unsigned screenRow)const{constexpr uint8_t notes[3][8]={{0,3,5,7,10,12,15,17},{0,2,3,5,7,8,10,12},{0,2,3,5,7,9,10,12}};return root_+notes[scale_][7-screenRow%8];}
 void nextGate(){gate_=(gate_+1)%3;rhythm_=0xFFFF;}void nextScale(){scale_=(scale_+1)%3;}
 void setRoot(int root){if(root>=24&&root<=60)root_=root;}
 void toggleAuto(){automatic_=!automatic_;}
 void move(int dx,int dy){
  automatic_=false;
  if(kind_==pong){px_=std::clamp(int(px_)+std::clamp(dx,-1,1),0,5);py_=std::clamp(int(py_)+std::clamp(dy,-1,1),1,6);}
  else{px_=std::clamp(int(px_)+std::clamp(dx,-1,1),1,14);py_=std::clamp(int(py_)+std::clamp(dy,-1,1),4,7);}
 }
 void serve(){x_=kind_==pong?8:px_;y_=kind_==pong?4:py_-1;dx_=1;dy_=kind_==pong?1:-1;}
 void restartBar(){column_=0;for(auto&n:phrase_)n={};}
 breakline::GameEvent tick(){
  if(automatic_){if(kind_==pong){px_=1;py_=std::clamp(int(y_)+dy_,1,6);}else{px_=std::clamp(int(x_)+dx_,1,14);py_=7;}}
  int nx=int(x_)+dx_,ny=int(y_)+dy_;bool bounce=false,miss=false;
  if(nx<0&&kind_==breaker){dx_=1;nx=1;bounce=true;}
  if(nx>15){dx_=-1;nx=14;bounce=true;}
  if(ny<0){dy_=1;ny=1;bounce=true;}
  if(kind_==pong&&ny>7){dy_=-1;ny=6;bounce=true;}
  if(kind_==pong){
   if(dx_<0&&int(x_)>px_&&nx<=px_&&std::abs(ny-int(py_))<=1){dx_=1;nx=px_+1;bounce=true;++score_;}
   if(nx<0){miss=true;++misses_;serve();nx=x_;ny=y_;}
  }else{
   if(ny>=0&&ny<3&&nx>=0&&nx<16&&brick(nx,ny)){bricks_[ny]&=~(1u<<nx);dy_=-dy_;ny=std::clamp(int(y_)+dy_,0,7);bounce=true;++score_;}
   if(dy_>0&&int(y_)<py_&&ny>=py_&&std::abs(nx-int(px_))<=1){dy_=-1;ny=py_-1;bounce=true;++score_;if(nx<int(px_))dx_=-1;else if(nx>int(px_))dx_=1;}
   if(ny>7){miss=true;++misses_;serve();nx=x_;ny=y_;}
   if(!(bricks_[0]|bricks_[1]|bricks_[2]))refill();
  }
  x_=std::clamp(nx,0,15);y_=std::clamp(ny,0,7);
  const bool on=!miss&&(rhythm_&(1u<<column_))&&(gate_==0||(gate_==1?bounce:column_%2==0));
  const uint8_t note=pitch(y_),velocity=(bounce||(accents_&(1u<<column_)))?accent_:velocity_;
  phrase_[column_]={on,note,velocity};column_=(column_+1)%16;
  if(column_==0){for(unsigned i=0;i<16;++i)completed_[i]=phrase_[i];++bars_;}
  return {on,bounce,note,velocity};
 }
private:
 void refill(){for(auto&r:bricks_)r=0xFFFF;}
 Kind kind_;uint8_t x_=8,y_=4,px_=1,py_=4,column_=0,root_=48,gate_=0,scale_=1;
 int8_t dx_=1,dy_=1;bool automatic_=true;unsigned score_=0,misses_=0,bars_=0;
 uint16_t bricks_[3]{};breakline::GameStep phrase_[16]{},completed_[16]{};
 uint16_t rhythm_=0xFFFF,accents_=0;uint8_t velocity_=90,accent_=120,length_=80;
};
}
