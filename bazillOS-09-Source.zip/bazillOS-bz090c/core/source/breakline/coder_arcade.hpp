// SPDX-License-Identifier: MIT
#pragma once
#include <algorithm>
#include <cstdint>
namespace bazill_arcade {
struct Catch {bool collected=false;uint8_t row=0,step=0,velocity=100;};
class BugHunt {
public:
 void reset(uint32_t seed){random_=seed?seed:1;x_=0;y_=3;score_=0;moves_=0;spawn();}
 Catch move(int dx,int dy){x_=static_cast<uint8_t>((int(x_)+(dx%16)+16)%16);y_=static_cast<uint8_t>((int(y_)+(dy%8)+8)%8);++moves_;return catchBug(false);}
 Catch bop(){return catchBug(true);}
 uint8_t x()const{return x_;}uint8_t y()const{return y_;}uint8_t bugX()const{return bugX_;}uint8_t bugY()const{return bugY_;}
 uint32_t score()const{return score_;}uint32_t moves()const{return moves_;}
private:
 uint32_t random(){random_^=random_<<13;random_^=random_>>17;random_^=random_<<5;return random_;}
 void spawn(){bugX_=random()%16;bugY_=random()%8;if(bugX_==x_&&bugY_==y_)bugX_=(bugX_+7)%16;}
 Catch catchBug(bool adjacent){
  int dx=std::abs(int(x_)-int(bugX_)),dy=std::abs(int(y_)-int(bugY_));dx=std::min(dx,16-dx);dy=std::min(dy,8-dy);
  if(dx+dy>(adjacent?1:0))return {};
  Catch event{true,bugY_,static_cast<uint8_t>(score_%32),static_cast<uint8_t>(96+score_%28)};
  if(score_!=UINT32_MAX)++score_;spawn();return event;
 }
 uint32_t random_=1,score_=0,moves_=0;uint8_t x_=0,y_=3,bugX_=9,bugY_=5;
};
class PatchQuest {
public:
 struct Trace {uint8_t cells[16]{},count=0;bool solved=false;};
 void reset(uint32_t seed){uint32_t s=seed?seed:1;cursor_=0;
  auto next=[&](){s^=s<<13;s^=s>>17;s^=s<<5;return s;};
  for(auto& p:pipes_)p=(next()&1)?5:3;
  // A guaranteed route; scramble its rotations and mix it with harmless decoys.
  pipes_[4]=10;pipes_[5]=9;pipes_[1]=6;pipes_[2]=12;pipes_[6]=5;pipes_[10]=3;pipes_[11]=10;
  for(auto& p:pipes_)for(unsigned n=next()%4;n;--n)p=rotateMask(p);
 }
 void move(int dx,int dy){const int x=(int(cursor_%4)+(dx%4)+4)%4,y=(int(cursor_/4)+(dy%4)+4)%4;cursor_=static_cast<uint8_t>(y*4+x);}
 void rotate(){pipes_[cursor_]=rotateMask(pipes_[cursor_]);}
 uint8_t cursor()const{return cursor_;}uint8_t pipe(unsigned at)const{return at<16?pipes_[at]:0;}
 Trace trace()const{
  Trace result;uint16_t visited=0;int cell=4,entry=3;
  while(cell>=0&&cell<16&&result.count<16){
   if(visited&(1u<<cell))return result;visited|=1u<<cell;
   const uint8_t mask=pipes_[cell];if(!(mask&(1u<<entry)))return result;
   result.cells[result.count++]=static_cast<uint8_t>(cell);int exit=-1;
   for(int d=0;d<4;++d)if(d!=entry&&(mask&(1u<<d))){if(exit>=0)return result;exit=d;}
   if(exit<0)return result;
   if(cell==11&&exit==1){result.solved=true;return result;}
   const int x=cell%4,y=cell/4;const int nx=x+(exit==1)-(exit==3),ny=y+(exit==2)-(exit==0);
   if(nx<0||nx>=4||ny<0||ny>=4)return result;
   cell=ny*4+nx;entry=(exit+2)%4;
  }
  return result;
 }
private:
 static uint8_t rotateMask(uint8_t m){return static_cast<uint8_t>(((m<<1)&15)|(m>>3));}
 uint8_t pipes_[16]{},cursor_=0;
};
}
