// SPDX-License-Identifier: MIT
#pragma once
#include <algorithm>
#include <cstdint>
#include <cstring>
namespace bazill_drums {
struct Packing {
 uint8_t destination[8][128]{};uint8_t tracks=0;bool valid=false;
};
// Samples keep a fixed track while sharing only nonoverlapping tail regions.
// Independent PERC one-shots may move between otherwise free step cells.
// Caller classifies sources and supplies conservative sample hold lengths.
template<class Cell>void pack(Packing&out,unsigned steps,uint8_t enabled,uint8_t sampleSources,const uint16_t hold[8],Cell cell){
 std::memset(out.destination,255,sizeof out.destination);out.tracks=0;out.valid=false;if(!steps||steps>128||!hold)return;
 struct Search{unsigned steps;uint8_t active=0,samples=0;uint8_t percs[128]{},busy[8][128]{},edges[8]{},colour[8]{},roles[8]{},roleCount=0,limit=0;unsigned nodes=0;bool exhausted=false;
  bool check(){for(unsigned s=0;s<steps;++s){uint8_t used=0;for(unsigned r=0;r<8;++r)if((samples&(1u<<r))&&busy[r][s])used|=1u<<colour[r];unsigned occupied=0;for(unsigned c=0;c<limit;++c)occupied+=(used>>c)&1u;if(occupied+percs[s]>limit)return false;}return true;}
  bool solve(unsigned at,unsigned used){if(++nodes>200000){exhausted=true;return false;}if(at==roleCount)return check();const unsigned r=roles[at];for(unsigned c=0;c<std::min<unsigned>(limit,used+1);++c){bool fits=true;for(unsigned i=0;i<at;++i)if((edges[r]&(1u<<roles[i]))&&colour[roles[i]]==c)fits=false;if(!fits)continue;colour[r]=c;if(solve(at+1,std::max(used,c+1)))return true;if(exhausted)return false;}return false;}
 } search;search.steps=steps;
 for(unsigned r=0;r<8;++r)if(enabled&(1u<<r)){bool audible=false;for(unsigned s=0;s<steps;++s)audible|=cell(r,s).velocity!=0;if(audible)search.active|=1u<<r;}
 if(!search.active){out.valid=true;return;}search.samples=sampleSources&search.active;
 for(unsigned r=0;r<8;++r)if(search.active&(1u<<r)){
  if(search.samples&(1u<<r)){search.roles[search.roleCount++]=r;for(unsigned s=0;s<steps;++s)if(cell(r,s).velocity){const unsigned span=std::min<unsigned>(steps,std::max<unsigned>(1,hold[r])+(cell(r,s).micro?1:0));for(unsigned k=0;k<span;++k)search.busy[r][(s+k)%steps]=1;}}
  else for(unsigned s=0;s<steps;++s)search.percs[s]+=cell(r,s).velocity!=0;
 }
 for(unsigned a=0;a<8;++a)if(search.samples&(1u<<a))for(unsigned b=a+1;b<8;++b)if(search.samples&(1u<<b))for(unsigned s=0;s<steps;++s)if(search.busy[a][s]&&search.busy[b][s]){search.edges[a]|=1u<<b;search.edges[b]|=1u<<a;break;}
 bool found=false;for(search.limit=1;search.limit<=8;++search.limit){search.nodes=0;if(search.solve(0,0)){found=true;break;}if(search.exhausted)break;}
 if(!found){out.tracks=8;for(unsigned r=0;r<8;++r)for(unsigned s=0;s<steps;++s)if((search.active&(1u<<r))&&cell(r,s).velocity)out.destination[r][s]=r;out.valid=true;return;}
 out.tracks=search.limit;
 for(unsigned s=0;s<steps;++s){uint8_t occupied=0;for(unsigned r=0;r<8;++r)if((search.samples&(1u<<r))&&search.busy[r][s])occupied|=1u<<search.colour[r];
  for(unsigned r=0;r<8;++r)if((search.samples&(1u<<r))&&cell(r,s).velocity)out.destination[r][s]=search.colour[r];
  for(unsigned r=0;r<8;++r)if((search.active&~search.samples)&(1u<<r))if(cell(r,s).velocity){unsigned c=0;while(c<out.tracks&&(occupied&(1u<<c)))++c;if(c>=out.tracks)return;out.destination[r][s]=c;occupied|=1u<<c;}
 }out.valid=true;
}
}
