#pragma once
#include "breakline/sample_analysis.hpp"
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>
namespace breakline {
enum class ChopMode : std::uint8_t { onsets, evenly, grid, phrases };
enum class ChopProfile : std::uint8_t { drums, breaks, melodic };
struct ChopRecipe {
    const char* name;
    const char* description;
    ChopMode mode;
    ChopProfile profile;
    std::uint8_t count, sensitivity, grid;
};
// Original bazillOS recipes. Tempo recipes use the project BPM explicitly.
inline constexpr ChopRecipe chopRecipes[]={
    {"Drum Hits", "Separate attacks / one-shots", ChopMode::onsets, ChopProfile::drums, 3,70,2},
    {"Tight Break", "Detailed drum break cuts", ChopMode::onsets, ChopProfile::breaks, 3,65,2},
    {"Loose Break", "Fewer cuts / longer grooves", ChopMode::onsets, ChopProfile::breaks, 2,35,2},
    {"Melody", "Softer attacks / even fallback", ChopMode::onsets, ChopProfile::melodic, 2,60,2},
    {"Vocal Gaps", "Restart after 120 ms silence", ChopMode::phrases, ChopProfile::melodic, 3,90,2},
    {"Long Phrases", "Restart after 300 ms silence", ChopMode::phrases, ChopProfile::melodic, 2,45,2},
    {"Equal 8", "Eight equal regions", ChopMode::evenly, ChopProfile::breaks, 1,55,2},
    {"Equal 16", "Sixteen equal regions", ChopMode::evenly, ChopProfile::breaks, 2,55,2},
    {"Equal 32", "Thirty-two equal regions", ChopMode::evenly, ChopProfile::breaks, 3,55,2},
    {"Tempo Grid", "Project BPM / quarter beats", ChopMode::grid, ChopProfile::breaks, 2,55,2}
};
inline constexpr unsigned chopRecipeCount=sizeof(chopRecipes)/sizeof(chopRecipes[0]);
struct ChopIdentity {
    std::uintptr_t left=0,right=0;
    std::uint32_t frames=0,hash=0;
    std::uint8_t instrument=0;
    bool stereo=false,streamed=false;
};
class ChopSession {
public:
    static constexpr std::size_t capacity=48;
    bool begin(const ChopIdentity& id,const std::uint16_t* current,std::uint8_t count,std::uint8_t selected){
        cancel();
        if(!id.frames||id.instrument>=48||!current||count>capacity)return false;
        identity=id;originalCount=count;originalSelected=selected;
        std::memcpy(original,current,sizeof original);invalidate();active=true;return true;
    }
    bool matches(const ChopIdentity& id,const std::uint16_t* current,std::uint8_t count,std::uint8_t selected)const{
        return active&&current&&id.left==identity.left&&id.right==identity.right&&id.frames==identity.frames&&
          id.hash==identity.hash&&id.instrument==identity.instrument&&id.stereo==identity.stereo&&
          id.streamed==identity.streamed&&count==originalCount&&selected==originalSelected&&
          std::memcmp(original,current,sizeof original)==0;
    }
    void invalidate(){manual=false;ready=false;count=0;selected=0;std::memset(starts,0,sizeof starts);}
    void cancel(){invalidate();active=false;}
    void setRecipe(unsigned index){
        recipeIndex=static_cast<std::uint8_t>(std::min(index,chopRecipeCount-1));
        const auto& r=recipe();mode=r.mode;profile=r.profile;countIndex=r.count;
        sensitivity=r.sensitivity;gridIndex=r.grid;manual=false;invalidate();
    }
    const ChopRecipe& recipe()const{return chopRecipes[std::min<unsigned>(recipeIndex,chopRecipeCount-1)];}
    // Starts remain in the native 16-bit format. The sample itself is never edited.
    bool nudgeSelected(int delta,std::uint32_t rate){
        if(!ready||!count||!selected||selected>=count||!delta||!rate||!identity.frames)return false;
        const auto gap=minimumGap(rate);
        const int low=int(starts[selected-1])+gap;
        const int high=(selected+1<count?int(starts[selected+1]):65535)-gap;
        if(low>high)return false;
        const auto unit=std::max<std::uint64_t>(1,std::uint64_t(rate)*65535/(std::uint64_t(identity.frames)*1000));
        const auto next=static_cast<std::uint16_t>(std::clamp<std::int64_t>(
          std::int64_t(starts[selected])+std::clamp(delta,-100,100)*std::int64_t(unit),low,high));
        if(next==starts[selected])return false;
        starts[selected]=next;manual=true;return true;
    }
    bool splitSelected(std::uint32_t rate){
        if(!ready||!count||count>=capacity||selected>=count||!rate)return false;
        const unsigned end=selected+1<count?starts[selected+1]:65535;
        if(end-starts[selected]<2*minimumGap(rate))return false;
        const auto cut=static_cast<std::uint16_t>((unsigned(starts[selected])+end)/2);
        for(unsigned i=count;i>unsigned(selected)+1;--i)starts[i]=starts[i-1];
        starts[++selected]=cut;++count;manual=true;return true;
    }
    bool mergeSelected(){
        if(!ready||count<2||selected>=count)return false;
        const unsigned remove=std::max<unsigned>(1,selected);
        for(unsigned i=remove;i+1<count;++i)starts[i]=starts[i+1];
        starts[--count]=0;selected=static_cast<std::uint8_t>(remove-1);manual=true;return true;
    }
    std::uint32_t cutMs(std::uint32_t rate,bool end=false)const{
        if(!rate||!ready||selected>=count)return 0;
        const unsigned value=end?(selected+1<count?starts[selected+1]:65535):starts[selected];
        return static_cast<std::uint32_t>(std::uint64_t(value)*identity.frames*1000/65535/rate);
    }
    TransientConfig onsetConfig(std::uint32_t rate)const{
        TransientConfig c;c.sample_rate=rate;
        const unsigned sens=std::clamp<unsigned>(sensitivity,20,100);
        if(profile==ChopProfile::drums){c.window_frames=64;c.minimum_slice_ms=35;c.attack_ratio=2.6f;c.novelty_floor=0.020f;}
        else if(profile==ChopProfile::breaks){c.window_frames=128;c.minimum_slice_ms=55;c.attack_ratio=2.9f;c.novelty_floor=0.024f;}
        else{c.window_frames=256;c.minimum_slice_ms=90;c.attack_ratio=2.1f;c.novelty_floor=0.012f;}
        c.attack_ratio=std::max(1.05f,c.attack_ratio-(sens-20)*0.012f);
        c.novelty_floor*=1.35f-(sens-20)*0.009f;
        if(mode==ChopMode::phrases){c.phrase_gap_ms=80+(100-sens)*4;c.amplitude_floor=profile==ChopProfile::melodic?.006f:.012f;}
        return c;
    }
    AnalysisStatus createEven(std::uint32_t rate){
        invalidate();
        if(!active||!rate)return AnalysisStatus::invalid_argument;
        std::uint64_t boundaries[capacity+1]{};
        const auto minimum=std::max<std::uint64_t>(1,(static_cast<std::uint64_t>(rate)*10+999)/1000);
        const auto result=equal_slices(identity.frames,targetCount(),minimum,boundaries,capacity+1);
        return result.status==AnalysisStatus::ok?stage(boundaries,result.boundary_count):result.status;
    }
    AnalysisStatus createGrid(std::uint32_t rate,double bpm){
        invalidate();
        std::uint64_t boundaries[capacity+1]{};
        const auto result=grid_slices(identity.frames,rate,bpm,gridDivision(),1,boundaries,capacity+1);
        return result.status==AnalysisStatus::ok?stage(boundaries,result.boundary_count):result.status;
    }
    bool finishOnsets(){
        if(!active||!count||count>capacity)return false;
        for(unsigned i=1;i<count;++i)if(starts[i]<=starts[i-1])return false;
        const auto limit=targetCount();
        if(count>limit){
            const auto oldCount=count;
            // Spread retained onsets over the full analysis, including its final onset.
            for(unsigned i=0;i<limit;++i)starts[i]=starts[(i*(oldCount-1))/(limit-1)];
            count=limit;
        }
        for(unsigned i=count;i<capacity;++i)starts[i]=0;
        selected=0;ready=true;return true;
    }
    void select(int delta){
        if(!count)return;
        selected=static_cast<std::uint8_t>(std::clamp<int>(selected+std::clamp(delta,-48,48),0,count-1));
    }
    std::uint8_t targetCount()const{constexpr std::uint8_t n[]={4,8,16,32,48};return n[std::min<unsigned>(countIndex,4)];}
    std::uint8_t gridDivision()const{constexpr std::uint8_t n[]={1,2,4,8,16};return n[std::min<unsigned>(gridIndex,4)];}
    std::uint8_t countIndex=2,gridIndex=2,sensitivity=55,recipeIndex=1;
    ChopMode mode=ChopMode::onsets;ChopProfile profile=ChopProfile::breaks;
    ChopIdentity identity{};
    std::uint16_t starts[capacity]{};
    std::uint8_t count=0,selected=0;
    bool active=false,ready=false,manual=false;
private:
    unsigned minimumGap(std::uint32_t rate)const{
        if(!identity.frames)return 65535;
        const auto denominator=std::uint64_t(identity.frames)*1000;
        return static_cast<unsigned>(std::min<std::uint64_t>(65535,
          (std::uint64_t(rate)*10*65535+denominator-1)/denominator));
    }
    AnalysisStatus stage(const std::uint64_t* boundaries,std::size_t n){
        if(!active||!boundaries||n<2||n>capacity+1||boundaries[0]||boundaries[n-1]!=identity.frames)
            return AnalysisStatus::invalid_argument;
        std::uint16_t next[capacity]{};std::uint8_t used=0;
        for(std::size_t i=0;i+1<n;++i){
            if(boundaries[i]>=identity.frames||(i&&boundaries[i]<=boundaries[i-1]))return AnalysisStatus::invalid_argument;
            const auto value=static_cast<std::uint16_t>((boundaries[i]*65535)/identity.frames);
            if(!used||value>next[used-1])next[used++]=value;
        }
        std::memcpy(starts,next,sizeof starts);count=used;selected=0;ready=true;return AnalysisStatus::ok;
    }
    std::uint16_t original[capacity]{};
    std::uint8_t originalCount=0,originalSelected=0;
};
}
