#pragma once
#include <cstddef>
#include <cstdint>
namespace breakline {
enum class GameScale : std::uint8_t { pentatonic, minor, dorian };
struct GameStep { bool active=false; std::uint8_t note=48, velocity=100; };
struct GameEvent { bool trigger=false, collected=false; std::uint8_t note=48, velocity=100; };
// ORBIT is a small musical playground, not an audio callback or project editor.
// Every active step belongs to the chosen scale. No heap, clock or global state.
class GameEngine {
public:
    static constexpr std::uint8_t maximumSteps=32, rows=8;
    GameEngine() { newBoard(1); }
    void newBoard(std::uint32_t seed) {
        random_=seed?seed:0x9e3779b9u;score_=0;x_=0;row_=3;
        for(std::uint8_t i=0;i<maximumSteps;++i){steps_[i]=GameStep{};noteRows_[i]=3;stars_[i]=random()%rows;}
    }
    void clear() { for(auto& step:steps_)step.active=false;score_=0; }
    bool setLength(std::uint8_t length) {
        if(length!=16&&length!=32)return false;
        length_=length;x_%=length_;return true;
    }
    bool setScale(GameScale scale) {
        if(scale!=GameScale::pentatonic&&scale!=GameScale::minor&&scale!=GameScale::dorian)return false;
        scale_=scale;retune();return true;
    }
    bool setRoot(std::uint8_t root) {
        if(root<24||root>72)return false;
        root_=root;retune();return true;
    }
    GameEvent move(int dx,int dy) {
        // Reduction first makes even INT_MIN / INT_MAX movement safe.
        const int nextX=static_cast<int>(x_)+(dx%length_);
        x_=static_cast<std::uint8_t>((nextX+length_)%length_);
        const int nextY=static_cast<int>(row_)+(dy%rows);
        row_=static_cast<std::uint8_t>((nextY+rows)%rows);
        return collect();
    }
    GameEvent strike() {
        steps_[x_]={true,noteForRow(row_),100};noteRows_[x_]=row_;
        return {true,false,steps_[x_].note,steps_[x_].velocity};
    }
    void erase() { steps_[x_].active=false; }
    void eraseAt(unsigned at){if(at<length_)steps_[at].active=false;}
    GameEvent plantAt(unsigned at,unsigned row,uint8_t velocity=100){
        if(at>=length_||row>=rows||velocity>127)return {};
        noteRows_[at]=static_cast<uint8_t>(row);steps_[at]={true,noteForRow(row),velocity};
        return {true,true,steps_[at].note,velocity};
    }
    GameEvent advance() {
        x_=static_cast<std::uint8_t>((x_+1)%length_);
        auto event=collect();
        if(event.trigger)return event;
        const auto& step=steps_[x_];return {step.active,false,step.note,step.velocity};
    }
    GameEvent atCurrent() {
        auto event=collect();if(event.trigger)return event;
        const auto& step=steps_[x_];return {step.active,false,step.note,step.velocity};
    }
    std::uint8_t noteForRow(std::uint8_t row) const {
        constexpr std::uint8_t pentatonic[]={0,3,5,7,10,12,15,17};
        constexpr std::uint8_t minor[]={0,2,3,5,7,8,10,12};
        constexpr std::uint8_t dorian[]={0,2,3,5,7,9,10,12};
        row%=rows;
        return static_cast<std::uint8_t>(root_+(scale_==GameScale::pentatonic?pentatonic[row]:scale_==GameScale::minor?minor[row]:dorian[row]));
    }
    const GameStep* steps() const {return steps_;}
    std::uint8_t length() const {return length_;}
    std::uint8_t x() const {return x_;}
    std::uint8_t row() const {return row_;}
    std::uint8_t root() const {return root_;}
    GameScale scale() const {return scale_;}
    std::uint8_t star(std::uint8_t column) const {return column<maximumSteps?stars_[column]:0;}
    std::uint8_t noteRow(std::uint8_t column) const {return column<maximumSteps?noteRows_[column]:0;}
    std::uint32_t score() const {return score_;}
    const char* scaleName() const {return scale_==GameScale::pentatonic?"PENTA":scale_==GameScale::minor?"MINOR":"DORIAN";}
private:
    std::uint32_t random(){random_^=random_<<13;random_^=random_>>17;random_^=random_<<5;return random_;}
    void retune(){for(std::uint8_t i=0;i<maximumSteps;++i)steps_[i].note=noteForRow(noteRows_[i]);}
    GameEvent collect(){
        if(row_!=stars_[x_])return {};
        if(score_!=UINT32_MAX)++score_;
        steps_[x_]={true,noteForRow(row_),static_cast<std::uint8_t>(95+score_%25)};
        noteRows_[x_]=row_;
        stars_[x_]=static_cast<std::uint8_t>((row_+1+random()%(rows-1))%rows);
        return {true,true,steps_[x_].note,steps_[x_].velocity};
    }
    GameStep steps_[maximumSteps]{};
    std::uint8_t stars_[maximumSteps]{},noteRows_[maximumSteps]{};
    std::uint32_t random_=1,score_=0;
    std::uint8_t length_=16,x_=0,row_=3,root_=48;
    GameScale scale_=GameScale::pentatonic;
};
}
