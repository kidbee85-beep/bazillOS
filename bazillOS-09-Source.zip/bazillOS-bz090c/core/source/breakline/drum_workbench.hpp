// SPDX-License-Identifier: MIT
#pragma once
#include <cstdint>
#include "drum_packing.hpp"
#include <algorithm>
namespace bazill_drums {
constexpr unsigned lanes=8,maximumSteps=128;
inline constexpr const char* roles[lanes]={"KICK","SNARE","CLOSED HAT","OPEN HAT","CLAP","PERC","SHAKER","RIDE"};
struct Cell {uint8_t velocity=0,micro=0;bool locked=false;};
struct Recipe {const char* name;uint16_t hits[lanes];uint8_t swing,ghosts;};
// Masks describe individual drum lanes. No sample slice/note selectors are used.
inline constexpr Recipe recipes[]={
 {"Boom Bap",{0x0141,0x1010,0x5555,0x4000,0,0x0400,0x2222,0},16,18},
 {"Dust Pocket",{0x4101,0x1010,0x5555,0x0800,0,0x0040,0x2222,0},24,25},
 {"Late 90s",{0x0441,0x1010,0xD555,0x8000,0,0x0200,0x2222,0},20,32},
 {"LoFi Lounge",{0x0101,0x1010,0x5151,0x4000,0,0x0800,0x4444,0},29,15},
 {"Half Time",{0x0041,0x0100,0x5555,0x4000,0x0100,0x1000,0x2222,0},9,12},
 {"Jazz Dust",{0x2101,0x1010,0x5545,0x0800,0,0x0480,0x2222,0x1111},27,35},
 {"Broken Soul",{0x0209,0x1010,0xD555,0x2000,0x0010,0x0240,0xAAAA,0},19,30},
 {"Minimal Hop",{0x0001,0x1010,0x1111,0x4000,0,0,0x4444,0},14,8},
 {"DnB Two Step",{0x0401,0x1010,0xFFFF,0x8000,0,0x0240,0xAAAA,0},0,28},
 {"Jungle Ghosts",{0x0481,0x1210,0xDDDD,0x2000,0,0x0840,0xAAAA,0x1111},2,65},
 {"Liquid Roller",{0x0401,0x1010,0xD5D5,0x4000,0,0x0800,0xAAAA,0x1111},3,28},
 {"Dark Steppa",{0x0401,0x1110,0xF5F5,0x8000,0x1000,0x2200,0xAAAA,0},0,38},
 {"Amen Mutation",{0x4501,0x9290,0xDD55,0x4000,0,0x0844,0xAAAA,0},2,75},
 {"Neuro Cell",{0x0441,0x1010,0xF5DD,0x8000,0,0x2200,0xAAAA,0x1111},0,32},
 {"Sparse Jungle",{0x0401,0x1010,0x5555,0x2000,0,0x0240,0x8888,0},5,48},
 {"Halftime DnB",{0x0041,0x0100,0xDDDD,0x4000,0x0100,0x2200,0xAAAA,0},0,35},
 {"Deep House",{0x1111,0x1010,0x5555,0x4444,0x1010,0x2200,0xAAAA,0},8,10},
 {"Garage Swing",{0x1101,0x1010,0xD555,0x4444,0x1010,0x0840,0xAAAA,0},28,32},
 {"Dusty House",{0x1111,0x1010,0x5555,0x4444,0x1010,0x0240,0xAAAA,0},18,20},
 {"Acid Floor",{0x1111,0x1010,0xFFFF,0x4444,0x1010,0x2222,0xAAAA,0},0,8},
 {"Dub Techno",{0x1111,0x1010,0x5151,0x4444,0x1000,0x0800,0x2222,0},5,10},
 {"Warehouse",{0x1111,0x1010,0xFFFF,0x4444,0x1010,0x2222,0xAAAA,0x5555},0,12},
 {"Detroit Strain",{0x1111,0x1010,0xDD55,0x4444,0x1010,0x0842,0xAAAA,0x1111},4,24},
 {"Electro Virus",{0x0401,0x1010,0xF5F5,0x4000,0x1010,0x2222,0xAAAA,0},7,15},
 {"UK Garage",{0x2101,0x1010,0xD555,0x4444,0x1010,0x0240,0xAAAA,0},31,40},
 {"Broken Beat",{0x4501,0x1010,0xDD55,0x8000,0,0x0842,0xAAAA,0},20,45},
 {"Dubstep Half",{0x0041,0x0100,0xF555,0x4000,0x0100,0x0800,0xAAAA,0},3,20},
 {"Trap Culture",{0x0401,0x0100,0xFFFF,0x8000,0x0100,0x2222,0xAAAA,0},0,60},
 {"Footwork",{0x1145,0x1010,0xD5DD,0x8000,0x1010,0x2222,0xAAAA,0x4444},0,65},
 {"Afro Cell",{0x1111,0x1010,0x5555,0x4444,0x1010,0x4A52,0xAAAA,0x1111},17,35},
 {"Ambient Dust",{0x0001,0x0100,0x1111,0x4000,0,0x0800,0x2222,0},10,12},
 {"Coder Break",{0x4901,0x9290,0xDFFF,0x8000,0x1010,0x4A52,0xAAAA,0x5555},6,85}
};
constexpr unsigned recipeCount=sizeof(recipes)/sizeof(recipes[0]);
class Workbench {
public:
 Packing packing{};
 bool generate(unsigned recipe,unsigned n,uint32_t seed,unsigned variation,unsigned swing=255){
  if(recipe>=recipeCount||n<16||n>128||n%16||variation>100||(swing!=255&&swing>35))return false;
  const auto&p=recipes[recipe];uint32_t rng=seed?seed:0xBA21BEEF;
  auto random=[&](){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;};
  for(unsigned lane=0;lane<lanes;++lane)for(unsigned i=0;i<n;++i){
   auto& out=cells[lane][i];if(out.locked&&i<length)continue;
   const unsigned at=i%16;bool hit=(p.hits[lane]>>at)&1;
   const bool anchor=lane<2&&hit;
   const unsigned chance=lane<2?p.ghosts/2:p.ghosts;
   if(!anchor&&random()%10000<variation*chance)hit=!hit;
   unsigned velocity=lane==0?111:lane==1?105:lane<4?(at%4?72:96):82;
   if(hit&&!((p.hits[lane]>>at)&1))velocity=45+random()%28;
   if(hit)velocity=std::clamp<int>(int(velocity)+(variation?int(random()%15)-7:0),1,127);
   const unsigned delay=(at&1?(swing==255?p.swing:swing):0)+(variation?random()%4:0);
   out.velocity=hit?velocity:0;out.micro=std::min(47u,delay);out.locked=false;
  }
  length=n;return true;
 }
 const Cell& at(unsigned lane,unsigned step)const{return cells[lane<8?lane:0][step<length?step:0];}
 void toggle(unsigned lane,unsigned step){if(lane<8&&step<length){auto& c=cells[lane][step];c.velocity=c.velocity?0:100;}}
 void toggleLock(unsigned lane,unsigned step){if(lane<8&&step<length)cells[lane][step].locked=!cells[lane][step].locked;}
 unsigned size()const{return length;}
private:Cell cells[lanes][maximumSteps]{};unsigned length=0;
};
static_assert(sizeof(Workbench)<4608,"Drum grid must stay small enough for a bounded UI allocation");
}
